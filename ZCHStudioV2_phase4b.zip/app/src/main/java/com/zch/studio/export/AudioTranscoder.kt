package com.zch.studio.export

import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import java.io.File
import kotlin.math.min

/** Decodes any audio file Android can read and writes it as AAC in an .m4a file, cut at maxUs. */
class AudioTranscoder {

    fun transcode(src: File, out: File, maxUs: Long, isCancelled: () -> Boolean) {
        val extractor = MediaExtractor()
        var decoder: MediaCodec? = null
        var muxer: MediaMuxer? = null
        var pipeline: Pipeline? = null
        var finished = false
        try {
            extractor.setDataSource(src.absolutePath)
            val index = (0 until extractor.trackCount).firstOrNull {
                extractor.getTrackFormat(it).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true
            } ?: throw IllegalArgumentException("No audio track in this file")
            extractor.selectTrack(index)
            val inFormat = extractor.getTrackFormat(index)
            decoder = MediaCodec.createDecoderByType(inFormat.getString(MediaFormat.KEY_MIME)!!)
            decoder.configure(inFormat, null, null, 0)
            decoder.start()
            muxer = MediaMuxer(out.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            pipeline = Pipeline(extractor, decoder, muxer, maxUs, isCancelled)
            pipeline.run()
            if (pipeline.muxStarted) muxer.stop()
            finished = true
        } finally {
            runCatching { decoder?.stop() }
            runCatching { decoder?.release() }
            runCatching { pipeline?.encoder?.stop() }
            runCatching { pipeline?.encoder?.release() }
            runCatching { extractor.release() }
            runCatching { muxer?.release() }
            if (!finished) out.delete()
        }
    }

    private class Pipeline(
        private val extractor: MediaExtractor,
        private val decoder: MediaCodec,
        private val muxer: MediaMuxer,
        private val maxUs: Long,
        private val isCancelled: () -> Boolean,
    ) {
        var encoder: MediaCodec? = null
            private set
        var muxStarted = false
            private set

        private val dInfo = MediaCodec.BufferInfo()
        private val eInfo = MediaCodec.BufferInfo()
        private var sampleRate = 0
        private var channels = 0
        private var pcmBytes = 0L
        private var track = -1
        private var encoderDone = false

        fun run() {
            var extractorDone = false
            var decoderDone = false
            while (!encoderDone) {
                if (isCancelled()) throw VideoExporter.CancelledException()
                if (!extractorDone) {
                    val i = decoder.dequeueInputBuffer(0)
                    if (i >= 0) {
                        val buf = decoder.getInputBuffer(i)!!
                        val n = extractor.readSampleData(buf, 0)
                        val t = extractor.sampleTime
                        if (n < 0 || t > maxUs) {
                            decoder.queueInputBuffer(i, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            extractorDone = true
                        } else {
                            decoder.queueInputBuffer(i, 0, n, t, 0)
                            extractor.advance()
                        }
                    }
                }
                if (!decoderDone) {
                    val o = decoder.dequeueOutputBuffer(dInfo, 5_000L)
                    if (o >= 0) {
                        val data = decoder.getOutputBuffer(o)
                        if (dInfo.size > 0 && data != null) {
                            if (encoder == null) startEncoder(decoder.outputFormat)
                            data.position(dInfo.offset)
                            data.limit(dInfo.offset + dInfo.size)
                            feed(data)
                        }
                        val eos = dInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0
                        decoder.releaseOutputBuffer(o, false)
                        if (eos) {
                            decoderDone = true
                            endInput()
                        }
                    }
                }
                drain()
            }
        }

        private fun startEncoder(decoded: MediaFormat) {
            sampleRate = decoded.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            channels = decoded.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            val format = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, sampleRate, channels).apply {
                setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                setInteger(MediaFormat.KEY_BIT_RATE, 128_000)
                setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16_384)
            }
            val enc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
            enc.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            enc.start()
            encoder = enc
        }

        private fun ptsUs(): Long = pcmBytes / (2L * channels) * 1_000_000L / sampleRate

        /** Copies decoded PCM into the encoder in pieces that fit its input buffers. */
        private fun feed(data: java.nio.ByteBuffer) {
            val enc = encoder!!
            while (data.hasRemaining()) {
                drain()
                val i = enc.dequeueInputBuffer(10_000L)
                if (i < 0) continue
                val input = enc.getInputBuffer(i)!!
                input.clear()
                val n = min(input.remaining(), data.remaining())
                val piece = data.duplicate()
                piece.limit(piece.position() + n)
                input.put(piece)
                data.position(data.position() + n)
                enc.queueInputBuffer(i, 0, n, ptsUs(), 0)
                pcmBytes += n
            }
        }

        private fun endInput() {
            val enc = encoder ?: throw IllegalStateException("No audio could be decoded")
            while (true) {
                drain()
                val i = enc.dequeueInputBuffer(10_000L)
                if (i >= 0) {
                    enc.queueInputBuffer(i, 0, 0, ptsUs(), MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                    return
                }
            }
        }

        private fun drain() {
            val enc = encoder ?: return
            while (true) {
                val o = enc.dequeueOutputBuffer(eInfo, 0L)
                if (o == MediaCodec.INFO_TRY_AGAIN_LATER) return
                if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    track = muxer.addTrack(enc.outputFormat)
                    muxer.start()
                    muxStarted = true
                } else if (o >= 0) {
                    val buffer = enc.getOutputBuffer(o)
                    if (eInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) eInfo.size = 0
                    if (eInfo.size > 0 && buffer != null && muxStarted) {
                        buffer.position(eInfo.offset)
                        buffer.limit(eInfo.offset + eInfo.size)
                        muxer.writeSampleData(track, buffer, eInfo)
                    }
                    enc.releaseOutputBuffer(o, false)
                    if (eInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) {
                        encoderDone = true
                        return
                    }
                }
            }
        }
    }
}
