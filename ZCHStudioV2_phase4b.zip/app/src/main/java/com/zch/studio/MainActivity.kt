package com.zch.studio

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.PrimaryScrollableTabRow
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import com.zch.studio.data.ProjectStore
import com.zch.studio.model.Project
import com.zch.studio.export.ExportController
import com.zch.studio.ui.CardsScreen
import com.zch.studio.ui.ExportScreen
import com.zch.studio.ui.TimelineScreen
import com.zch.studio.ui.VoiceScreen
import java.io.File

/** Same nine sections as the WebView app. Cards, Timing, Export and Voice (audio file) are real so far. */
private val SECTIONS = listOf(
    "Cards", "Edit", "Timing", "Video", "Brand", "Export", "Text", "Effects", "Voice"
)

class MainActivity : ComponentActivity() {

    private val store by lazy { ProjectStore(File(filesDir, "project.json")) }
    private var project by mutableStateOf(Project())
    private val exporter by lazy { ExportController(applicationContext) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        project = store.load()
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                AppShell(
                    project = project,
                    onProject = { update(it) },
                    exporter = exporter,
                )
            }
        }
    }

    private fun update(p: Project) {
        project = p
        store.save(p)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppShell(
    project: Project,
    onProject: (Project) -> Unit,
    exporter: ExportController,
) {
    var selected by remember { mutableIntStateOf(0) }
    Scaffold { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            PrimaryScrollableTabRow(selectedTabIndex = selected) {
                SECTIONS.forEachIndexed { index, title ->
                    Tab(
                        selected = selected == index,
                        onClick = { selected = index },
                        text = { Text(title) },
                    )
                }
            }
            if (selected == 0) {
                CardsScreen(project, onProject)
            } else if (selected == 2) {
                TimelineScreen(project, onProject)
            } else if (selected == 5) {
                ExportScreen(project, onProject, exporter)
            } else if (selected == 8) {
                VoiceScreen(project, onProject)
            } else {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("${SECTIONS[selected]}: coming in the next phase")
                }
            }
        }
    }
}
