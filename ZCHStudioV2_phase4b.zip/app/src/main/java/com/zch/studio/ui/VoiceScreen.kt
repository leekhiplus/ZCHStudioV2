package com.zch.studio.ui

import android.os.Handler
import android.os.Looper
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.zch.studio.audio.AudioImport
import com.zch.studio.model.Project

/** Voice tab: choose a voiceover file, remove it, and decide whether the video ends with the audio or the last card. */
@Composable
fun VoiceScreen(project: Project, onProject: (Project) -> Unit) {
    val context = LocalContext.current
    val latest by rememberUpdatedState(project)
    val save by rememberUpdatedState(onProject)
    var message by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        busy = true
        message = "Importing..."
        val app = context.applicationContext
        Thread {
            val result = runCatching { AudioImport.import(app, uri) }
            Handler(Looper.getMainLooper()).post {
                busy = false
                result.onSuccess {
                    message = ""
                    save(latest.copy(audioName = it.name, audioSec = it.seconds))
                }.onFailure {
                    message = it.message ?: "Could not import this file"
                }
            }
        }.start()
    }

    Column(
        modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("Voiceover", style = MaterialTheme.typography.titleMedium)
        if (project.audioName.isEmpty()) {
            Text("No audio chosen.")
        } else {
            Text("${project.audioName}  (${project.audioSec.toInt() / 60}:${(project.audioSec.toInt() % 60).toString().padStart(2, '0')})")
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { picker.launch(arrayOf("audio/*")) }, enabled = !busy) {
                Text(if (project.audioName.isEmpty()) "Choose audio file" else "Replace audio")
            }
            if (project.audioName.isNotEmpty()) {
                OutlinedButton(
                    onClick = {
                        AudioImport.remove(context)
                        onProject(project.copy(audioName = "", audioSec = 0.0))
                    },
                    enabled = !busy,
                ) { Text("Remove") }
            }
        }
        if (message.isNotEmpty()) Text(message, style = MaterialTheme.typography.bodySmall)

        Text("Video ends with", style = MaterialTheme.typography.labelMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(
                selected = project.endm != "card",
                onClick = { onProject(project.copy(endm = "voice")) },
                label = { Text("Audio length") },
            )
            FilterChip(
                selected = project.endm == "card",
                onClick = { onProject(project.copy(endm = "card")) },
                label = { Text("Last card") },
            )
        }
        Text(
            "With Last card, audio longer than the cards is cut at the end of the video.",
            style = MaterialTheme.typography.bodySmall,
        )
    }
}
