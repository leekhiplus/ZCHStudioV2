package com.zch.studio.export

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.zch.studio.audio.AudioImport
import com.zch.studio.model.Project
import com.zch.studio.model.totalDuration
import com.zch.studio.render.Fonts
import com.zch.studio.render.ImageCache
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Runs an export (video, optional voiceover, join) on a background thread and exposes progress for the Export tab. Lives as long as the activity. */
class ExportController(private val app: Context) {

    var running by mutableStateOf(false)
        private set
    var progress by mutableFloatStateOf(0f)
        private set
    var status by mutableStateOf("")
        private set

    @Volatile
    private var cancelled = false

    fun start(project: Project) {
        if (running) return
        running = true
        cancelled = false
        progress = 0f
        status = "Rendering video..."
        Thread({
            val videoOnly = File(app.cacheDir, "zch-video.mp4")
            val audioAac = File(app.cacheDir, "zch-audio.m4a")
            val finalFile = File(app.cacheDir, "zch-export.mp4")
            try {
                val voice = AudioImport.voiceFile(app)
                val withAudio = project.audioName.isNotEmpty() && voice.exists()
                val share = if (withAudio) 0.85f else 1f
                VideoExporter().export(
                    project, if (withAudio) videoOnly else finalFile,
                    Fonts(app), ImageCache(), { progress = it * share }, { cancelled },
                )
                var note = ""
                if (withAudio) {
                    try {
                        status = "Processing audio..."
                        val maxUs = (project.totalDuration() * 1_000_000f).toLong()
                        AudioTranscoder().transcode(voice, audioAac, maxUs) { cancelled }
                        progress = 0.95f
                        status = "Combining video and audio..."
                        Mp4Mux.combine(videoOnly, audioAac, finalFile, maxUs)
                    } catch (e: VideoExporter.CancelledException) {
                        throw e
                    } catch (e: Throwable) {
                        // Keep the finished video rather than lose it.
                        note = " (without audio: " + (e.message ?: e.javaClass.simpleName) + ")"
                        videoOnly.copyTo(finalFile, overwrite = true)
                    }
                }
                progress = 1f
                status = "Saving..."
                status = "Saved: " + save(finalFile) + note
            } catch (e: VideoExporter.CancelledException) {
                status = "Export cancelled"
            } catch (e: Throwable) {
                status = "Export failed: " + (e.message ?: e.javaClass.simpleName)
            } finally {
                videoOnly.delete()
                audioAac.delete()
                finalFile.delete()
                running = false
            }
        }, "zch-export").start()
    }

    fun cancel() {
        cancelled = true
    }

    /** Android 10 and newer: Movies/ZCH in the gallery. Older: the app's own Movies folder. Returns where it went. */
    private fun save(source: File): String {
        val name = "ZCH-" + SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date()) + ".mp4"
        if (Build.VERSION.SDK_INT >= 29) {
            val resolver = app.contentResolver
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, name)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/ZCH")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("Could not create the video file")
            resolver.openOutputStream(uri)!!.use { out -> source.inputStream().use { it.copyTo(out) } }
            values.clear()
            values.put(MediaStore.Video.Media.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            return "Movies/ZCH/$name"
        }
        val dir = app.getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: app.filesDir
        val dest = File(dir, name)
        source.copyTo(dest, overwrite = true)
        return dest.absolutePath
    }
}
