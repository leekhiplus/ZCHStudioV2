package com.zch.studio.render

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import com.zch.studio.model.NewsCard
import kotlin.math.max
import kotlin.math.min

/** Drawing helpers for one card frame. Coordinates are pixels on the canvas. */
class Ctx(
    val c: Canvas,
    val W: Float,
    val H: Float,
    /** Scale factor: 1.0 at 720 px short side, same as the WebView app's S. */
    val S: Float,
    val card: NewsCard,
    val t: Float,
    val fonts: Fonts,
    val images: ImageCache,
) {
    val B: Float = H
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    val tc: Int get() = safeColor(card.tc, Color.WHITE)
    val bgc: Int get() = safeColor(card.bg, Color.parseColor("#0a1630"))

    fun firstImage(): String = card.imgs.firstOrNull() ?: card.src

    fun isUrdu(s: String): Boolean = s.any { it in '\u0600'..'\u06FF' }

    private fun typeface(rtl: Boolean, bold: Boolean): Typeface = when {
        rtl -> fonts.urdu
        bold -> fonts.latinBold
        else -> fonts.latinRegular
    }

    private fun lineHeight(size: Float, rtl: Boolean): Float = size * if (rtl) fonts.urduLineFactor else 1.3f

    fun rect(x: Float, y: Float, w: Float, h: Float, color: Int, radius: Float = 0f, alpha: Int = 255) {
        paint.reset()
        paint.isAntiAlias = true
        paint.style = Paint.Style.FILL
        paint.color = color
        paint.alpha = Color.alpha(color) * alpha / 255
        if (radius > 0f) {
            c.drawRoundRect(RectF(x, y, x + w, y + h), radius, radius, paint)
        } else {
            c.drawRect(x, y, x + w, y + h, paint)
        }
    }

    fun gradient(x: Float, y: Float, w: Float, h: Float, from: Int, to: Int, diagonal: Boolean = false) {
        paint.reset()
        paint.shader = LinearGradient(
            x, y,
            if (diagonal) x + w else x,
            if (diagonal) y + h else y + h,
            from, to, Shader.TileMode.CLAMP,
        )
        c.drawRect(x, y, x + w, y + h, paint)
        paint.shader = null
    }

    /** Wraps text to the given width, in pixels. */
    private fun wrap(s: String, size: Float, tf: Typeface, maxW: Float): List<String> {
        paint.reset()
        paint.typeface = tf
        paint.textSize = size
        val lines = mutableListOf<String>()
        for (para in s.split('\n')) {
            var line = ""
            for (word in para.trim().split(Regex("\\s+"))) {
                if (word.isEmpty()) continue
                val candidate = if (line.isEmpty()) word else "$line $word"
                if (line.isNotEmpty() && paint.measureText(candidate) > maxW) {
                    lines += line
                    line = word
                } else {
                    line = candidate
                }
            }
            lines += line
        }
        return lines
    }

    /** Height that text() would use. Same scaling rules as text(). */
    fun textHeight(s: String, w: Float, size: Float, bold: Boolean = true): Float {
        if (s.isBlank()) return 0f
        val rtl = isUrdu(s)
        val px = size * S * card.ts.toFloat()
        val lines = wrap(s, px, typeface(rtl, bold), w)
        return lineHeight(px, rtl) * lines.size
    }

    /** Draws wrapped, centred text in the box (x, y, w). Returns the height used. */
    fun text(s: String, x: Float, y: Float, w: Float, size: Float, color: Int, bold: Boolean = true, alpha: Int = 255): Float {
        if (s.isBlank()) return 0f
        val rtl = isUrdu(s)
        val px = size * S * card.ts.toFloat()
        val tf = typeface(rtl, bold)
        val lines = wrap(s, px, tf, w)
        val lh = lineHeight(px, rtl)
        paint.reset()
        paint.isAntiAlias = true
        paint.typeface = tf
        paint.textSize = px
        paint.textAlign = Paint.Align.CENTER
        paint.color = color
        paint.alpha = Color.alpha(color) * alpha / 255
        val fm = paint.fontMetrics
        val mid = -(fm.ascent + fm.descent) / 2f
        lines.forEachIndexed { i, line ->
            c.drawText(line, x + w / 2f, y + lh * i + lh / 2f + mid, paint)
        }
        return lh * lines.size
    }

    /** Single line of text centred on (cx, cy), with an absolute pixel size. */
    fun centerText(s: String, cx: Float, cy: Float, px: Float, color: Int, tf: Typeface = fonts.latinBold) {
        paint.reset()
        paint.isAntiAlias = true
        paint.typeface = tf
        paint.textSize = px
        paint.textAlign = Paint.Align.CENTER
        paint.color = color
        val fm = paint.fontMetrics
        c.drawText(s, cx, cy - (fm.ascent + fm.descent) / 2f, paint)
    }

    /** Coloured label box with centred text, like LB() in the WebView app. */
    fun label(s: String, x: Float, y: Float, w: Float, h: Float, bg: Int, fg: Int, alpha: Int = 255) {
        rect(x, y, w, h, bg, radius = h / 4f, alpha = alpha)
        centerText(s, x + w / 2f, y + h / 2f, h * 0.52f, fg)
    }

    /** Draws a picture into a box, with fit/fill, zoom and position from the card. */
    fun image(x: Float, y: Float, w: Float, h: Float, src: String) {
        val bmp: Bitmap? = images.get(src)
        c.save()
        c.clipRect(x, y, x + w, y + h)
        if (bmp == null) {
            gradient(x, y, w, h, Color.parseColor("#1c2f66"), Color.parseColor("#0a1630"), diagonal = true)
        } else {
            val fit = card.fit == "fit"
            val base = if (fit) min(w / bmp.width, h / bmp.height) else max(w / bmp.width, h / bmp.height)
            val r = base * card.iz.toFloat()
            val dw = bmp.width * r
            val dh = bmp.height * r
            val dx = x + (w - dw) * (card.fx / 100.0).toFloat()
            val dy = y + (h - dh) * (card.fy / 100.0).toFloat()
            paint.reset()
            paint.isAntiAlias = true
            paint.isFilterBitmap = true
            c.drawBitmap(bmp, null, RectF(dx, dy, dx + dw, dy + dh), paint)
        }
        c.restore()
    }

    /** Circular flag badge with a yellow ring and the team name below it. */
    fun flag(name: String, cx: Float, cy: Float, r: Float) {
        c.save()
        val circle = Path().apply { addCircle(cx, cy, r, Path.Direction.CW) }
        c.clipPath(circle)
        val isPak = name.contains("pak", ignoreCase = true) || name.contains("پاک")
        if (isPak) {
            rect(cx - r, cy - r, 2 * r, 2 * r, Color.parseColor("#01411c"))
            rect(cx - r, cy - r, r * 0.5f, 2 * r, Color.WHITE)
            paint.reset(); paint.isAntiAlias = true; paint.color = Color.WHITE
            c.drawCircle(cx + r * 0.1f, cy, r * 0.5f, paint)
            paint.color = Color.parseColor("#01411c")
            c.drawCircle(cx + r * 0.25f, cy - r * 0.08f, r * 0.42f, paint)
        } else {
            rect(cx - r, cy - r, 2 * r, 2 * r, Color.parseColor("#24418f"))
            centerText(name.replace(" ", "").take(3).uppercase(), cx, cy, r * 0.6f, Color.WHITE)
        }
        c.restore()
        paint.reset(); paint.isAntiAlias = true
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 3 * S
        paint.color = Color.parseColor("#f5c518")
        c.drawCircle(cx, cy, r, paint)
        paint.style = Paint.Style.FILL
        centerText(name, cx, cy + r + 26 * S, 24 * S, Color.WHITE)
    }

    companion object {
        fun safeColor(s: String, fallback: Int): Int =
            runCatching { Color.parseColor(s) }.getOrDefault(fallback)
    }
}
