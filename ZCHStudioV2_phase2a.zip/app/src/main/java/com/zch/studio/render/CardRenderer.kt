package com.zch.studio.render

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Path
import com.zch.studio.model.NewsCard
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.min
import kotlin.math.sin

/**
 * Draws one slide. Ported from the WebView app's CARD() function.
 * Phase 2a: templates 0 to 7. Templates 8 to 21 use template 0 until phase 2b.
 * Still to come: transitions, text and picture animations, ticker, logo, lower third.
 */
object CardRenderer {

    private val RED = Color.parseColor("#c8102e")
    private val YELLOW = Color.parseColor("#f5c518")
    private val NAVY = Color.parseColor("#0a1630")
    private val WHITE = Color.WHITE
    private val SOFT = Color.parseColor("#e6e6e6")
    private val PALE = Color.parseColor("#c9d6ff")

    /** Draws the card at time t (seconds into the card) onto a W x H canvas. */
    fun draw(canvas: Canvas, card: NewsCard, t: Float, width: Int, height: Int, fonts: Fonts, images: ImageCache) {
        val s = min(width, height) / 720f
        val x = Ctx(canvas, width.toFloat(), height.toFloat(), s, card, t, fonts, images)
        x.rect(0f, 0f, x.W, x.H, x.bgc)
        when (card.tpl) {
            0 -> t0(x)
            1 -> t1(x)
            2 -> t2(x)
            3 -> t3(x)
            4 -> t4(x)
            5 -> t5(x)
            6 -> t6(x)
            7 -> t7(x)
            else -> t0(x)
        }
    }

    private fun isLandscape(x: Ctx): Boolean = x.W >= x.H * 0.9f

    /** 0: Classic breaking news. Picture on top, red band with headline and description. */
    private fun t0(x: Ctx) = with(x) {
        val ih = B * 0.52f * card.fs.toFloat()
        image(0f, 0f, W, ih, firstImage())
        rect(0f, ih, W, B * 0.28f, RED)
        rect(0f, ih, W, 6 * S, YELLOW)
        label("BREAKING NEWS", 0.03f * W, 0.03f * B, 260 * S, 48 * S, RED, WHITE)
        text(card.head, 0.04f * W, ih + 0.025f * B, 0.92f * W, 50f, tc)
        text(card.desc, 0.04f * W, ih + B * 0.29f, 0.92f * W, 28f, WHITE, bold = false)
    }

    /** 1: Professional TV bulletin. Blue header, picture in a frame below. */
    private fun t1(x: Ctx) = with(x) {
        rect(0f, 0f, W, B * 0.2f, Color.parseColor("#0d2a6b"))
        rect(0f, B * 0.2f, W, 5 * S, YELLOW)
        text(card.head, 0.04f * W, 0.03f * B, 0.92f * W, 44f, tc)
        val ih = B * 0.4f * card.fs.toFloat()
        image(0.06f * W, B * 0.24f, 0.88f * W, ih, firstImage())
        text(card.desc, 0.06f * W, B * 0.27f + ih, 0.88f * W, 28f, WHITE, bold = false)
    }

    /** 2: Cricket sports news. Two team badges, VS, score box. */
    private fun t2(x: Ctx) = with(x) {
        gradient(0f, 0f, W, H, NAVY, Color.parseColor("#16398a"))
        image(0f, 0f, W, B * 0.38f, firstImage())
        val r = min(W, H) * 0.075f
        flag(card.a, W * 0.25f, B * 0.46f, r)
        flag(card.b, W * 0.75f, B * 0.46f, r)
        centerText("VS", W / 2f, B * 0.46f, 44 * S, YELLOW)
        val hh = text(card.head, 0.04f * W, B * 0.58f, 0.92f * W, 42f, tc)
        val py = B * 0.58f + hh
        rect(0.05f * W, py + 0.01f * B, 0.9f * W, 0.2f * B, Color.BLACK, radius = 16 * S, alpha = 115)
        text(card.c, 0.06f * W, py + 0.015f * B, 0.88f * W, 40f, YELLOW)
        text(card.d, 0.06f * W, py + 0.11f * B, 0.88f * W, 26f, WHITE, bold = false)
    }

    /** 3: Headline news. Picture on the left (landscape) or top (portrait), text beside or below. */
    private fun t3(x: Ctx) = with(x) {
        val land = isLandscape(this)
        val tx: Float
        val ty: Float
        val tw: Float
        if (land) {
            image(0f, 0f, W * 0.5f, B, firstImage())
            rect(W * 0.5f, 0f, 8 * S, B, RED)
            tx = 0.54f * W; ty = 0.08f * B; tw = 0.42f * W
        } else {
            image(0f, 0f, W, B * 0.5f, firstImage())
            rect(0f, B * 0.5f, W, 8 * S, RED)
            tx = 0.05f * W; ty = B * 0.54f; tw = 0.9f * W
        }
        val hh = text(card.head, tx, ty, tw, 48f, tc)
        text(card.desc, tx, ty + hh + 0.02f * B, tw, 26f, WHITE, bold = false)
    }

    /** 4: Special report. Full picture with a dark panel and a SPECIAL REPORT label. */
    private fun t4(x: Ctx) = with(x) {
        image(0f, 0f, W, B, firstImage())
        val w = 0.9f * W
        val h1 = textHeight(card.head, w, 52f)
        val h2 = textHeight(card.desc, w, 26f, bold = false)
        val ph = h1 + h2 + 64 * S + 0.02f * B
        val py = B - ph - 0.03f * B
        rect(0.03f * W, py, 0.94f * W, ph, Color.argb(235, 8, 16, 40), radius = 14 * S)
        label("SPECIAL REPORT", 0.05f * W, py + 10 * S, 280 * S, 46 * S, YELLOW, NAVY)
        text(card.head, 0.05f * W, py + 60 * S, w, 52f, tc)
        text(card.desc, 0.05f * W, py + 60 * S + h1, w, 26f, SOFT, bold = false)
    }

    /** 5: Match score update. Gradient background, flags, big score. */
    private fun t5(x: Ctx) = with(x) {
        gradient(0f, 0f, W, H, NAVY, Color.parseColor("#1b3a8c"), diagonal = true)
        label("MATCH UPDATE", 0.04f * W, 0.03f * B, 260 * S, 46 * S, RED, WHITE)
        text(card.head, 0.04f * W, 0.12f * B, 0.92f * W, 34f, tc)
        val r = min(W, H) * 0.11f
        flag(card.a, W * 0.2f, B * 0.45f, r)
        flag(card.b, W * 0.8f, B * 0.45f, r)
        text(card.c, 0.3f * W, B * 0.37f, 0.4f * W, 80f, YELLOW)
        text(card.d, 0.05f * W, B * 0.7f, 0.9f * W, 32f, WHITE)
        text(card.desc, 0.05f * W, B * 0.8f, 0.9f * W, 24f, PALE, bold = false)
    }

    /** 6: Player performance. Photo, name, stat box, description. */
    private fun t6(x: Ctx) = with(x) {
        val land = isLandscape(this)
        if (land) image(0f, 0f, W * 0.42f, B, firstImage()) else image(0f, 0f, W, B * 0.42f, firstImage())
        val tx = if (land) 0.46f * W else 0.05f * W
        val ty = if (land) 0.06f * B else B * 0.45f
        val tw = if (land) 0.5f * W else 0.9f * W
        label("PLAYER PERFORMANCE", tx, ty, min(tw, 340 * S), 42 * S, RED, WHITE)
        var y = ty + 52 * S
        y += text(card.a, tx, y, tw, 56f, YELLOW)
        y += text(card.b, tx, y, tw, 30f, WHITE, bold = false)
        rect(tx, y + 6 * S, tw, 0.17f * B, Color.argb(26, 255, 255, 255), radius = 14 * S)
        text(card.c, tx, y + 10 * S, tw, 34f, tc)
        text(card.d, tx, y + 0.085f * B, tw, 30f, tc, bold = false)
        text(card.head, tx, y + 0.2f * B, tw, 28f, PALE, bold = false)
    }

    /** 7: Breaking news alert. Blinking alert bar, animated stripes, headline below the picture. */
    private fun t7(x: Ctx) = with(x) {
        val has = firstImage().isNotEmpty()
        val w = 0.9f * W
        val h1 = textHeight(card.head, w, 60f)
        val h2 = textHeight(card.desc, w, 30f, bold = false)
        val top = 0.24f * B + 5 * S
        val ph = if (has) min(h1 + h2 + 0.06f * B, B - top - 0.2f * B) else 0f
        val py = if (has) B - ph else top
        if (has) {
            image(0f, 0f, W, py, firstImage())
            rect(0f, py, W, B - py, bgc)
        }
        // Moving stripes over the lower area
        c.save()
        c.clipRect(0f, py, W, B)
        val gap = 170 * S
        val n = ceil((W + H * 0.4f) / gap).toInt() + 1
        val stripe = Path()
        for (i in 0 until n) {
            val sx = (i * gap + t * 70 * S) % (n * gap) - H * 0.4f
            stripe.reset()
            stripe.moveTo(sx, 0f)
            stripe.lineTo(sx + 60 * S, 0f)
            stripe.lineTo(sx + 60 * S - H * 0.4f, B)
            stripe.lineTo(sx - H * 0.4f, B)
            stripe.close()
            val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
            paint.color = Color.argb(20, 255, 255, 255)
            c.drawPath(stripe, paint)
        }
        c.restore()
        rect(0f, 0.1f * B, W, 0.14f * B, Color.parseColor("#0a0a0a"))
        val blink = (255 * (0.65f + 0.35f * abs(sin(t * 5f)))).toInt()
        label("BREAKING NEWS ALERT", 0.05f * W, 0.115f * B, 0.9f * W, 0.11f * B, RED, WHITE, alpha = blink)
        rect(0f, 0.24f * B, W, 5 * S, YELLOW)
        val ty = if (has) py + 0.03f * B else 0.3f * B
        val hh = text(card.head, 0.05f * W, ty, w, 60f, tc)
        text(card.desc, 0.05f * W, ty + hh + 0.02f * B, w, 30f, WHITE, bold = false)
    }
}
