package com.zch.studio.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.LocalContext
import com.zch.studio.model.NewsCard
import com.zch.studio.render.CardRenderer
import com.zch.studio.render.Fonts
import com.zch.studio.render.ImageCache

/** Live preview of one slide at 16:9, drawn by the same renderer used for export. */
@Composable
fun CardPreview(card: NewsCard, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val fonts = remember { Fonts(context) }
    val images = remember { ImageCache() }
    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .aspectRatio(16f / 9f)
            .background(Color.Black),
    ) {
        drawPreview(card, fonts, images)
    }
}

private fun DrawScope.drawPreview(card: NewsCard, fonts: Fonts, images: ImageCache) {
    val native = drawContext.canvas.nativeCanvas
    native.save()
    native.scale(size.width / 1280f, size.height / 720f)
    CardRenderer.draw(native, card, 0f, 1280, 720, fonts, images)
    native.restore()
}
