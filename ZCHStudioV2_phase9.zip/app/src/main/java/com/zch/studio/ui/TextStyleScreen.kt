package com.zch.studio.ui

import androidx.compose.runtime.Composable
import com.zch.studio.model.Project

/** Text tab, in boxes: size and colours of the selected card. */
@Composable
fun TextStyleScreen(project: Project, onProject: (Project) -> Unit) {
    CardSettings(project, onProject) { card, update ->
        Panel("Size", hint = "Text size of this card") {
            LabeledSlider("Text size", card.ts.toFloat(), 0.5f..1.6f) { update(card.copy(ts = it.toDouble())) }
            Hint("Urdu text uses Noto Nastaliq Urdu and English text uses Montserrat. Both are built into the app.")
        }
        Panel("Colors", hint = "Text and background") {
            ColorField("Text color", card.tc) { update(card.copy(tc = it)) }
            ColorField("Background color", card.bg) { update(card.copy(bg = it)) }
        }
    }
}
