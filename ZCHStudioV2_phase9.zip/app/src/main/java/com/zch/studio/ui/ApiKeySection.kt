package com.zch.studio.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.zch.studio.gemini.SecureKey

/** Gemini API key entry. The key is stored encrypted and never goes into the project file. */
@Composable
fun ApiKeySection() {
    val context = LocalContext.current
    var typed by remember { mutableStateOf("") }
    var hasKey by remember { mutableStateOf(SecureKey.load(context).isNotEmpty()) }
    var message by remember { mutableStateOf("") }

    Panel("Gemini API key", startOpen = !hasKey, hint = if (hasKey) "Saved on this phone" else "") {
        Text(
            if (hasKey) "A key is saved on this phone, encrypted." else "No key saved yet.",
            style = MaterialTheme.typography.bodySmall,
        )
        OutlinedTextField(
            value = typed,
            onValueChange = { typed = it },
            label = { Text(if (hasKey) "Replace key" else "Paste key") },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth(),
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = {
                    runCatching { SecureKey.save(context, typed) }
                        .onSuccess { hasKey = true; typed = ""; message = "Key saved." }
                        .onFailure { message = "Could not save the key: " + (it.message ?: "") }
                },
                enabled = typed.isNotBlank(),
            ) { Text("Save key") }
            if (hasKey) {
                OutlinedButton(onClick = { SecureKey.clear(context); hasKey = false; message = "Key removed." }) { Text("Remove key") }
            }
        }
        if (message.isNotEmpty()) Text(message, style = MaterialTheme.typography.bodySmall)
    }
}
