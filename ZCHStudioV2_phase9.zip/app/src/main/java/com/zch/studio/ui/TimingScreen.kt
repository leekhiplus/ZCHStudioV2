package com.zch.studio.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.material3.Text
import androidx.compose.ui.unit.dp
import com.zch.studio.model.Project
import com.zch.studio.model.closeGaps
import com.zch.studio.model.withEqualLengths
import java.util.Locale
import kotlin.math.max

/** Timing tab, in boxes: this card, all cards, and how to edit in the timeline. */
@Composable
fun TimingScreen(project: Project, onProject: (Project) -> Unit, player: PlayerState) {
    var every by remember { mutableFloatStateOf(5f) }
    CardSettings(project, onProject) { card, update ->
        Panel("This card", hint = "Start, end, length") {
            Stepper("Start (s)", card.s) { update(card.copy(s = it.coerceIn(0.0, card.e - 0.3))) }
            Stepper("End (s)", card.e) { update(card.copy(e = max(it, card.s + 0.3))) }
            Hint("Length: " + String.format(Locale.US, "%.1f", card.e - card.s) + " s")
            Button(onClick = { player.time = card.s.toFloat(); player.playing = true }) { Text("Play from this card") }
        }
        Panel("All cards", startOpen = false, hint = "Close gaps, same length") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { onProject(project.closeGaps()) }) { Text("Back to back") }
            }
            LabeledSlider("Same length for every card (s)", every, 2f..12f, 1) { every = it }
            OutlinedButton(onClick = { onProject(project.withEqualLengths(every.toDouble())) }) { Text("Apply same length") }
        }
        Panel("Editing in the timeline", startOpen = false, hint = "Drag, zoom, scroll") {
            Hint(
                "Tap a card in the timeline to select it, then drag it. The edges change its start or end and the middle moves it. " +
                    "Drag anywhere else to scroll. Use Fit, 1x, 2x, 4x, 8x to zoom and Tall for more tracks. " +
                    "Cards made with a Gemini voice are timed to the speech, so changing them can move picture and voice apart.",
            )
        }
    }
}
