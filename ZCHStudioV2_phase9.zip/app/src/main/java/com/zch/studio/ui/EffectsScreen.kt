package com.zch.studio.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.zch.studio.audio.SfxPlayer
import com.zch.studio.audio.SfxSynth
import com.zch.studio.model.Project

private val TEXT_ANIMATIONS = listOf(
    "Fade In", "Slide From Right", "Slide From Left", "Slide From Bottom", "Pop In", "Zoom In", "Slide From Top",
    "Zoom Out", "Bounce Drop", "Spin In", "Flip In", "Wipe (right to left)", "Wipe (left to right)", "No animation",
)
private val PICTURE_ANIMATIONS = listOf(
    "Slow Zoom In", "Slow Zoom Out", "Pan Left", "Pan Right", "Static Image", "Pan Up", "Pan Down",
    "Zoom In + Pan Right", "Zoom Out + Pan Left", "Pulse", "Fast Zoom In",
)
private val TRANSITIONS = listOf(
    "cut" to "Cut", "cross" to "Crossfade", "fade" to "Fade through black", "flash" to "Flash", "push" to "Push",
    "slide" to "Slide from right", "slidel" to "Slide from left", "slideu" to "Slide up", "zoom" to "Zoom in", "wipe" to "Wipe",
)
private val PICTURE_CHANGES = listOf("cross" to "Crossfade", "slide" to "Slide", "zoom" to "Zoom", "flash" to "Flash", "wipe" to "Wipe")

/** Effects tab, in boxes: presets, animation, lower third, captions, sound, transitions and shine. */
@Composable
fun EffectsScreen(project: Project, onProject: (Project) -> Unit) {
    val sfx = remember { SfxPlayer() }
    DisposableEffect(Unit) { onDispose { sfx.release() } }

    CardSettings(project, onProject) { card, update ->
        Panel("Presets", hint = "Newsroom look in one tap") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = {
                    update(card.copy(tpl = 16, ot = 1, ot1 = "BREAKING NEWS", ot2 = "LIVE", ol = 1, olx = "fade", sh = 1, it = "cross", pz = 1))
                }) { Text("Newsroom preset") }
                OutlinedButton(onClick = {
                    onProject(
                        project.copy(
                            cards = project.cards.map { c ->
                                c.copy(
                                    ot = card.ot, ot1 = card.ot1, ot2 = card.ot2, ol = card.ol, olx = card.olx,
                                    olc = card.olc, sh = card.sh, it = card.it, pz = card.pz,
                                )
                            },
                        ),
                    )
                }) { Text("Apply to all cards") }
            }
            Hint("Apply to all cards copies the lower third, shine, picture change and pop of this card to every card.")
        }

        Panel("Animation", hint = "Text and picture motion") {
            IndexChoice("Text animation", TEXT_ANIMATIONS, card.ta) { update(card.copy(ta = it)) }
            IndexChoice("Picture animation", PICTURE_ANIMATIONS, card.ia) { update(card.copy(ia = it)) }
            LabeledSlider("Animation speed", card.sp.toFloat(), 0.5f..3f) { update(card.copy(sp = it.toDouble())) }
            Choice("When the picture changes", PICTURE_CHANGES, card.it) { update(card.copy(it = it)) }
            SwitchRow("Small pop when the card starts", card.pz != 0) { update(card.copy(pz = if (it) 1 else 0)) }
        }

        Panel("Lower third", startOpen = false, hint = if (card.ot != 0 || card.ol != 0) "On" else "Off") {
            SwitchRow("Tag at the top left", card.ot != 0) { update(card.copy(ot = if (it) 1 else 0)) }
            if (card.ot != 0) {
                OutlinedTextField(
                    value = card.ot1, onValueChange = { update(card.copy(ot1 = it)) },
                    label = { Text("Red part") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = card.ot2, onValueChange = { update(card.copy(ot2 = it)) },
                    label = { Text("White part (can be empty)") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                )
            }
            SwitchRow("Text bar at the bottom", card.ol != 0) { update(card.copy(ol = if (it) 1 else 0)) }
            if (card.ol != 0) {
                OutlinedTextField(
                    value = card.lt, onValueChange = { update(card.copy(lt = it)) },
                    label = { Text("Bar text (empty uses the headline)") }, modifier = Modifier.fillMaxWidth(),
                )
                Choice("Bar text at the end", listOf("fade" to "Fade out", "slide" to "Slide out", "stay" to "Stay"), card.olx.ifBlank { "fade" }) {
                    update(card.copy(olx = it))
                }
                ColorField("Bar color", card.olc) { update(card.copy(olc = it)) }
            }
            SwitchRow("Shine on the tag and bar", card.sh != 0) { update(card.copy(sh = if (it) 1 else 0)) }
        }

        Panel("Captions", startOpen = false, hint = if (card.cap != 0) "On" else "Off") {
            SwitchRow("Show the spoken words on the card", card.cap != 0) { update(card.copy(cap = if (it) 1 else 0)) }
            Hint("Captions need a voiceover whose cards are matched to it. Make one in the Voice tab.")
        }

        Panel("Sound at card start", startOpen = false, hint = SfxSynth.nameFor(card, project) ?: "No sound") {
            Choice("This card", listOf("def" to "Use the default", "none" to "No sound") + SfxSynth.NAMES, card.sfx.ifEmpty { "def" }) {
                update(card.copy(sfx = it))
            }
            Choice("Default for all cards", listOf("none" to "No sound") + SfxSynth.NAMES, project.sfx) { onProject(project.copy(sfx = it)) }
            LabeledSlider("Sound volume", project.sfv.toFloat(), 0f..1f) { onProject(project.copy(sfv = it.toDouble())) }
            val chosen = SfxSynth.nameFor(card, project)
            OutlinedButton(onClick = { chosen?.let { sfx.play(it, project.sfv.toFloat()) } }, enabled = chosen != null) {
                Text("Play this card's sound")
            }
            Hint("Sounds play in the preview and are mixed into the exported video with the voiceover.")
        }

        Panel("Transitions", startOpen = false, hint = "Between cards") {
            Choice("Transition", TRANSITIONS, project.trans) { onProject(project.copy(trans = it)) }
            LabeledSlider("Transition length (s)", project.td.toFloat(), 0.2f..1.5f) { onProject(project.copy(td = it.toDouble())) }
        }

        Panel("Shine", startOpen = false, hint = "Moving light on panels") {
            Choice("Where", listOf("bars" to "Panels only", "all" to "Whole card", "off" to "Off"), project.ls) { onProject(project.copy(ls = it)) }
            LabeledSlider("Strength", project.lsi.toFloat(), 0.1f..1f) { onProject(project.copy(lsi = it.toDouble())) }
            LabeledSlider("Seconds between sweeps", project.lsp.toFloat(), 1f..6f, 1) { onProject(project.copy(lsp = it.toDouble())) }
        }
    }
}
