package com.zch.studio.data

import com.zch.studio.model.Project
import kotlinx.serialization.json.Json
import java.io.File

/**
 * Saves the project as JSON in the app's private storage.
 * Unknown fields are ignored, so projects exported from the WebView app import directly.
 */
class ProjectStore(private val file: File) {

    private val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    fun load(): Project =
        runCatching { json.decodeFromString<Project>(file.readText()) }
            .getOrDefault(Project())

    fun save(project: Project) {
        file.writeText(json.encodeToString(Project.serializer(), project))
    }

    /** Parses an exported WebView project, saves it and returns it. Throws if the file is not valid. */
    fun importOld(text: String): Project {
        val project = json.decodeFromString<Project>(text)
        if (project.cards.isEmpty()) throw IllegalArgumentException("No cards in file")
        save(project)
        return project
    }
}
