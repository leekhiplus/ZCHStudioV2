package com.zch.studio.model

import kotlinx.serialization.Serializable

/** Whole project: slides plus output and ticker settings. */
@Serializable
data class Project(
    val cards: List<NewsCard> = listOf(NewsCard()),
    val sel: Int = 0,
    val asp: String = "16:9",
    val res: Int = 720,
    val fps: Int = 30,
    val trans: String = "cross",
    val td: Double = 0.6,
    val endm: String = "voice",
    val tickOn: Int = 1,
    val tick: String = "بریکنگ نیوز • ZCH NEWS • Zafar Cricket Hub • تازہ ترین خبریں",
    val tickSpd: Double = 120.0,
    val tickC: String = "#ffffff",
    val tickBg: String = "#c8102e",
    val chan: String = "ZAFAR CRICKET HUB",
    val lpos: String = "tr",
    val lsz: Double = 0.14,
    val lop: Double = 0.9,
)

/** Helpers that return a new Project. The data stays immutable for Compose. */
fun Project.replaceCard(index: Int, card: NewsCard): Project =
    copy(cards = cards.mapIndexed { i, c -> if (i == index) card else c })

fun Project.addCard(): Project {
    val start = cards.lastOrNull()?.e ?: 0.0
    return copy(cards = cards + NewsCard(s = start, e = start + 5.0), sel = cards.size)
}

fun Project.deleteCard(index: Int): Project {
    if (cards.size <= 1) return copy(cards = listOf(NewsCard()), sel = 0)
    val rest = cards.filterIndexed { i, _ -> i != index }
    return copy(cards = rest, sel = index.coerceAtMost(rest.size - 1))
}
