package com.zch.studio.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.text.KeyboardOptions
import com.zch.studio.gemini.CardText
import com.zch.studio.gemini.GeminiClient
import com.zch.studio.gemini.GeminiModels
import com.zch.studio.gemini.SecureKey
import com.zch.studio.gemini.VoiceBuilder
import com.zch.studio.gemini.withDrafts
import com.zch.studio.model.Project

/**
 * "Paste news and create cards" of the Cards tab. Cards can be made without any AI by splitting the text into
 * sentences, or by Gemini, and one voiceover for the whole video can be made in the same step.
 */
@Composable
fun NewsSection(project: Project, onProject: (Project) -> Unit) {
    val context = LocalContext.current
    val latest by rememberUpdatedState(project)
    val save by rememberUpdatedState(onProject)
    var open by remember { mutableStateOf(false) }
    var news by remember { mutableStateOf("") }
    var most by remember { mutableStateOf("6") }
    var useAi by remember { mutableStateOf(false) }
    var withVoice by remember { mutableStateOf(false) }
    var replace by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }

    fun create() {
        val text = news.trim()
        if (text.isEmpty()) { message = "Paste the news text first."; return }
        val count = (most.toIntOrNull() ?: 6).coerceIn(1, 12)
        val key = SecureKey.load(context)
        if ((useAi || withVoice) && key.isEmpty()) { message = "Save your Gemini API key in the Voice tab first."; return }
        busy = true
        message = if (useAi) "Asking Gemini to prepare the cards..." else "Creating cards..."
        val model = latest.tm
        val app = context.applicationContext
        val ai = useAi
        val voice = withVoice
        val swap = replace
        val warning = if (ai) " AI can make mistakes: check every name and number." else ""
        background({
            val drafts = if (ai) GeminiClient.newsToCards(text, count, model, key) else CardText.localDrafts(text, count)
            if (drafts.isEmpty()) throw IllegalArgumentException("No cards could be made from this text.")
            drafts
        }) { result ->
            result.onSuccess { drafts ->
                val made = latest.withDrafts(drafts, swap)
                save(made)
                if (!voice) {
                    busy = false
                    message = "Created ${drafts.size} cards.$warning"
                } else {
                    message = "Generating one voiceover..."
                    background({ VoiceBuilder.generateAll(app, made, key) { s -> onMain { message = s } } }) { spoken ->
                        busy = false
                        spoken.onSuccess { v ->
                            save(latest.copy(cards = v.cards, audioName = v.audioName, audioSec = v.audioSec))
                            message = "Done: ${drafts.size} cards with one voiceover.$warning"
                        }.onFailure { message = "Cards created, but the voiceover failed. " + (it.message ?: "") }
                    }
                }
            }.onFailure {
                busy = false
                message = "Could not create cards: " + (it.message ?: "")
            }
        }
    }

    Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
            (if (open) "\u25BE " else "\u25B8 ") + "Paste news and create cards",
            color = AccentColor,
            modifier = Modifier.fillMaxWidth().clickable { open = !open }.padding(vertical = 8.dp),
        )
        if (open) {
            OutlinedTextField(
                value = news,
                onValueChange = { news = it },
                label = { Text("Paste the full news text here") },
                minLines = 5,
                maxLines = 12,
                modifier = Modifier.fillMaxWidth(),
            )
            OutlinedTextField(
                value = most,
                onValueChange = { most = it.filter { c -> c.isDigit() }.take(2) },
                label = { Text("Max cards") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth(),
            )
            SwitchRow("Use Gemini to write Urdu headlines, summaries and scripts", useAi) { useAi = it }
            if (useAi) {
                Caption("Gemini text model")
                Chips(GeminiModels.TEXT, project.tm) { onProject(project.copy(tm = it)) }
                OutlinedTextField(
                    value = project.tm,
                    onValueChange = { onProject(project.copy(tm = it.trim())) },
                    label = { Text("Other model name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            SwitchRow("Generate one voiceover for the whole video", withVoice) { withVoice = it }
            SwitchRow("Replace the existing cards", replace) { replace = it }
            Button(onClick = { create() }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("Create cards") }
            if (message.isNotEmpty()) Text(message, style = MaterialTheme.typography.bodySmall)
        }
    }
}
