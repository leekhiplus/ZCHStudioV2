package com.zch.studio.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.awaitTouchSlopOrCancellation
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.foundation.gestures.drag
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zch.studio.audio.SfxSynth
import com.zch.studio.model.NewsCard
import com.zch.studio.model.Project
import kotlin.math.max
import kotlin.math.min

private val TRACKS = listOf("Cards", "Pictures", "Voice", "Sound", "Overlay", "Captions", "Ticker", "Logo")
private val LABEL_WIDTH = 64.dp
private val RULER_HEIGHT = 26.dp
private val TRACK_HEIGHT = 32.dp

private val CARD_COLOR = Color(0xFF3F6AD8)
private val SELECTED_COLOR = Color(0xFFF5C518)
private val PICTURE_COLORS = listOf(Color(0xFF2E7D6B), Color(0xFF3C9C86))
private val VOICE_COLOR = Color(0xFF8E44AD)
private val SOUND_COLOR = Color(0xFFD35400)
private val TAG_COLOR = Color(0xFFC0392B)
private val BAR_COLOR = Color(0xFF8E2A22)
private val CAPTION_COLOR = Color(0xFF16A085)
private val TICKER_COLOR = Color(0xFF7F8C8D)
private val LOGO_COLOR = Color(0xFF95A5A6)
private val PLAYHEAD_COLOR = Color(0xFFFF3B30)

/** A card being changed by a long-press drag. mode 0 = start edge, 1 = end edge, 2 = whole card. */
private data class CardDrag(val index: Int, val mode: Int, val s0: Double, val e0: Double, val delta: Float)

private fun snap(v: Double) = Math.round(v * 10) / 10.0

private fun applyDrag(c: NewsCard, d: CardDrag): NewsCard {
    val delta = d.delta.toDouble()
    return when (d.mode) {
        0 -> c.copy(s = snap(d.s0 + delta).coerceIn(0.0, d.e0 - 0.3), e = d.e0)
        1 -> c.copy(s = d.s0, e = max(d.s0 + 0.3, snap(d.e0 + delta)))
        else -> {
            val s = max(0.0, snap(d.s0 + delta))
            c.copy(s = s, e = s + (d.e0 - d.s0))
        }
    }
}

/**
 * Tracks for cards, pictures, voice, sounds, overlays, captions, ticker and logo along one time ruler.
 * Tap to jump, drag the ruler to scrub, long-press a card bar and drag to move it or change its start or end.
 */
@Composable
fun MultiTrackTimeline(
    project: Project,
    total: Float,
    time: Float,
    playing: Boolean,
    onSeek: (Float) -> Unit,
    onSelect: (Int) -> Unit,
    onCardsChange: (List<NewsCard>) -> Unit,
    tall: Boolean,
    onTall: () -> Unit,
) {
    val density = LocalDensity.current
    val hScroll = rememberScrollState()
    val vScroll = rememberScrollState()
    var viewportPx by remember { mutableIntStateOf(0) }
    var zoom by remember { mutableFloatStateOf(1f) }
    var dragState by remember { mutableStateOf<CardDrag?>(null) }

    val seek by rememberUpdatedState(onSeek)
    val select by rememberUpdatedState(onSelect)
    val commit by rememberUpdatedState(onCardsChange)
    val cardsNow by rememberUpdatedState(project.cards)
    val selectedNow by rememberUpdatedState(project.sel)
    var nudge by remember { mutableFloatStateOf(0f) }

    val span = max(total, 1f)
    // zoom 0 fits the whole video in the window; otherwise 40 dp per second times the zoom, and the timeline scrolls.
    val basePx = with(density) { 40.dp.toPx() }
    val pps = if (zoom == 0f) (if (viewportPx > 0) viewportPx / span else 40f) else basePx * zoom
    val widthDp = with(density) { max(span * pps, viewportPx.toFloat()).toDp() }
    val trackPx = with(density) { TRACK_HEIGHT.toPx() }
    val rulerPx = with(density) { RULER_HEIGHT.toPx() }
    val labelPx = with(density) { 11.sp.toPx() }
    val edgePx = with(density) { 18.dp.toPx() }

    val live = dragState?.let { d -> project.cards.mapIndexed { i, c -> if (i == d.index) applyDrag(c, d) else c } } ?: project.cards
    val labelColor = MaterialTheme.colorScheme.onSurfaceVariant.toArgb()

    // While playing, keep the playhead in view.
    LaunchedEffect(playing, (time * 5).toInt(), zoom) {
        if (playing && viewportPx > 0) {
            val x = (time * pps).toInt()
            if (x < hScroll.value || x > hScroll.value + viewportPx * 0.85f) {
                hScroll.scrollTo((x - viewportPx * 0.15f).toInt().coerceAtLeast(0))
            }
        }
    }

    // The arrow buttons scroll the timeline by pushing a distance here.
    LaunchedEffect(nudge) {
        if (nudge != 0f) {
            hScroll.animateScrollBy(nudge)
            nudge = 0f
        }
    }

    val textPaint = remember { android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG) }

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Text("Timeline", style = MaterialTheme.typography.labelMedium, modifier = Modifier.weight(1f))
            FilterChip(selected = tall, onClick = onTall, label = { Text(if (tall) "Short" else "Tall", style = MaterialTheme.typography.labelSmall) })
            FilterChip(selected = false, onClick = { nudge = -viewportPx * 0.6f }, label = { Text("\u25C0", style = MaterialTheme.typography.labelSmall) })
            FilterChip(selected = false, onClick = { nudge = viewportPx * 0.6f }, label = { Text("\u25B6", style = MaterialTheme.typography.labelSmall) })
            listOf(0f, 1f, 2f, 4f, 8f).forEach { z ->
                FilterChip(
                    selected = zoom == z,
                    onClick = { zoom = z },
                    label = { Text(if (z == 0f) "Fit" else "${z.toInt()}x", style = MaterialTheme.typography.labelSmall) },
                )
            }
        }

        // Time ruler. Drag to scrub.
        Row(modifier = Modifier.fillMaxWidth()) {
            Spacer(Modifier.width(LABEL_WIDTH))
            Box(
                modifier = Modifier.weight(1f).height(RULER_HEIGHT)
                    .onSizeChanged { viewportPx = it.width }
                    .horizontalScroll(hScroll),
            ) {
                Canvas(
                    modifier = Modifier.width(widthDp).height(RULER_HEIGHT)
                        .pointerInput(pps, span) {
                            detectTapGestures { o -> seek((o.x / pps).coerceIn(0f, total)) }
                        }
                        .pointerInput(pps, span) {
                            detectDragGestures { change, _ ->
                                change.consume()
                                seek((change.position.x / pps).coerceIn(0f, total))
                            }
                        },
                ) {
                    val nc = drawContext.canvas.nativeCanvas
                    textPaint.textSize = labelPx
                    textPaint.color = labelColor
                    val steps = listOf(1, 2, 5, 10, 15, 30, 60, 120, 300)
                    val step = steps.firstOrNull { it * pps >= 56f } ?: 300
                    var t = 0
                    while (t <= span) {
                        val x = t * pps
                        drawLine(Color.Gray, Offset(x, rulerPx - 8f), Offset(x, rulerPx), strokeWidth = 2f)
                        nc.drawText(clock(t.toFloat()), x + 4f, rulerPx - 10f, textPaint)
                        t += step
                    }
                    drawRect(PLAYHEAD_COLOR, Offset(time * pps - 1.5f, 0f), Size(3f, size.height))
                }
            }
        }

        // Tracks.
        Box(modifier = Modifier.fillMaxWidth().heightIn(max = if (tall) 264.dp else 130.dp).verticalScroll(vScroll)) {
            Row(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.width(LABEL_WIDTH)) {
                    TRACKS.forEach { name ->
                        Box(modifier = Modifier.height(TRACK_HEIGHT).padding(start = 8.dp), contentAlignment = Alignment.CenterStart) {
                            Text(name, style = MaterialTheme.typography.labelSmall, maxLines = 1)
                        }
                    }
                }
                Box(modifier = Modifier.weight(1f).horizontalScroll(hScroll)) {
                    Canvas(
                        modifier = Modifier.width(widthDp).height(TRACK_HEIGHT * TRACKS.size)
                            .pointerInput(pps, span) {
                                detectTapGestures { o ->
                                    val t = (o.x / pps).coerceIn(0f, total)
                                    seek(t)
                                    if (o.y < trackPx) {
                                        val i = cardsNow.indexOfLast { t >= it.s && t < it.e }
                                        if (i >= 0) select(i)
                                    }
                                }
                            }
                            .pointerInput(pps, span) {
                                // Tap a card to select it, then drag it: the edges change start or end, the middle moves the card.
                                // Dragging anywhere else scrolls the timeline.
                                awaitEachGesture {
                                    val down = awaitFirstDown(requireUnconsumed = false)
                                    val t0 = down.position.x / pps
                                    val i = cardsNow.indexOfLast { t0 >= it.s && t0 <= it.e }
                                    if (down.position.y >= trackPx || i < 0 || i != selectedNow) return@awaitEachGesture
                                    val c = cardsNow[i]
                                    val edge = edgePx / pps
                                    val mode = when {
                                        t0 - c.s < edge -> 0
                                        c.e - t0 < edge -> 1
                                        else -> 2
                                    }
                                    val moved = awaitTouchSlopOrCancellation(down.id) { ch, _ -> ch.consume() }
                                        ?: return@awaitEachGesture
                                    select(i)
                                    val startX = down.position.x
                                    dragState = CardDrag(i, mode, c.s, c.e, 0f)
                                    drag(moved.id) { ch ->
                                        ch.consume()
                                        dragState = dragState?.copy(delta = (ch.position.x - startX) / pps)
                                    }
                                    dragState?.let { d ->
                                        commit(cardsNow.mapIndexed { n, cc -> if (n == d.index) applyDrag(cc, d) else cc })
                                    }
                                    dragState = null
                                }
                            },
                    ) {
                        val nc = drawContext.canvas.nativeCanvas
                        textPaint.textSize = labelPx

                        fun bar(track: Int, s: Double, e: Double, color: Color, label: String, dark: Boolean = false, part: Int = 0, parts: Int = 1) {
                            val full = trackPx - 6f
                            val h = full / parts - (if (parts > 1) 1f else 0f)
                            val top = track * trackPx + 3f + part * full / parts
                            val x0 = (max(0.0, s) * pps).toFloat()
                            val x1 = (e * pps).toFloat()
                            if (x1 - x0 < 1f) return
                            drawRoundRect(color, Offset(x0 + 1f, top), Size(max(2f, x1 - x0 - 2f), h), CornerRadius(5f, 5f))
                            if (label.isNotEmpty()) {
                                nc.save()
                                nc.clipRect(x0 + 3f, top, x1 - 2f, top + h)
                                textPaint.color = if (dark) android.graphics.Color.BLACK else android.graphics.Color.WHITE
                                nc.drawText(label, x0 + 6f, top + h / 2 + labelPx / 3, textPaint)
                                nc.restore()
                            }
                        }

                        for (i in TRACKS.indices) {
                            if (i % 2 == 1) drawRect(Color(0x14FFFFFF), Offset(0f, i * trackPx), Size(size.width, trackPx))
                        }

                        live.forEachIndexed { i, c ->
                            val selected = i == project.sel
                            bar(0, c.s, c.e, if (selected) SELECTED_COLOR else CARD_COLOR, "${i + 1} ${c.head}", dark = selected)
                        }
                        live.forEach { c ->
                            val n = max(c.imgs.size, if (c.src.isNotEmpty()) 1 else 0)
                            if (n > 0) {
                                val seg = (c.e - c.s) / n
                                for (k in 0 until n) bar(1, c.s + k * seg, c.s + (k + 1) * seg, PICTURE_COLORS[k % 2], if (n > 1) "${k + 1}" else "")
                            }
                        }
                        if (project.audioSec > 0.0) bar(2, 0.0, min(project.audioSec, total.toDouble()), VOICE_COLOR, project.audioName)
                        live.forEach { c ->
                            val n = SfxSynth.nameFor(c, project) ?: return@forEach
                            val begin = c.s - (SfxSynth.LEAD[n] ?: 0f)
                            bar(3, begin, begin + SfxSynth.DUR.getValue(n), SOUND_COLOR, n)
                        }
                        live.forEach { c ->
                            if (c.ot != 0) bar(4, c.s + 0.35, c.e, TAG_COLOR, c.ot1, part = 0, parts = 2)
                            if (c.ol != 0) bar(4, c.s + 0.55, c.e, BAR_COLOR, "bar", part = 1, parts = 2)
                        }
                        live.forEach { c -> if (c.cap != 0 && c.vd > 0.0) bar(5, c.s, c.e, CAPTION_COLOR, "CC") }
                        if (project.tickOn != 0) bar(6, 0.0, total.toDouble(), TICKER_COLOR, project.tick.take(60))
                        if (project.logo.isNotEmpty() || project.chan.isNotBlank()) {
                            bar(7, 0.0, total.toDouble(), LOGO_COLOR, if (project.logo.isNotEmpty()) "Logo" else project.chan)
                        }
                        drawRect(PLAYHEAD_COLOR, Offset(time * pps - 1.5f, 0f), Size(3f, size.height))
                    }
                }
            }
        }
    }
}

private fun Color.toArgb(): Int = android.graphics.Color.argb(
    (alpha * 255).toInt(), (red * 255).toInt(), (green * 255).toInt(), (blue * 255).toInt(),
)
