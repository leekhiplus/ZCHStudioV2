package com.zch.studio.export

import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import com.zch.studio.audio.SfxSynth
import com.zch.studio.model.Project
import java.io.ByteArrayOutputStream
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** Mixes the voiceover (if any) and the card start sounds into one WAV file as long as the video. */
object AudioMix {

    /** First channel of an audio file as 16-bit samples, and its sample rate. For finding words in a voice. */
    fun decodeMono(file: File): Pair<ShortArray, Int> {
        val d = decode(file, Long.MAX_VALUE / 4) { false }
        val n = d.data.size / d.channels
        return ShortArray(n) { d.data[it * d.channels] } to d.rate
    }

    private class Decoded(val data: ShortArray, val rate: Int, val channels: Int)

    fun build(project: Project, voice: File?, totalSec: Float, out: File, isCancelled: () -> Boolean) {
        val decoded = if (voice != null) decode(voice, (totalSec * 1_000_000L).toLong() + 500_000L, isCancelled) else null
        val rate = decoded?.rate ?: SfxSynth.RATE
        val ch = (decoded?.channels ?: 1).coerceIn(1, 2)
        val frames = max(1, (totalSec * rate).toInt())
        val mix = ShortArray(frames * ch)

        if (decoded != null) {
            val srcCh = decoded.channels
            val n = min(frames, decoded.data.size / srcCh)
            for (f in 0 until n) for (c in 0 until ch) mix[f * ch + c] = decoded.data[f * srcCh + min(c, srcCh - 1)]
        }

        val gain = project.sfv.toFloat().coerceIn(0f, 1.5f)
        val ratio = SfxSynth.RATE.toFloat() / rate
        for (card in project.cards) {
            val name = SfxSynth.nameFor(card, project) ?: continue
            val pcm = SfxSynth.pcm(name)
            val start = ((card.s - (SfxSynth.LEAD[name] ?: 0f)) * rate).roundToInt()
            val length = (pcm.size / ratio).toInt()
            for (i in 0 until length) {
                val f = start + i
                if (f < 0 || f >= frames) continue
                val pos = i * ratio
                val i0 = pos.toInt()
                val i1 = min(i0 + 1, pcm.size - 1)
                val frac = pos - i0
                val s = (pcm[i0] * (1 - frac) + pcm[i1] * frac) * gain
                for (c in 0 until ch) {
                    val idx = f * ch + c
                    mix[idx] = (mix[idx] + s).roundToInt().coerceIn(-32768, 32767).toShort()
                }
            }
        }
        writeWav(out, mix, rate, ch)
    }

    private fun writeWav(out: File, data: ShortArray, rate: Int, channels: Int) {
        out.outputStream().buffered().use { os ->
            val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
            header.put("RIFF".toByteArray()).putInt(36 + data.size * 2).put("WAVE".toByteArray())
            header.put("fmt ".toByteArray()).putInt(16).putShort(1).putShort(channels.toShort())
            header.putInt(rate).putInt(rate * channels * 2).putShort((channels * 2).toShort()).putShort(16)
            header.put("data".toByteArray()).putInt(data.size * 2)
            os.write(header.array())
            val chunk = ByteBuffer.allocate(1 shl 16).order(ByteOrder.LITTLE_ENDIAN)
            for (s in data) {
                if (!chunk.hasRemaining()) {
                    os.write(chunk.array(), 0, chunk.position())
                    chunk.clear()
                }
                chunk.putShort(s)
            }
            os.write(chunk.array(), 0, chunk.position())
        }
    }

    /** Decodes an audio file to 16-bit PCM, up to maxUs. */
    private fun decode(file: File, maxUs: Long, isCancelled: () -> Boolean): Decoded {
        val extractor = MediaExtractor()
        var decoder: MediaCodec? = null
        try {
            extractor.setDataSource(file.absolutePath)
            val index = (0 until extractor.trackCount).firstOrNull {
                extractor.getTrackFormat(it).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true
            } ?: throw IllegalArgumentException("No audio track in this file")
            extractor.selectTrack(index)
            val format = extractor.getTrackFormat(index)
            val mime = format.getString(MediaFormat.KEY_MIME)!!
            var rate = format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            var channels = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            val bytes = ByteArrayOutputStream()

            if (mime == "audio/raw") {
                val buffer = ByteBuffer.allocate(1 shl 20)
                while (true) {
                    if (isCancelled()) throw VideoExporter.CancelledException()
                    buffer.clear()
                    val n = extractor.readSampleData(buffer, 0)
                    if (n < 0 || extractor.sampleTime > maxUs) break
                    bytes.write(buffer.array(), 0, n)
                    extractor.advance()
                }
            } else {
                val dec = MediaCodec.createDecoderByType(mime)
                decoder = dec
                dec.configure(format, null, null, 0)
                dec.start()
                val info = MediaCodec.BufferInfo()
                var inputDone = false
                var outputDone = false
                while (!outputDone) {
                    if (isCancelled()) throw VideoExporter.CancelledException()
                    if (!inputDone) {
                        val i = dec.dequeueInputBuffer(0)
                        if (i >= 0) {
                            val buf = dec.getInputBuffer(i)!!
                            val n = extractor.readSampleData(buf, 0)
                            val t = extractor.sampleTime
                            if (n < 0 || t > maxUs) {
                                dec.queueInputBuffer(i, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                inputDone = true
                            } else {
                                dec.queueInputBuffer(i, 0, n, t, 0)
                                extractor.advance()
                            }
                        }
                    }
                    val o = dec.dequeueOutputBuffer(info, 5_000L)
                    if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        val f = dec.outputFormat
                        rate = f.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                        channels = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    } else if (o >= 0) {
                        val data = dec.getOutputBuffer(o)
                        if (info.size > 0 && data != null) {
                            data.position(info.offset)
                            data.limit(info.offset + info.size)
                            val chunk = ByteArray(info.size)
                            data.get(chunk)
                            bytes.write(chunk)
                        }
                        dec.releaseOutputBuffer(o, false)
                        if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outputDone = true
                    }
                }
            }
            val raw = bytes.toByteArray()
            val shorts = ShortArray(raw.size / 2)
            ByteBuffer.wrap(raw).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().get(shorts)
            return Decoded(shorts, rate, channels)
        } finally {
            runCatching { decoder?.stop() }
            runCatching { decoder?.release() }
            runCatching { extractor.release() }
        }
    }
}
