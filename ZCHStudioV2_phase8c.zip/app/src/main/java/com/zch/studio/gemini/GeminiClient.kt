package com.zch.studio.gemini

import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import java.nio.ByteOrder

class GeminiException(message: String) : Exception(message)

/**
 * Minimal Gemini REST client: news text to card drafts, and text to speech.
 * Request shapes follow the WebView app, which worked with the gemini-3.8 models.
 * Blocking, call from a background thread.
 */
object GeminiClient {

    class Draft(val head: String, val desc: String, val script: String)

    /** 16-bit mono PCM audio and its sample rate. */
    class Pcm(val bytes: ByteArray, val rate: Int)

    private const val BASE = "https://generativelanguage.googleapis.com/v1beta/models/"

    fun newsToCards(text: String, wordsPerCard: Int, model: String, key: String): List<Draft> {
        val prompt = "You are an Urdu news editor. Turn the news text below into cards for a short news video. Make as many cards as the story needs, about one card for every $wordsPerCard words of the text, and give each card one clear point. " +
            "Use ONLY facts that are in the text and never add facts. Keep names, numbers and dates exactly as written. Write in Urdu. " +
            "For each card return \"headline\" (max 10 words), \"summary\" (max 25 words, shown on screen) and " +
            "\"script\" (natural spoken Urdu, max 45 words, read aloud). " +
            "Return only JSON like {\"cards\":[{\"headline\":\"\",\"summary\":\"\",\"script\":\"\"}]}.\n\nNEWS TEXT:\n$text"
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
            .put("generationConfig", JSONObject().put("responseMimeType", "application/json"))
        val raw = answerText(post(model, key, body))
        val parsed: Any = try {
            JSONObject(raw)
        } catch (e: Exception) {
            val braces = Regex("\\{[\\s\\S]*\\}").find(raw)?.value
            val brackets = Regex("\\[[\\s\\S]*\\]").find(raw)?.value
            try {
                if (braces != null) JSONObject(braces) else JSONArray(brackets ?: throw GeminiException("x"))
            } catch (e2: Exception) {
                throw GeminiException("Gemini did not return usable JSON. Try again.")
            }
        }
        val array = if (parsed is JSONArray) parsed else (parsed as JSONObject).optJSONArray("cards") ?: JSONArray()
        val drafts = (0 until array.length()).mapNotNull {
            val o = array.optJSONObject(it) ?: return@mapNotNull null
            val head = o.optString("headline")
            val desc = o.optString("summary")
            if (head.isEmpty() && desc.isEmpty()) null else Draft(head, desc, o.optString("script").ifEmpty { desc })
        }
        if (drafts.isEmpty()) throw GeminiException("Gemini returned no cards")
        return drafts
    }

    fun speak(text: String, model: String, voice: String, style: String, key: String): Pcm {
        val part = JSONObject().put("text", text)
        if (style.isNotBlank()) part.put("speech_metadata", JSONObject().put("style", style.trim()))
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", JSONArray().put(part))))
            .put(
                "generationConfig",
                JSONObject()
                    .put("responseModalities", JSONArray(listOf("AUDIO")))
                    .put("speechConfig", JSONObject().put("voiceConfig", JSONObject().put("voice", voice))),
            )
        val parts = parts(post(model, key, body))
        for (i in 0 until parts.length()) {
            val inline = parts.optJSONObject(i)?.optJSONObject("inlineData") ?: continue
            val data = inline.optString("data")
            if (data.isEmpty()) continue
            val mimeRate = Regex("rate=(\\d+)").find(inline.optString("mimeType"))?.groupValues?.get(1)?.toIntOrNull()
            return decodeAudio(Base64.decode(data, Base64.DEFAULT), mimeRate)
        }
        throw GeminiException("No audio came back.")
    }

    /** The answer is either a WAV file or raw 16-bit PCM. */
    private fun decodeAudio(bytes: ByteArray, mimeRate: Int?): Pcm {
        if (bytes.size > 44 && String(bytes, 0, 4, Charsets.US_ASCII) == "RIFF") {
            val bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
            var q = 12
            var rate = mimeRate ?: 24000
            var start = 44
            var end = bytes.size
            while (q + 8 <= bytes.size) {
                val id = String(bytes, q, 4, Charsets.US_ASCII)
                val size = bb.getInt(q + 4)
                if (id == "fmt " && q + 16 <= bytes.size) rate = bb.getInt(q + 12)
                if (id == "data") {
                    start = q + 8
                    end = if (size in 0..(bytes.size - start)) start + size else bytes.size
                    break
                }
                if (size < 0) break
                q += 8 + size + (size and 1)
            }
            val n = (end - start) and 1.inv()
            return Pcm(bytes.copyOfRange(start, start + n), rate)
        }
        return Pcm(bytes.copyOf(bytes.size and 1.inv()), mimeRate ?: 24000)
    }

    private fun parts(reply: JSONObject): JSONArray =
        reply.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
            ?: throw GeminiException(
                "Gemini gave no answer" +
                    (reply.optJSONObject("promptFeedback")?.optString("blockReason")?.takeIf { it.isNotEmpty() }
                        ?.let { " (blocked: $it)" } ?: ""),
            )

    /** All text parts joined, without the model's thinking parts. */
    private fun answerText(reply: JSONObject): String {
        val parts = parts(reply)
        val text = StringBuilder()
        for (i in 0 until parts.length()) {
            val p = parts.optJSONObject(i) ?: continue
            if (!p.optBoolean("thought", false)) text.append(p.optString("text"))
        }
        if (text.isEmpty()) throw GeminiException("Gemini gave an empty answer")
        return text.toString()
    }

    private fun post(model: String, key: String, body: JSONObject): JSONObject {
        val connection = URL(BASE + model.trim() + ":generateContent").openConnection() as HttpURLConnection
        try {
            connection.requestMethod = "POST"
            connection.doOutput = true
            connection.connectTimeout = 20_000
            connection.readTimeout = 180_000
            connection.setRequestProperty("Content-Type", "application/json")
            connection.setRequestProperty("x-goog-api-key", key)
            connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (code !in 200..299) throw GeminiException(errorText(code, text))
            return JSONObject(text)
        } catch (e: GeminiException) {
            throw e
        } catch (e: java.io.IOException) {
            throw GeminiException("Network problem: " + (e.message ?: "check your internet connection"))
        } finally {
            connection.disconnect()
        }
    }

    private fun errorText(code: Int, body: String): String {
        val message = runCatching { JSONObject(body).getJSONObject("error").getString("message") }.getOrNull()
        val hint = when (code) {
            400, 403 -> " Check the API key and the model name."
            404 -> " This model name was not found."
            429 -> " Quota or rate limit reached. Wait a little and try again."
            else -> ""
        }
        return "Gemini error $code: " + (message ?: "no details") + hint
    }
}
