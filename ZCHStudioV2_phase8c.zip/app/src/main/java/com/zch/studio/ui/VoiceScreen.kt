package com.zch.studio.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.zch.studio.audio.AudioImport
import com.zch.studio.gemini.CardText
import com.zch.studio.gemini.GeminiModels
import com.zch.studio.gemini.SecureKey
import com.zch.studio.gemini.VoiceBuilder
import com.zch.studio.gemini.splitCard
import com.zch.studio.model.Project
import com.zch.studio.model.replaceCard
import java.util.Locale

/** Voice tab: the same controls as the WebView app. One voiceover for the whole video, from Gemini or from your own file. */
@Composable
fun VoiceScreen(project: Project, onProject: (Project) -> Unit, player: PlayerState) {
    val context = LocalContext.current
    val latest by rememberUpdatedState(project)
    val save by rememberUpdatedState(onProject)
    var message by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        busy = true
        message = "Importing..."
        val app = context.applicationContext
        background({ AudioImport.import(app, uri) }) { result ->
            busy = false
            result.onSuccess {
                message = "Imported. Write the script of each card, then press \"Match cards to the voice\"."
                save(latest.copy(audioName = it.name, audioSec = it.seconds, cards = latest.cards.map { c -> c.copy(vd = 0.0, vw = emptyList(), wt = emptyList()) }))
            }.onFailure { message = it.message ?: "Could not import this file" }
        }
    }

    fun generate() {
        val key = SecureKey.load(context)
        if (key.isEmpty()) { message = "Paste and save your Gemini API key first."; return }
        var base = latest
        if (base.autoSplit != 0) {
            // Every card with a long script becomes as many cards as the script needs. From the end, so earlier numbers stay valid.
            var split = false
            var i = base.cards.lastIndex
            while (i >= 0) {
                if (CardText.wc(base.cards[i].script.trim()) > CardText.LONG_SCRIPT) {
                    base.splitCard(i, 32)?.let { base = it; split = true }
                }
                i--
            }
            if (split) {
                base = base.copy(sel = latest.sel.coerceIn(0, maxOf(0, base.cards.lastIndex)))
                save(base)
            }
        }
        busy = true
        message = "Starting..."
        val app = context.applicationContext
        val snapshot = base
        background({ VoiceBuilder.generateAll(app, snapshot, key) { s -> onMain { message = s } } }) { result ->
            busy = false
            result.onSuccess { v ->
                save(latest.copy(cards = v.cards, audioName = v.audioName, audioSec = v.audioSec))
                message = "Done: one voiceover, " + String.format(Locale.US, "%.1f", v.audioSec) + " s. The cards now follow the voice."
            }.onFailure { message = "Could not generate: " + (it.message ?: "") }
        }
    }

    fun matchCards() {
        busy = true
        message = "Matching the cards to the voice..."
        val app = context.applicationContext
        val snapshot = latest
        background({ VoiceBuilder.syncCards(app, snapshot) { s -> onMain { message = s } } }) { result ->
            busy = false
            result.onSuccess { v ->
                save(latest.copy(cards = v.cards))
                message = "Done: ${v.cards.size} cards matched to the voice. Check the timing and adjust it in the Timing tab if needed."
            }.onFailure { message = "Could not match the cards: " + (it.message ?: "") }
        }
    }

    ScreenColumn {
        ApiKeySection()

        Heading("Voice")
        Caption("Model")
        Chips(GeminiModels.TTS, project.gm, enabled = !busy) { onProject(project.copy(gm = it)) }
        OutlinedTextField(
            value = project.gm,
            onValueChange = { onProject(project.copy(gm = it.trim())) },
            label = { Text("Other model name") },
            singleLine = true,
            enabled = !busy,
            modifier = Modifier.fillMaxWidth(),
        )
        Caption("Voice")
        Chips(GeminiModels.VOICES.map { (name, style) -> name to "$name \u00B7 $style" }, project.gv, enabled = !busy) {
            onProject(project.copy(gv = it))
        }
        OutlinedTextField(
            value = project.gs,
            onValueChange = { onProject(project.copy(gs = it)) },
            label = { Text("Delivery style (optional)") },
            enabled = !busy,
            modifier = Modifier.fillMaxWidth(),
        )

        val index = project.sel.coerceIn(0, maxOf(0, project.cards.lastIndex))
        val card = project.cards.getOrNull(index)
        if (card != null) {
            OutlinedTextField(
                value = card.script,
                onValueChange = { onProject(project.replaceCard(index, card.copy(script = it))) },
                label = { Text("Script for card ${index + 1}") },
                minLines = 3,
                enabled = !busy,
                modifier = Modifier.fillMaxWidth(),
            )
            SwitchRow("Show the script on the card, synced with the voice", card.cap != 0) {
                onProject(project.replaceCard(index, card.copy(cap = if (it) 1 else 0)))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = {
                        val joined = listOf(card.head, card.desc).filter { it.isNotBlank() }.joinToString(" ")
                        onProject(project.replaceCard(index, card.copy(script = joined)))
                    },
                    enabled = !busy,
                ) { Text("Use headline + description") }
                OutlinedButton(
                    onClick = {
                        val split = project.splitCard(index, 32)
                        if (split == null) {
                            message = "The script is too short to split."
                        } else {
                            onProject(split)
                            message = "Split into ${split.cards.size - project.cards.size + 1} cards. Now generate one voiceover for all of them."
                        }
                    },
                    enabled = !busy,
                ) { Text("Split into cards") }
            }
        }
        SwitchRow("Auto-split a long script into several cards", project.autoSplit != 0) {
            onProject(project.copy(autoSplit = if (it) 1 else 0))
        }

        Heading("Voiceover (one track for the whole video)")
        Button(onClick = { generate() }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("Generate ONE voiceover with Gemini") }
        Caption("Or import your own voice (MP3, WAV, M4A)")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { picker.launch(arrayOf("audio/*")) }, enabled = !busy) {
                Text(if (project.audioName.isEmpty()) "Choose audio file" else "Replace audio")
            }
            OutlinedButton(onClick = { matchCards() }, enabled = !busy && project.audioName.isNotEmpty()) { Text("Match cards to the voice") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(
                onClick = {
                    card?.let { player.time = it.s.toFloat(); player.playing = true }
                },
                enabled = card != null,
            ) { Text("Play this card") }
            OutlinedButton(
                onClick = {
                    AudioImport.remove(context)
                    onProject(
                        project.copy(
                            audioName = "", audioSec = 0.0,
                            cards = project.cards.map { it.copy(vd = 0.0, vw = emptyList(), wt = emptyList()) },
                        ),
                    )
                    message = ""
                },
                enabled = !busy && project.audioName.isNotEmpty(),
            ) { Text("Delete the voiceover") }
        }
        val info = if (project.audioName.isEmpty()) {
            "No voiceover yet."
        } else {
            "Voiceover: ${project.audioName}, " + String.format(Locale.US, "%.1f", project.audioSec) + " s" +
                (if (project.cards.any { it.vd > 0.0 }) ". The cards are matched to it." else ". Press \"Match cards to the voice\" to sync the cards and the on-card script.")
        }
        Text(info, style = MaterialTheme.typography.bodySmall)
        if (message.isNotEmpty()) Text(message, style = MaterialTheme.typography.bodyMedium)

        Caption("Video ends with")
        Chips(listOf("voice" to "Audio length", "card" to "Last card"), if (project.endm == "card") "card" else "voice") {
            onProject(project.copy(endm = it))
        }
    }
}
