package com.zch.studio.ui

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.unit.dp

/** The line icons of the WebView app's bottom bar, drawn from the same SVG paths. */
object NavIcons {

    private val cache = HashMap<String, ImageVector>()

    private fun build(name: String, vararg paths: String): ImageVector = cache.getOrPut(name) {
        ImageVector.Builder(name = name, defaultWidth = 24.dp, defaultHeight = 24.dp, viewportWidth = 24f, viewportHeight = 24f)
            .apply {
                paths.forEach { d ->
                    addPath(
                        pathData = PathParser().parsePathString(d).toNodes(),
                        stroke = SolidColor(Color.White),
                        strokeLineWidth = 2f,
                        strokeLineCap = StrokeCap.Round,
                        strokeLineJoin = StrokeJoin.Round,
                    )
                }
            }
            .build()
    }

    /** Icon for a section number (the numbers of the WebView app). Text (6) uses the letters "Aa" instead. */
    fun forTab(i: Int): ImageVector = when (i) {
        0 -> build("cards", "M6 7H18A2 2 0 0 1 20 9V16A2 2 0 0 1 18 18H6A2 2 0 0 1 4 16V9A2 2 0 0 1 6 7Z", "M8 4h8")
        1 -> build("edit", "M4 20h4L19 9l-4-4L4 16z")
        8 -> build("voice", "M12 3A3 3 0 0 1 15 6V11A3 3 0 0 1 9 11V6A3 3 0 0 1 12 3Z", "M5 11a7 7 0 0 0 14 0M12 18v3")
        7 -> build("effects", "M12 3v4M12 17v4M3 12h4M17 12h4M6 6l2.5 2.5M15.5 15.5L18 18M18 6l-2.5 2.5M8.5 15.5L6 18")
        2 -> build("timing", "M12 4A8 8 0 1 1 12 20A8 8 0 1 1 12 4Z", "M12 8v4l3 2")
        3 -> build("video", "M5 6H14A2 2 0 0 1 16 8V16A2 2 0 0 1 14 18H5A2 2 0 0 1 3 16V8A2 2 0 0 1 5 6Z", "M16 10l5-2v8l-5-2")
        else -> build("brand", "M12 3l2.6 5.4 5.9.9-4.3 4.1 1 5.8-5.2-2.8-5.2 2.8 1-5.8L3.5 9.3l5.9-.9z")
    }

    val Undo: ImageVector get() = build("undo", "M9 14L4 9l5-5", "M4 9h10a6 6 0 0 1 0 12h-3")
    val Redo: ImageVector get() = build("redo", "M15 14l5-5-5-5", "M20 9H10a6 6 0 0 0 0 12h3")
}
