package com.zch.studio.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.zch.studio.export.ExportController
import com.zch.studio.model.Project
import com.zch.studio.model.outputSize
import com.zch.studio.model.totalDuration

/** Export tab: pick shape, size and frame rate, then render the project to an MP4. */
@Composable
fun ExportScreen(project: Project, onProject: (Project) -> Unit, exporter: ExportController) {
    val (w, h) = project.outputSize()
    val seconds = project.totalDuration()
    val busy = exporter.running
    val context = LocalContext.current
    val latest by rememberUpdatedState(project)
    // The export shows a progress notification. The export starts whether or not the permission is granted.
    val askNotifications = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        exporter.start(latest)
    }

    Column(
        modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("Shape", style = MaterialTheme.typography.labelMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("16:9", "9:16", "1:1").forEach { asp ->
                FilterChip(
                    selected = project.asp == asp,
                    onClick = { onProject(project.copy(asp = asp)) },
                    label = { Text(asp) },
                    enabled = !busy,
                )
            }
        }
        Text("Size (short side)", style = MaterialTheme.typography.labelMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(480, 720, 1080).forEach { res ->
                FilterChip(
                    selected = project.res == res,
                    onClick = { onProject(project.copy(res = res)) },
                    label = { Text("${res}p") },
                    enabled = !busy,
                )
            }
        }
        Text("Frame rate", style = MaterialTheme.typography.labelMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(24, 30).forEach { fps ->
                FilterChip(
                    selected = project.fps == fps,
                    onClick = { onProject(project.copy(fps = fps)) },
                    label = { Text("$fps fps") },
                    enabled = !busy,
                )
            }
        }

        Text("$w x $h, ${project.fps} fps, ${seconds.toInt()} s, MP4 (H.264)")

        if (busy) {
            LinearProgressIndicator(progress = { exporter.progress }, modifier = Modifier.fillMaxWidth())
            Text("${(exporter.progress * 100).toInt()}%")
            OutlinedButton(onClick = { exporter.cancel() }) { Text("Cancel") }
        } else {
            Button(onClick = {
                val needsAsk = Build.VERSION.SDK_INT >= 33 &&
                    ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                if (needsAsk) askNotifications.launch(Manifest.permission.POST_NOTIFICATIONS) else exporter.start(project)
            }) { Text("Export MP4") }
        }
        if (exporter.status.isNotEmpty()) {
            Text(exporter.status, style = MaterialTheme.typography.bodyMedium)
        }
        Text(
            (if (project.audioName.isEmpty()) "No voiceover. Add one in the Voice tab." else "Voiceover: ${project.audioName}") +
                "\nExport keeps running in the background. Watch the notification for progress.",
            style = MaterialTheme.typography.bodySmall,
        )
    }
}
