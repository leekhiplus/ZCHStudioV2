package com.zch.studio.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.LocalContext
import com.zch.studio.model.NewsCard
import com.zch.studio.model.Project
import com.zch.studio.render.CardRenderer
import com.zch.studio.render.FrameRenderer
import com.zch.studio.render.Fonts
import com.zch.studio.render.ImageCache

/** Live preview of one slide at 16:9, drawn by the same renderer used for export. */
@Composable
fun CardPreview(card: NewsCard, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val fonts = remember { Fonts(context) }
    val images = remember { ImageCache() }
    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .aspectRatio(16f / 9f)
            .background(Color.Black),
    ) {
        drawPreview(card, fonts, images)
    }
}

private fun DrawScope.drawPreview(card: NewsCard, fonts: Fonts, images: ImageCache) {
    val native = drawContext.canvas.nativeCanvas
    native.save()
    native.scale(size.width / 1280f, size.height / 720f)
    CardRenderer.draw(native, card, 0f, 1280, 720, fonts, images)
    native.restore()
}

/**
 * Preview of the selected card as it looks in the video, with logo and ticker.
 * Uses a moment after the entrance animation and transition have finished.
 */
@Composable
fun FramePreview(project: Project, index: Int, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val fonts = remember { Fonts(context) }
    val images = remember { ImageCache() }
    val (pw, ph) = when (project.asp) {
        "9:16" -> 720 to 1280
        "1:1" -> 720 to 720
        else -> 1280 to 720
    }
    val card = project.cards.getOrNull(index) ?: return
    val t = (card.s + maxOf(project.td, project.ad) + 0.1).coerceAtMost(card.e - 0.01).coerceAtLeast(card.s).toFloat()
    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .aspectRatio(pw.toFloat() / ph)
            .background(Color.Black),
    ) {
        val native = drawContext.canvas.nativeCanvas
        native.save()
        native.scale(size.width / pw, size.height / ph)
        FrameRenderer.drawCard(native, project, index, t, pw, ph, fonts, images)
        native.restore()
    }
}
