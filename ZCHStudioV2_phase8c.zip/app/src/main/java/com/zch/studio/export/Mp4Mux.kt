package com.zch.studio.export

import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import java.io.File
import java.nio.ByteBuffer

/** Joins a video-only MP4 and an AAC .m4a into one MP4 without re-encoding. Audio is cut at maxAudioUs. */
object Mp4Mux {

    fun combine(video: File, audio: File, out: File, maxAudioUs: Long) {
        val v = MediaExtractor()
        val a = MediaExtractor()
        var muxer: MediaMuxer? = null
        var finished = false
        try {
            v.setDataSource(video.absolutePath)
            a.setDataSource(audio.absolutePath)
            val vi = trackOf(v, "video/")
            val ai = trackOf(a, "audio/")
            v.selectTrack(vi)
            a.selectTrack(ai)
            muxer = MediaMuxer(out.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val vTrack = muxer.addTrack(v.getTrackFormat(vi))
            val aTrack = muxer.addTrack(a.getTrackFormat(ai))
            muxer.start()

            val buffer = ByteBuffer.allocate(4 * 1024 * 1024)
            val info = MediaCodec.BufferInfo()
            var vDone = false
            var aDone = false
            while (true) {
                var vt = if (vDone) Long.MAX_VALUE else v.sampleTime
                if (!vDone && vt < 0) { vDone = true; vt = Long.MAX_VALUE }
                var at = if (aDone) Long.MAX_VALUE else a.sampleTime
                if (!aDone && (at < 0 || at > maxAudioUs)) { aDone = true; at = Long.MAX_VALUE }
                if (vDone && aDone) break

                val takeVideo = vt <= at
                val source = if (takeVideo) v else a
                buffer.clear()
                val size = source.readSampleData(buffer, 0)
                if (size < 0) {
                    if (takeVideo) vDone = true else aDone = true
                    continue
                }
                val key = source.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC != 0
                info.set(0, size, source.sampleTime, if (key) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0)
                muxer.writeSampleData(if (takeVideo) vTrack else aTrack, buffer, info)
                source.advance()
            }
            muxer.stop()
            finished = true
        } finally {
            runCatching { v.release() }
            runCatching { a.release() }
            runCatching { muxer?.release() }
            if (!finished) out.delete()
        }
    }

    private fun trackOf(extractor: MediaExtractor, prefix: String): Int =
        (0 until extractor.trackCount).firstOrNull {
            extractor.getTrackFormat(it).getString(MediaFormat.KEY_MIME)?.startsWith(prefix) == true
        } ?: throw IllegalArgumentException("Missing $prefix track")
}
