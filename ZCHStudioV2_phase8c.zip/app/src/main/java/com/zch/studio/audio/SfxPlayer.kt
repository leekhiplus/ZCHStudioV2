package com.zch.studio.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack

/** Plays the card start sounds while the preview runs. */
class SfxPlayer {

    private val tracks = HashMap<String, AudioTrack>()

    private fun track(name: String): AudioTrack = tracks.getOrPut(name) {
        val pcm = SfxSynth.pcm(name)
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build(),
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(SfxSynth.RATE)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build(),
            )
            .setBufferSizeInBytes(pcm.size * 2)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
        t.write(pcm, 0, pcm.size)
        t
    }

    /** Starts the sound, optionally partway in (offsetSec). A sound that is still playing restarts. */
    fun play(name: String, volume: Float, offsetSec: Float = 0f) {
        runCatching {
            val t = track(name)
            t.stop()
            t.reloadStaticData()
            t.setVolume(volume.coerceIn(0f, 1f))
            if (offsetSec > 0f) t.playbackHeadPosition = (offsetSec * SfxSynth.RATE).toInt()
            t.play()
        }
    }

    fun stopAll() {
        tracks.values.forEach { runCatching { it.stop() } }
    }

    fun release() {
        tracks.values.forEach { runCatching { it.release() } }
        tracks.clear()
    }
}
