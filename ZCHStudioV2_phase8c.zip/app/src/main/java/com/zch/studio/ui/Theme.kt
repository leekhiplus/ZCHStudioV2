package com.zch.studio.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

/** Colours of the WebView app: black background, dark grey panels, cyan accent. */
val PanelColor = Color(0xFF141416)
val FieldColor = Color(0xFF232328)
val MutedColor = Color(0xFF9A9AA5)
val AccentColor = Color(0xFF25F4EE)

@Composable
fun ZchTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = AccentColor,
            onPrimary = Color.Black,
            primaryContainer = FieldColor,
            onPrimaryContainer = Color.White,
            secondary = AccentColor,
            onSecondary = Color.Black,
            secondaryContainer = Color(0xFF34343B),
            onSecondaryContainer = Color.White,
            tertiary = Color(0xFFFE2C55),
            background = Color.Black,
            onBackground = Color.White,
            surface = PanelColor,
            onSurface = Color.White,
            surfaceVariant = FieldColor,
            onSurfaceVariant = MutedColor,
            outline = Color(0xFF3A3A44),
            outlineVariant = Color(0xFF2A2A30),
        ),
        content = content,
    )
}
