package com.zch.studio.export

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Icon
import com.zch.studio.MainActivity

/** Notifications for video export: the ongoing progress one and the final result. */
object ExportNotification {

    private const val CHANNEL = "export"
    const val ID = 4101
    private const val DONE_ID = 4102

    fun ensureChannel(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL) == null) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "Video export", NotificationManager.IMPORTANCE_LOW),
            )
        }
    }

    private fun openApp(ctx: Context): PendingIntent = PendingIntent.getActivity(
        ctx, 0,
        Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
    )

    /** The ongoing notification shown while exporting, with a progress bar and a Cancel action. */
    fun build(ctx: Context, percent: Int, text: String): Notification {
        val cancel = PendingIntent.getService(
            ctx, 1,
            Intent(ctx, ExportService::class.java).setAction(ExportService.ACTION_CANCEL),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val cancelAction = Notification.Action.Builder(
            Icon.createWithResource(ctx, android.R.drawable.ic_menu_close_clear_cancel),
            "Cancel",
            cancel,
        ).build()
        return Notification.Builder(ctx, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_sys_upload)
            .setContentTitle("Exporting video")
            .setContentText(text)
            .setProgress(100, percent.coerceIn(0, 100), false)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(openApp(ctx))
            .addAction(cancelAction)
            .build()
    }

    fun update(ctx: Context, percent: Int, text: String) {
        ctx.getSystemService(NotificationManager::class.java).notify(ID, build(ctx, percent, text))
    }

    /** A normal notification with the result, left in the shade after the export ends. */
    fun finished(ctx: Context, text: String) {
        ensureChannel(ctx)
        val n = Notification.Builder(ctx, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_sys_upload_done)
            .setContentTitle("Video export")
            .setContentText(text)
            .setContentIntent(openApp(ctx))
            .setAutoCancel(true)
            .build()
        ctx.getSystemService(NotificationManager::class.java).notify(DONE_ID, n)
    }
}
