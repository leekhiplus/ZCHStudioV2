package com.zch.studio.audio

import com.zch.studio.model.NewsCard
import com.zch.studio.model.Project
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.random.Random

/** The card start sounds of the WebView app (mkSfx), made from maths instead of audio files. 44.1 kHz mono. */
object SfxSynth {

    const val RATE = 44100

    val NAMES = listOf(
        "whoosh" to "Whoosh", "swish" to "Swish (short)", "pop" to "Pop", "impact" to "Impact boom",
        "ding" to "Ding", "sting" to "Breaking sting", "riser" to "Riser",
    )

    /** Seconds the sound starts before the card does. */
    val LEAD = mapOf("whoosh" to 0.25f, "swish" to 0.12f, "pop" to 0f, "impact" to 0f, "ding" to 0f, "sting" to 0.05f, "riser" to 0.95f)
    val DUR = mapOf("whoosh" to 0.8f, "swish" to 0.4f, "pop" to 0.25f, "impact" to 1.1f, "ding" to 1.2f, "sting" to 0.9f, "riser" to 1.1f)

    private val cache = HashMap<String, ShortArray>()

    /** The sound a card plays: its own choice, or the project default. Null means silence. */
    fun nameFor(card: NewsCard, project: Project): String? {
        val n = if (card.sfx.isNotEmpty() && card.sfx != "def") card.sfx else project.sfx
        return n.takeIf { it != "none" && DUR.containsKey(it) }
    }

    @Synchronized
    fun pcm(name: String): ShortArray = cache.getOrPut(name) { render(name) }

    private fun render(n: String): ShortArray {
        val d = DUR.getValue(n).toDouble()
        val len = (RATE * d).roundToInt()
        val f = DoubleArray(len)
        val rnd = Random(n.hashCode())
        var y = 0.0
        var y2 = 0.0
        var ph = 0.0
        for (i in 0 until len) {
            val t = i.toDouble() / RATE
            val u = t / d
            var v = 0.0
            when (n) {
                "whoosh", "swish", "riser" -> {
                    val z = rnd.nextDouble() * 2 - 1
                    val rs = n == "riser"
                    val a = if (rs) 0.02 + 0.45 * u else 0.03 + 0.42 * sin(PI * u)
                    val e = if (rs) u * u else sin(PI * u.pow(if (n == "swish") 0.7 else 0.6))
                    y += a * (z - y)
                    y2 += a * (y - y2)
                    v = y2 * 3.4 * e
                    if (rs) {
                        ph += 2 * PI * (220 + 660 * u * u) / RATE
                        v = v * 0.7 + sin(ph) * 0.25 * u
                    }
                }
                "pop" -> {
                    ph += 2 * PI * (900 * exp(-t * 18) + 120) / RATE
                    v = sin(ph) * exp(-t * 20)
                }
                "impact" -> {
                    ph += 2 * PI * (110 * exp(-t * 3) + 38) / RATE
                    v = sin(ph) * exp(-t * 4.5) * 1.1 + (rnd.nextDouble() * 2 - 1) * exp(-t * 40) * 0.6
                }
                "ding" -> v = (sin(2 * PI * 1318 * t) + 0.5 * sin(2 * PI * 1976 * t) + 0.25 * sin(2 * PI * 2637 * t)) * exp(-t * 4.5) * 0.45
                else -> {
                    val notes = doubleArrayOf(523.0, 659.0, 784.0, 1047.0)
                    val k = min(3, floor(t / 0.12).toInt())
                    val tt = t - k * 0.12
                    val e = if (k < 3) exp(-tt * 10) else exp(-tt * 3.5)
                    val fr = notes[k]
                    v = (sin(2 * PI * fr * t) + 0.4 * sin(2 * PI * fr * 2 * t)) * e * 0.5
                }
            }
            f[i] = v
        }
        var peak = 0.0
        for (x in f) peak = maxOf(peak, kotlin.math.abs(x))
        val gain = if (peak > 0) 0.85 / peak else 1.0
        val fadeIn = (RATE * 0.004).roundToInt()
        val fadeOut = (RATE * 0.02).roundToInt()
        return ShortArray(len) { i ->
            var k = gain
            if (i < fadeIn) k *= i.toDouble() / fadeIn
            if (len - i < fadeOut) k *= (len - i).toDouble() / fadeOut
            (f[i] * k * 32767).roundToInt().coerceIn(-32768, 32767).toShort()
        }
    }
}
