package com.zch.studio.model

import kotlinx.serialization.Serializable

/** One slide. Field names match the WebView app's saved JSON so old projects import directly. */
@Serializable
data class NewsCard(
    val tpl: Int = 0,
    val head: String = "",
    val desc: String = "",
    val a: String = "",
    val b: String = "",
    val c: String = "",
    val d: String = "",
    val tc: String = "#ffffff",
    val bg: String = "#0a1630",
    val ta: Int = 0,
    val ia: Int = 0,
    val ts: Double = 1.0,
    val s: Double = 0.0,
    val e: Double = 5.0,
    val src: String = "",
    val src2: String = "",
    val imgs: List<String> = emptyList(),
    val script: String = "",
    val fu: String = "Noto Nastaliq Urdu",
    val fe: String = "Montserrat",
    val sp: Double = 1.0,
    val cap: Int = 1,
    val fit: String = "fill",
    val iz: Double = 1.0,
    val fx: Double = 50.0,
    val fy: Double = 35.0,
    val fs: Double = 1.0,
    val ot: Int = 0,
    val ot1: String = "BREAKING NEWS",
    val ot2: String = "LIVE",
    val ol: Int = 0,
    val lt: String = "",
    val olx: String = "fade",
    val olc: String = "#0e1a4a",
    val sh: Int = 1,
    val it: String = "cross",
    val pz: Int = 0,
    val sfx: String = "def",
    /** Length of the card's spoken part in seconds. 0 means no voice timing. */
    val vd: Double = 0.0,
    /** Words of the script, for captions. */
    val vw: List<String> = emptyList(),
    /** Start time of each word, seconds from the card start. */
    val wt: List<Double> = emptyList(),
)
