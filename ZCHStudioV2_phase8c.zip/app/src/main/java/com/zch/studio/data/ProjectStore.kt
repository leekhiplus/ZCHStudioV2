package com.zch.studio.data

import com.zch.studio.model.Project
import kotlinx.serialization.json.Json
import java.io.File

/**
 * Saves the project as JSON in the app's private storage.
 * Stores the project on the phone only. Nothing is imported from the old app.
 */
class ProjectStore(private val file: File) {

    private val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
        // Use the default value when a field is null or has a different type (e.g. NaN saved as null)
        coerceInputValues = true
    }

    fun load(): Project =
        runCatching { json.decodeFromString<Project>(file.readText()) }
            .getOrDefault(Project())

    fun save(project: Project) {
        file.writeText(json.encodeToString(Project.serializer(), project))
    }
}
