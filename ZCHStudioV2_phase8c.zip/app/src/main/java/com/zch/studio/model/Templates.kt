package com.zch.studio.model

/** Template names in the same order as the WebView app (index = NewsCard.tpl). */
val TEMPLATE_NAMES = listOf(
    "Classic Breaking News",
    "Professional TV Bulletin",
    "Cricket Sports News",
    "Headline News",
    "Special Report",
    "Match Score Update",
    "Player Performance",
    "Breaking News Alert",
    "Photo + Red Panel",
    "Orange Slant Panel",
    "Social Card (Reporter)",
    "Top Banner + Image",
    "Split Screen Bulletin",
    "Full Image Overlay",
    "Framed Photo Card",
    "Headline First",
    "Clean Photo (for effects)",
    "Player Duel (Side by Side)",
    "Player Stat Bars",
    "Versus Split Screen",
    "Head-to-Head Table",
    "Winner Highlight",
)
