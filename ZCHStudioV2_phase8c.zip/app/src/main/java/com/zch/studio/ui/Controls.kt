package com.zch.studio.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import com.zch.studio.model.NewsCard
import com.zch.studio.model.Project
import com.zch.studio.model.replaceCard
import com.zch.studio.render.Ctx
import com.zch.studio.render.ImageCache
import java.util.Locale

/** A scrolling screen with the standard padding and spacing. */
@Composable
fun ScreenColumn(content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        content = content,
    )
}

@Composable
fun Heading(text: String) {
    Text(text, style = MaterialTheme.typography.titleMedium)
}

@Composable
fun Caption(text: String) {
    Text(text, style = MaterialTheme.typography.labelMedium)
}

/** One-choice row of chips that scrolls sideways. Options are (value, label). */
@Composable
fun Chips(options: List<Pair<String, String>>, selected: String, enabled: Boolean = true, onSelect: (String) -> Unit) {
    Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { (value, label) ->
            FilterChip(selected = value == selected, onClick = { onSelect(value) }, label = { Text(label) }, enabled = enabled)
        }
    }
}

/** Chips for a list picked by position. */
@Composable
fun IndexChips(labels: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Chips(labels.mapIndexed { i, l -> i.toString() to l }, selected.toString()) { onSelect(it.toInt()) }
}

@Composable
fun LabeledSlider(label: String, value: Float, range: ClosedFloatingPointRange<Float>, decimals: Int = 2, onChange: (Float) -> Unit) {
    Column {
        Text("$label: " + String.format(Locale.US, "%.${decimals}f", value), style = MaterialTheme.typography.labelMedium)
        Slider(value = value.coerceIn(range.start, range.endInclusive), onValueChange = onChange, valueRange = range)
    }
}

@Composable
fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(label, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

private val SWATCHES = listOf("#ffffff", "#000000", "#f5c518", "#e10600", "#c8102e", "#0a1630", "#0e3290", "#01411c", "#25f4ee", "#1877f2")

/** Colour as #RRGGBB text with a preview and quick swatches. */
@Composable
fun ColorField(label: String, value: String, onChange: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Caption(label)
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(Modifier.size(40.dp).background(Color(Ctx.safeColor(value, 0xFF888888.toInt())), RoundedCornerShape(8.dp)))
            OutlinedTextField(
                value = value,
                onValueChange = { onChange(it.trim()) },
                singleLine = true,
                modifier = Modifier.width(150.dp),
            )
        }
        Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SWATCHES.forEach { hex ->
                Box(
                    Modifier.size(32.dp)
                        .background(Color(Ctx.safeColor(hex, 0xFF888888.toInt())), CircleShape)
                        .clickable { onChange(hex) },
                )
            }
        }
    }
}

/** Small picture preview of a data:image string. */
@Composable
fun Thumb(cache: ImageCache, src: String) {
    val bitmap = remember(src) { cache.get(src) }
    if (bitmap != null) {
        Image(
            bitmap = bitmap.asImageBitmap(),
            contentDescription = null,
            modifier = Modifier.size(56.dp),
            contentScale = ContentScale.Crop,
        )
    } else {
        Box(Modifier.size(56.dp).background(Color.DarkGray))
    }
}

/** Card number chips plus a place for card settings. Settings change the selected card. */
@Composable
fun CardSettings(project: Project, onProject: (Project) -> Unit, content: @Composable ColumnScope.(NewsCard, (NewsCard) -> Unit) -> Unit) {
    ScreenColumn {
        if (project.cards.isEmpty()) {
            Text("No cards yet. Add one in the Cards tab.")
            return@ScreenColumn
        }
        val index = project.sel.coerceIn(0, project.cards.lastIndex)
        Caption("Card")
        IndexChips(project.cards.indices.map { "${it + 1}" }, index) { onProject(project.copy(sel = it)) }
        content(project.cards[index]) { onProject(project.replaceCard(index, it)) }
    }
}

/** A number changed with -1, -0.1, +0.1 and +1 buttons. */
@Composable
fun Stepper(label: String, value: Double, onChange: (Double) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Caption(label + ": " + String.format(Locale.US, "%.1f", value))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(-1.0, -0.1, 0.1, 1.0).forEach { d ->
                OutlinedButton(
                    onClick = { onChange(Math.round((value + d) * 10) / 10.0) },
                    contentPadding = PaddingValues(horizontal = 12.dp),
                ) { Text(if (d > 0) "+$d" else "$d") }
            }
        }
    }
}
