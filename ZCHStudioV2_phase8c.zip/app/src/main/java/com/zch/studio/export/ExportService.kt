package com.zch.studio.export

import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder

/**
 * Foreground service that keeps the process alive while a video is exported.
 * The export itself runs in ExportController; this service only holds the notification
 * and passes the Cancel button on. ExportController stops it when the export ends.
 */
class ExportService : Service() {

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        ExportNotification.ensureChannel(this)
        val controller = ExportController.get(this)
        val notification = ExportNotification.build(this, (controller.progress * 100).toInt(), "Preparing...")
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(ExportNotification.ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(ExportNotification.ID, notification)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val controller = ExportController.get(this)
        if (intent?.action == ACTION_CANCEL) controller.cancel()
        if (!controller.running) stopSelf()
        return START_NOT_STICKY
    }

    companion object {
        const val ACTION_CANCEL = "com.zch.studio.export.CANCEL"
    }
}
