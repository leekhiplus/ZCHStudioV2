package com.zch.studio.model

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Undo and redo. Edits made within 0.7 s of each other (a slider drag, typing) count as one step. */
class History {
    private val past = ArrayDeque<Project>()
    private val future = ArrayDeque<Project>()
    private var lastEdit = 0L

    var canUndo by mutableStateOf(false)
        private set
    var canRedo by mutableStateOf(false)
        private set

    /** Call with the project as it was before a change. */
    fun record(before: Project) {
        val now = System.currentTimeMillis()
        if (now - lastEdit > 700) {
            past.addLast(before)
            if (past.size > 60) past.removeFirst()
        }
        lastEdit = now
        future.clear()
        refresh()
    }

    fun undo(current: Project): Project? {
        val previous = past.removeLastOrNull() ?: return null
        future.addLast(current)
        lastEdit = 0L
        refresh()
        return previous
    }

    fun redo(current: Project): Project? {
        val next = future.removeLastOrNull() ?: return null
        past.addLast(current)
        lastEdit = 0L
        refresh()
        return next
    }

    private fun refresh() {
        canUndo = past.isNotEmpty()
        canRedo = future.isNotEmpty()
    }
}
