package com.zch.studio.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import com.zch.studio.model.Project

/** Text tab: size and colours of the selected card. */
@Composable
fun TextStyleScreen(project: Project, onProject: (Project) -> Unit) {
    CardSettings(project, onProject) { card, update ->
        Heading("Text")
        LabeledSlider("Text size", card.ts.toFloat(), 0.5f..1.6f) { update(card.copy(ts = it.toDouble())) }
        ColorField("Text color", card.tc) { update(card.copy(tc = it)) }
        ColorField("Background color", card.bg) { update(card.copy(bg = it)) }
        Text(
            "Urdu text uses Noto Nastaliq Urdu and English text uses Montserrat. Both are built into the app.",
            style = MaterialTheme.typography.bodySmall,
        )
    }
}
