package com.zch.studio.gemini

import com.zch.studio.model.Project
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Finds when each word is spoken in a recording, aln() of the WebView app: speech regions are split by pauses,
 * sentence ends are pinned to real pauses, and the words in between are spread by length.
 */
object VoiceAlign {

    class Aligned(val p: ShortArray, val t: DoubleArray, val off: Double)

    private val SOFT_END = Regex("[.!?۔،,؟:;]$")
    private val BREAK_END = Regex("[۔.!؟?،,;:]$")
    private val SENTENCE_END = Regex("[۔.!؟?]$")

    /** Removes the loud click Gemini voices can leave at the very end. */
    fun clean(p: ShortArray, rate: Int): ShortArray {
        val f = Math.round(rate * 0.01).toInt()
        if (f <= 0) return p
        val n = p.size / f
        val pk = DoubleArray(n) { i ->
            var m = 0
            for (j in 0 until f) m = max(m, abs(p[i * f + j].toInt()))
            m / 32768.0
        }
        for (i in max(8, n - 120) until n) {
            if (pk[i] >= 0.6) {
                var quiet = true
                var click = false
                for (k in i - 8 until i) if (pk[k] > 0.05) quiet = false
                for (k in i until min(n, i + 25)) if (pk[k] >= 0.97) click = true
                if (quiet && click) return p.copyOfRange(0, i * f)
            }
        }
        return p
    }

    fun align(p: ShortArray, r: Int, w: List<String>): Aligned {
        val f = max(1, Math.round(r * 0.02).toInt())
        val fs = f.toDouble() / r
        val n = p.size / f
        val a = BooleanArray(n) { i ->
            var q = 0.0
            for (j in 0 until f) {
                val v = p[i * f + j] / 32768.0
                q += v * v
            }
            sqrt(q / f) > 0.012
        }
        var i0 = a.indexOf(true)
        var i1 = a.lastIndexOf(true)
        if (i0 < 0) { i0 = 0; i1 = max(0, n - 1) }
        i0 = max(0, i0 - 3)
        i1 = min(n - 1, i1 + 3)
        val t = BooleanArray(max(0, i1 - i0 + 1)) { a[i0 + it] }

        // Short gaps inside speech are not pauses.
        var i = 0
        while (i < t.size) {
            if (!t[i]) {
                var j = i
                while (j < t.size && !t[j]) j++
                if (j - i < 6) for (k in i until j) t[k] = true
                i = j
            } else {
                i++
            }
        }
        val rg = ArrayList<DoubleArray>()
        i = 0
        while (i < t.size) {
            if (t[i]) {
                var j = i
                while (j < t.size && t[j]) j++
                rg.add(doubleArrayOf(i * fs, j * fs))
                i = j
            } else {
                i++
            }
        }
        if (rg.isEmpty()) rg.add(doubleArrayOf(0.0, max(fs, t.size * fs)))

        val cs = DoubleArray(rg.size + 1)
        for (k in rg.indices) cs[k + 1] = cs[k] + rg[k][1] - rg[k][0]
        val regions = rg.size
        val speechLen = if (cs[regions] != 0.0) cs[regions] else fs
        val nw = w.size

        fun toTime(u: Double): Double {
            for (k in 0 until regions) if (u < cs[k + 1]) return rg[k][0] + max(0.0, u - cs[k])
            return rg[regions - 1][1]
        }

        val weights = w.map { it.length + (if (SOFT_END.containsMatchIn(it)) 2 else 0) }
        val cw = DoubleArray(nw + 1)
        weights.forEachIndexed { k, x -> cw[k + 1] = cw[k] + x }
        val totalWeight = if (cw[nw] != 0.0) cw[nw] else 1.0

        val bs = ArrayList<Int>()
        for (k in 1 until nw) if (BREAK_END.containsMatchIn(w[k - 1])) bs.add(k)
        val bn = bs.size
        val bu = DoubleArray(bn) { cw[bs[it]] / totalWeight * speechLen }
        val bk = DoubleArray(bn) { if (SENTENCE_END.containsMatchIn(w[bs[it] - 1])) 0.8 else 0.35 }
        val dp = Array(bn + 1) { DoubleArray(regions) }
        val ch = Array(bn + 1) { IntArray(regions) }
        for (b in 1..bn) {
            dp[b][0] = dp[b - 1][0] + bk[b - 1]
            ch[b][0] = 2
        }
        for (b in 1..bn) for (j in 1 until regions) {
            var v = dp[b][j - 1]
            var c = 0
            val gap = rg[j][0] - rg[j - 1][1]
            val m = dp[b - 1][j - 1] + abs(cs[j] - bu[b - 1]) - 0.5 * min(0.5, gap)
            if (m < v) { v = m; c = 1 }
            val s2 = dp[b - 1][j] + bk[b - 1]
            if (s2 < v) { v = s2; c = 2 }
            dp[b][j] = v
            ch[b][j] = c
        }

        val anchors = ArrayList<DoubleArray>()
        anchors.add(doubleArrayOf(0.0, 0.0))
        run {
            var b = bn
            var j = regions - 1
            val found = ArrayList<DoubleArray>()
            while (b > 0 && j > 0) {
                when (ch[b][j]) {
                    0 -> j--
                    1 -> { found.add(doubleArrayOf(bs[b - 1].toDouble(), cs[j])); b--; j-- }
                    else -> b--
                }
            }
            found.reverse()
            anchors.addAll(found)
        }
        anchors.add(doubleArrayOf(nw.toDouble(), speechLen))

        val times = DoubleArray(nw)
        for (q in 0 until anchors.size - 1) {
            val k1 = anchors[q][0].toInt()
            val u1 = anchors[q][1]
            val k2 = anchors[q + 1][0].toInt()
            val u2 = anchors[q + 1][1]
            val dw = (cw[k2] - cw[k1]).let { if (it == 0.0) 1.0 else it }
            for (k in k1 until k2) times[k] = CardText.r2(toTime(u1 + (cw[k] - cw[k1]) / dw * (u2 - u1)))
        }
        return Aligned(p.copyOfRange(i0 * f, min(p.size, (i1 + 1) * f)), times, i0 * fs)
    }

    /** Sets every card's start, end and word times from the word times of one voiceover, applyTimes() of the WebView app. */
    fun applyTimes(project: Project, times: List<Double>, counts: List<Int>, words: List<String>, total: Double): Project {
        var a = 0
        val starts = counts.map { n ->
            val s = if (a != 0) max(0.0, times[a] - 0.12) else 0.0
            a += n
            s
        }
        var k = 0
        val cards = project.cards.mapIndexed { i, c ->
            val n = counts[i]
            val s = CardText.r2(starts[i])
            val e0 = if (i < counts.size - 1) starts[i + 1] else total
            val e = CardText.r2(max(e0, starts[i] + 0.8))
            val updated = c.copy(
                s = s, e = e,
                vw = words.subList(k, k + n),
                wt = times.subList(k, k + n).map { CardText.r2(max(0.0, it - starts[i])) },
                vd = CardText.r2(e - s),
            )
            k += n
            updated
        }
        return project.copy(cards = cards)
    }
}
