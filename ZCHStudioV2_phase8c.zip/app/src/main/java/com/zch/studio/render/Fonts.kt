package com.zch.studio.render

import android.content.Context
import android.graphics.Typeface

/**
 * Fonts used by the renderer.
 * Latin text uses Poppins (bundled in assets/fonts).
 * Urdu uses assets/fonts/NotoNastaliqUrdu.ttf if you add it, otherwise the system Arabic font.
 */
class Fonts(context: Context) {
    val latinBold: Typeface = load(context, "fonts/Poppins-Bold.ttf") ?: Typeface.create("sans-serif", Typeface.BOLD)
    val latinRegular: Typeface = load(context, "fonts/Poppins-Regular.ttf") ?: Typeface.create("sans-serif", Typeface.NORMAL)

    private val nastaliq: Typeface? = load(context, "fonts/NotoNastaliqUrdu.ttf")
    val urdu: Typeface = nastaliq ?: Typeface.create("sans-serif", Typeface.BOLD)

    /** Nastaliq needs taller lines than other Urdu fonts. */
    val urduLineFactor: Float = if (nastaliq != null) 2.4f else 1.8f

    private fun load(context: Context, path: String): Typeface? =
        runCatching { Typeface.createFromAsset(context.assets, path) }.getOrNull()
}
