package com.zch.studio.render

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Path
import com.zch.studio.model.NewsCard
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Draws one slide. Ported from the WebView app's CARD() function.
 * Phase 2a: templates 0 to 7. Phase 2b: templates 8 to 21.
 * Transitions, ticker and logo live in FrameRenderer. Still to come: lower third, the shine effect (SHB).
 */
object CardRenderer {

    private val RED = Color.parseColor("#c8102e")
    private val YELLOW = Color.parseColor("#f5c518")
    private val NAVY = Color.parseColor("#0a1630")
    private val WHITE = Color.WHITE
    private val SOFT = Color.parseColor("#e6e6e6")
    private val PALE = Color.parseColor("#c9d6ff")
    private val ALERT = Color.parseColor("#e10600")
    private val CYAN = Color.parseColor("#25f4ee")
    private val PANEL = Color.argb(235, 8, 16, 40)
    private val SCRIM = Color.argb(184, 0, 0, 0)
    private fun white(a: Float) = Color.argb((a * 255).toInt(), 255, 255, 255)
    private fun numv(s: String): Float = s.filter { it.isDigit() || it == '.' }.toFloatOrNull() ?: 0f

    /**
     * Draws the card at time t (seconds into the card) onto a W x H canvas.
     * tickH: height the news ticker will take at the bottom (0 until the ticker is ported).
     * animate: play the text entrance animation (off for still previews).
     * adDur: entrance animation length in seconds.
     */
    fun draw(
        canvas: Canvas, card: NewsCard, t: Float, width: Int, height: Int,
        fonts: Fonts, images: ImageCache, tickH: Float = 0f, animate: Boolean = false, adDur: Float = 0.7f,
        shineMode: String = "bars", shineAlpha: Float = 0.5f, shinePeriod: Float = 2.4f,
    ) {
        val s = min(width, height) / 720f
        val h = height.toFloat()
        // Extra bars some templates reserve at the bottom (footer for 10, coloured strip for 11 to 15).
        val footer = if (card.tpl == 10) 0.07f * h else 0f
        val strip = if (card.tpl in 11..15) 0.06f * h else 0f
        val b = h - tickH - footer - strip
        // With captions on, the spoken words replace the description.
        val shown = if (card.cap != 0 && card.vd > 0.0 && card.vw.isNotEmpty()) card.copy(desc = "") else card
        val x = Ctx(canvas, width.toFloat(), h, s, shown, t, fonts, images, b, adDur, animate, shineMode, shineAlpha, shinePeriod)
        x.rect(0f, 0f, x.W, x.H, x.bgc)
        when (card.tpl) {
            0 -> t0(x)
            1 -> t1(x)
            2 -> t2(x)
            3 -> t3(x)
            4 -> t4(x)
            5 -> t5(x)
            6 -> t6(x)
            7 -> t7(x)
            8 -> t8(x)
            9 -> t9(x)
            10 -> t10(x, footer)
            11 -> t11(x)
            12 -> t12(x)
            13 -> t13(x)
            14 -> t14(x)
            15 -> t15(x)
            16 -> t16(x)
            17 -> t17(x)
            18 -> t18(x)
            19 -> t19(x)
            20 -> t20(x)
            21 -> t21(x)
            else -> t7(x)
        }
    }

    private fun isLandscape(x: Ctx): Boolean = x.W >= x.H * 0.9f

    /** 0: Classic breaking news. Picture on top, red band with headline and description. */
    private fun t0(x: Ctx) = with(x) {
        val ih = B * 0.52f * card.fs.toFloat()
        image(0f, 0f, W, ih)
        rect(0f, ih, W, B * 0.28f, RED)
        shb(0f, ih, W, B * 0.28f)
        rect(0f, ih, W, 6 * S, YELLOW)
        label("BREAKING NEWS", 0.03f * W, 0.03f * B, 260 * S, 48 * S, RED, WHITE)
        text(card.head, 0.04f * W, ih + 0.025f * B, 0.92f * W, 50f, tc)
        text(card.desc, 0.04f * W, ih + B * 0.29f, 0.92f * W, 28f, WHITE, bold = false)
    }

    /** 1: Professional TV bulletin. Blue header, picture in a frame below. */
    private fun t1(x: Ctx) = with(x) {
        rect(0f, 0f, W, B * 0.2f, Color.parseColor("#0d2a6b"))
        shb(0f, 0f, W, B * 0.2f)
        rect(0f, B * 0.2f, W, 5 * S, YELLOW)
        text(card.head, 0.04f * W, 0.03f * B, 0.92f * W, 44f, tc)
        val ih = B * 0.4f * card.fs.toFloat()
        image(0.06f * W, B * 0.24f, 0.88f * W, ih)
        text(card.desc, 0.06f * W, B * 0.27f + ih, 0.88f * W, 28f, WHITE, bold = false)
    }

    /** 2: Cricket sports news. Two team badges, VS, score box. */
    private fun t2(x: Ctx) = with(x) {
        gradient(0f, 0f, W, H, NAVY, Color.parseColor("#16398a"))
        image(0f, 0f, W, B * 0.38f)
        val r = min(W, H) * 0.075f
        flag(card.a, W * 0.25f, B * 0.46f, r)
        flag(card.b, W * 0.75f, B * 0.46f, r)
        centerText("VS", W / 2f, B * 0.46f, 44 * S, YELLOW)
        val hh = text(card.head, 0.04f * W, B * 0.58f, 0.92f * W, 42f, tc)
        val py = B * 0.58f + hh
        rect(0.05f * W, py + 0.01f * B, 0.9f * W, 0.2f * B, Color.BLACK, radius = 16 * S, alpha = 115)
        shb(0.05f * W, py + 0.01f * B, 0.9f * W, 0.2f * B)
        text(card.c, 0.06f * W, py + 0.015f * B, 0.88f * W, 40f, YELLOW)
        text(card.d, 0.06f * W, py + 0.11f * B, 0.88f * W, 26f, WHITE, bold = false)
    }

    /** 3: Headline news. Picture on the left (landscape) or top (portrait), text beside or below. */
    private fun t3(x: Ctx) = with(x) {
        val land = isLandscape(this)
        val tx: Float
        val ty: Float
        val tw: Float
        if (land) {
            image(0f, 0f, W * 0.5f, B)
            rect(W * 0.5f, 0f, 8 * S, B, RED)
            tx = 0.54f * W; ty = 0.08f * B; tw = 0.42f * W
        } else {
            image(0f, 0f, W, B * 0.5f)
            rect(0f, B * 0.5f, W, 8 * S, RED)
            tx = 0.05f * W; ty = B * 0.54f; tw = 0.9f * W
        }
        val hh = text(card.head, tx, ty, tw, 48f, tc)
        text(card.desc, tx, ty + hh + 0.02f * B, tw, 26f, WHITE, bold = false)
    }

    /** 4: Special report. Full picture with a dark panel and a SPECIAL REPORT label. */
    private fun t4(x: Ctx) = with(x) {
        image(0f, 0f, W, B)
        val w = 0.9f * W
        val h1 = textHeight(card.head, w, 52f)
        val h2 = textHeight(card.desc, w, 26f, bold = false)
        val ph = h1 + h2 + 64 * S + 0.02f * B
        val py = B - ph - 0.03f * B
        rect(0.03f * W, py, 0.94f * W, ph, Color.argb(235, 8, 16, 40), radius = 14 * S)
        label("SPECIAL REPORT", 0.05f * W, py + 10 * S, 280 * S, 46 * S, YELLOW, NAVY)
        text(card.head, 0.05f * W, py + 60 * S, w, 52f, tc)
        text(card.desc, 0.05f * W, py + 60 * S + h1, w, 26f, SOFT, bold = false)
    }

    /** 5: Match score update. Gradient background, flags, big score. */
    private fun t5(x: Ctx) = with(x) {
        gradient(0f, 0f, W, H, NAVY, Color.parseColor("#1b3a8c"), diagonal = true)
        label("MATCH UPDATE", 0.04f * W, 0.03f * B, 260 * S, 46 * S, RED, WHITE)
        text(card.head, 0.04f * W, 0.12f * B, 0.92f * W, 34f, tc)
        val r = min(W, H) * 0.11f
        flag(card.a, W * 0.2f, B * 0.45f, r)
        flag(card.b, W * 0.8f, B * 0.45f, r)
        text(card.c, 0.3f * W, B * 0.37f, 0.4f * W, 80f, YELLOW)
        text(card.d, 0.05f * W, B * 0.7f, 0.9f * W, 32f, WHITE)
        text(card.desc, 0.05f * W, B * 0.8f, 0.9f * W, 24f, PALE, bold = false)
    }

    /** 6: Player performance. Photo, name, stat box, description. */
    private fun t6(x: Ctx) = with(x) {
        val land = isLandscape(this)
        if (land) image(0f, 0f, W * 0.42f, B) else image(0f, 0f, W, B * 0.42f)
        val tx = if (land) 0.46f * W else 0.05f * W
        val ty = if (land) 0.06f * B else B * 0.45f
        val tw = if (land) 0.5f * W else 0.9f * W
        label("PLAYER PERFORMANCE", tx, ty, min(tw, 340 * S), 42 * S, RED, WHITE)
        var y = ty + 52 * S
        y += text(card.a, tx, y, tw, 56f, YELLOW)
        y += text(card.b, tx, y, tw, 30f, WHITE, bold = false)
        rect(tx, y + 6 * S, tw, 0.17f * B, Color.argb(26, 255, 255, 255), radius = 14 * S)
        shb(tx, y + 6 * S, tw, 0.17f * B)
        text(card.c, tx, y + 10 * S, tw, 34f, tc)
        text(card.d, tx, y + 0.085f * B, tw, 30f, tc, bold = false)
        text(card.head, tx, y + 0.2f * B, tw, 28f, PALE, bold = false)
    }

    /** 7: Breaking news alert. Blinking alert bar, animated stripes, headline below the picture. */
    private fun t7(x: Ctx) = with(x) {
        val has = hasImage
        val w = 0.9f * W
        val h1 = textHeight(card.head, w, 60f)
        val h2 = textHeight(card.desc, w, 30f, bold = false)
        val top = 0.24f * B + 5 * S
        val ph = if (has) min(h1 + h2 + 0.06f * B, B - top - 0.2f * B) else 0f
        val py = if (has) B - ph else top
        if (has) {
            image(0f, 0f, W, py)
            rect(0f, py, W, B - py, bgc)
        }
        // Moving stripes over the lower area
        c.save()
        c.clipRect(0f, py, W, B)
        val gap = 170 * S
        val n = ceil((W + H * 0.4f) / gap).toInt() + 1
        val stripe = Path()
        for (i in 0 until n) {
            val sx = (i * gap + t * 70 * S) % (n * gap) - H * 0.4f
            stripe.reset()
            stripe.moveTo(sx, 0f)
            stripe.lineTo(sx + 60 * S, 0f)
            stripe.lineTo(sx + 60 * S - H * 0.4f, B)
            stripe.lineTo(sx - H * 0.4f, B)
            stripe.close()
            val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
            paint.color = Color.argb(20, 255, 255, 255)
            c.drawPath(stripe, paint)
        }
        c.restore()
        rect(0f, 0.1f * B, W, 0.14f * B, Color.parseColor("#0a0a0a"))
        shb(0f, 0.1f * B, W, 0.14f * B)
        val blink = (255 * (0.65f + 0.35f * abs(sin(t * 5f)))).toInt()
        label("BREAKING NEWS ALERT", 0.05f * W, 0.115f * B, 0.9f * W, 0.11f * B, RED, WHITE, alpha = blink)
        rect(0f, 0.24f * B, W, 5 * S, YELLOW)
        val ty = if (has) py + 0.03f * B else 0.3f * B
        val hh = text(card.head, 0.05f * W, ty, w, 60f, tc)
        text(card.desc, 0.05f * W, ty + hh + 0.02f * B, w, 30f, WHITE, bold = false)
    }

    // ---------- Phase 2b: templates 8 to 21 ----------

    /** 8: Photo plus red panel. Full picture, BREAKING / NEWS tabs, headline panel. */
    private fun t8(x: Ctx) = with(x) {
        val land = isLandscape(this)
        image(0f, 0f, W, B)
        val bx = 0.03f * W
        val by = 0.04f * B
        val bh = 62 * S
        para(bx, by, 200 * S, bh, 14 * S, Color.parseColor("#e11d1d"), WHITE, 4 * S)
        centerText("BREAKING", bx + 107 * S, by + bh / 2, bh * 0.52f, WHITE, italic = true)
        para(bx + 180 * S, by + bh * 0.3f, 130 * S, bh * 0.85f, 14 * S, Color.parseColor("#1f56d6"), WHITE, 4 * S)
        centerText("NEWS", bx + 250 * S, by + bh * 0.72f, bh * 0.5f, WHITE, italic = true)
        val pw = if (land) 0.6f * W else 0.92f * W
        val pa = pw - 50 * S
        val ph = textHeight(card.head, pa, 50f) + 40 * S
        val py = min(B * (if (land) 0.36f else 0.42f), B - ph - 0.1f * B)
        para(0.04f * W, py, pw, ph, 16 * S, bgc, WHITE, 4 * S)
        shb(0.04f * W, py, pw, ph)
        text(card.head, 0.04f * W + 24 * S, py + 20 * S, pa, 50f, tc)
        if (card.desc.isNotBlank()) {
            val dh = textHeight(card.desc, pw - 24 * S, 26f) + 14 * S
            rect(0.04f * W, py + ph + 10 * S, pw, dh, PANEL, radius = 8 * S)
            text(card.desc, 0.04f * W + 12 * S, py + ph + 17 * S, pw - 24 * S, 26f, WHITE, bold = false)
        }
    }

    /** 9: Orange slant panel. Blue header with slanted tab, slanted text panel. */
    private fun t9(x: Ctx) = with(x) {
        val land = isLandscape(this)
        image(0f, 0f, W, B)
        val hh = 0.15f * B
        gradient(0f, 0f, W, hh, Color.parseColor("#050d2e"), Color.parseColor("#10246b"))
        shb(0f, 0f, W, hh)
        rect(0f, hh, W, 4 * S, WHITE)
        para(W * 0.2f, hh * 0.14f, W * 0.6f, hh * 0.72f, hh * 0.3f, Color.parseColor("#0a1a52"), WHITE, 3 * S)
        centerText("BREAKING NEWS", W / 2 + hh * 0.15f, hh / 2, hh * 0.5f, WHITE, italic = true)
        val px = 0.03f * W
        val pw = if (land) 0.58f * W else 0.94f * W
        val ph = if (land) 0.66f * B else 0.44f * B
        val py = if (land) 0.2f * B else B - ph - 0.04f * B
        val pa = pw - 70 * S
        val h1 = textHeight(card.head, pa, 54f)
        val h2 = textHeight(card.desc, pa, 28f, bold = false)
        val ty = py + (ph - h1 - h2) / 2
        para(px, py, pw, ph, if (land) 34 * S else 20 * S, bgc, WHITE, 5 * S)
        shb(px, py, pw, ph)
        text(card.head, px + 30 * S, ty, pa, 54f, tc)
        text(card.desc, px + 30 * S, ty + h1 + 8 * S, pa, 28f, WHITE, bold = false)
    }

    /** Small white name tag with dark text, TG() in the WebView app. */
    private fun Ctx.tag(s: String, x: Float, y: Float, w: Float, h: Float) {
        rect(x, y, w, h, WHITE)
        centerText(s, x + w / 2, y + h / 2, h * 0.5f, NAVY)
    }

    /** 10: Social card. Blue header, red band with breaking ribbons, reporter photo, big photo, footer. */
    private fun t10(x: Ctx, ft: Float) = with(x) {
        val land = isLandscape(this)
        val hh = B * 0.24f
        gradient(0f, 0f, W, hh, Color.parseColor("#06143f"), Color.parseColor("#0e3290"))
        shb(0f, 0f, W, hh)
        val h1 = textHeight(card.head, 0.92f * W, 46f)
        text(card.head, 0.04f * W, (hh - h1) / 2, 0.92f * W, 46f, tc)
        gradient(0f, hh, W, B - hh, bgc, Color.parseColor("#4a060e"))
        rect(0f, hh, W, B * 0.075f, Color.argb(89, 0, 0, 0))
        for (i in 0 until 4) {
            centerText("BREAKING NEWS", W * (0.12f + i * 0.25f), hh + B * 0.037f, B * 0.04f, white(0.35f), italic = true)
        }
        para(W * 0.26f, hh + B * 0.012f, W * 0.3f, B * 0.07f, 16 * S, WHITE, Color.BLACK, 2 * S)
        centerText("BREAKING NEWS", W * 0.41f, hh + B * 0.047f, B * 0.045f, Color.parseColor("#c8102e"), italic = true)
        para(W * 0.52f, hh + B * 0.012f, W * 0.22f, B * 0.07f, 16 * S, YELLOW, WHITE, 2 * S)
        centerText("بریکنگ نیوز", W * 0.63f, hh + B * 0.047f, B * 0.045f, NAVY)
        val y0 = B * 0.37f
        val h0 = B * 0.58f
        if (land) {
            val rx = 0.04f * W
            val rw = 0.17f * W
            val rh = h0 - 0.1f * B
            rect(rx - 4 * S, y0 - 4 * S, rw + 8 * S, rh + 8 * S, WHITE)
            image(rx, y0, rw, rh, card.src2)
            tag(card.a, rx - 4 * S, y0 + rh + 4 * S, rw + 8 * S, 0.1f * B - 4 * S)
            rect(0.24f * W - 5 * S, y0 - 5 * S, 0.38f * W + 10 * S, h0 + 10 * S, WHITE)
            image(0.24f * W, y0, 0.38f * W, h0)
            text(card.desc, 0.65f * W, y0, 0.31f * W, 34f, WHITE, leftAlign = true)
        } else {
            val ph = h0 * 0.5f
            rect(0.05f * W - 5 * S, y0 - 5 * S, 0.9f * W + 10 * S, ph + 10 * S, WHITE)
            image(0.05f * W, y0, 0.9f * W, ph)
            val ry = y0 + ph + 14 * S
            val rh = B * 0.95f - ry - 0.07f * B
            val rw = 0.3f * W
            rect(0.05f * W - 4 * S, ry - 4 * S, rw + 8 * S, rh + 8 * S, WHITE)
            image(0.05f * W, ry, rw, rh, card.src2)
            tag(card.a, 0.05f * W - 4 * S, ry + rh + 4 * S, rw + 8 * S, 0.07f * B - 4 * S)
            text(card.desc, 0.39f * W, ry, 0.56f * W, 30f, WHITE, leftAlign = true)
        }
        // Footer bar with the Facebook-style badge and the page URL in card.c
        val fy = H - ft
        rect(0f, fy, W, ft, WHITE)
        if (card.c.isNotBlank()) {
            val r = ft * 0.38f
            val size = ft * 0.45f
            val tw = measure(card.c, size)
            val sx = (W - (2 * r + 14 * S + tw)) / 2
            disc(sx + r, fy + ft / 2, r, Color.parseColor("#1877f2"))
            centerText("f", sx + r, fy + ft / 2 + r * 0.1f, size, WHITE)
            centerText(card.c, sx + 2 * r + 14 * S, fy + ft / 2, size, NAVY, align = android.graphics.Paint.Align.LEFT)
        }
    }

    /** Top banner used by templates 11 to 15 (BN0 in the WebView app). */
    private fun banner(x: Ctx, k: Int, tb: Float) = with(x) {
        val tx = card.b.ifBlank { "BREAKING NEWS" }
        when (k) {
            11 -> {
                rect(0f, 0f, W, tb, Color.parseColor("#c8102e"))
                rect(0f, tb, W, 4 * S, YELLOW)
                centerText(tx, W / 2, tb / 2, tb * 0.55f, WHITE, italic = true)
            }
            12 -> {
                rect(0f, 0f, W, tb, NAVY)
                para(W * 0.5f, tb * 0.12f, W * 0.46f, tb * 0.76f, 12 * S, ALERT, WHITE, 2 * S)
                centerText(tx, W * 0.73f + 6 * S, tb / 2, tb * 0.5f, WHITE, italic = true)
            }
            13 -> {
                rect(0f, 0f, W, tb, NAVY)
                para(W * 0.03f, tb * 0.14f, W * 0.5f, tb * 0.72f, 14 * S, ALERT)
                centerText(tx, W * 0.28f + 7 * S, tb / 2, tb * 0.5f, WHITE, italic = true)
            }
            14 -> {
                para(W * 0.2f, tb * 0.2f, W * 0.6f, tb * 0.8f, tb * 0.3f, ALERT, WHITE, 3 * S)
                centerText(tx, W / 2 + tb * 0.15f, tb * 0.6f, tb * 0.5f, WHITE, italic = true)
            }
            else -> {
                rect(0f, 0f, W, tb, ALERT)
                rect(W * 0.62f, 0f, W * 0.38f, tb, WHITE)
                centerText(tx, W * 0.31f, tb / 2, tb * 0.55f, WHITE, italic = true)
                if (card.d.isNotBlank()) centerText(card.d, W * 0.81f, tb / 2, tb * 0.42f, NAVY)
            }
        }
    }

    /** Coloured strip under the card area (SP0): label tab on the right (card.a), text on the left (card.c). */
    private fun strip(x: Ctx, color: Int, tab: Int, fg: Int, textColor: Int = WHITE) = with(x) {
        val sp = 0.06f * H
        val lw = max(0.22f * W, 220 * S)
        rect(0f, B, W, sp, color)
        para(W - lw - sp * 0.3f, B, lw, sp, sp * 0.3f, tab)
        centerText(card.a, W - lw / 2 - sp * 0.15f, B + sp / 2, sp * 0.5f, fg)
        if (card.c.isNotBlank()) {
            val rtl = isUrdu(card.c)
            centerText(
                card.c,
                if (rtl) W - lw - sp * 0.6f else 0.03f * W,
                B + sp / 2, sp * 0.42f, textColor,
                align = if (rtl) android.graphics.Paint.Align.RIGHT else android.graphics.Paint.Align.LEFT,
            )
        }
    }

    /** 11: Top banner plus image. */
    private fun t11(x: Ctx) = with(x) {
        val tb = max(0.09f * B, 54 * S)
        banner(this, 11, tb)
        val ih = (B - tb) * 0.55f * card.fs.toFloat()
        val y0 = tb + 4 * S
        image(0f, y0, W, ih)
        val y = y0 + ih + 0.03f * B
        val h = text(card.head, 0.04f * W, y, 0.92f * W, 46f, tc)
        text(card.desc, 0.04f * W, y + h + 0.01f * B, 0.92f * W, 26f, SOFT, bold = false)
        strip(this, NAVY, YELLOW, NAVY)
    }

    /** 12: Split screen bulletin. Picture beside (landscape) or above (portrait) the text panel. */
    private fun t12(x: Ctx) = with(x) {
        val land = isLandscape(this)
        val tb = max(0.09f * B, 54 * S)
        val hh = B - tb
        val px = if (land) W * 0.5f else 0f
        val py = if (land) tb else tb + hh * 0.45f
        val pw = if (land) W * 0.5f else W
        val ph = if (land) hh else hh * 0.55f
        if (land) image(0f, tb, W * 0.5f, hh) else image(0f, tb, W, hh * 0.45f)
        rect(px, py, pw, ph, bgc)
        if (land) rect(px, tb, 6 * S, hh, YELLOW) else rect(0f, py, W, 6 * S, YELLOW)
        val m = 0.04f * W
        val h1 = textHeight(card.head, pw - 2 * m, 46f)
        val h2 = textHeight(card.desc, pw - 2 * m, 26f, bold = false)
        val ty = py + max(0.03f * B, (ph - h1 - h2) / 2)
        text(card.head, px + m, ty, pw - 2 * m, 46f, tc)
        text(card.desc, px + m, ty + h1 + 0.01f * B, pw - 2 * m, 26f, WHITE, bold = false)
        banner(this, 12, tb)
        strip(this, NAVY, ALERT, WHITE)
    }

    /** 13: Full image overlay. Full picture, dark text panel at the bottom. */
    private fun t13(x: Ctx) = with(x) {
        val tb = max(0.09f * B, 54 * S)
        image(0f, 0f, W, B)
        banner(this, 13, tb)
        val w = 0.9f * W
        val h1 = textHeight(card.head, w, 50f)
        val h2 = textHeight(card.desc, w, 26f, bold = false)
        val ph = h1 + h2 + 0.04f * B
        val py = B - ph - 0.02f * B
        rect(0.03f * W, py, 0.94f * W, ph, PANEL, radius = 14 * S)
        text(card.head, 0.05f * W, py + 0.02f * B, w, 50f, tc)
        text(card.desc, 0.05f * W, py + 0.02f * B + h1, w, 26f, SOFT, bold = false)
        strip(this, Color.parseColor("#c8102e"), YELLOW, NAVY)
    }

    /** 14: Framed photo card. Dark gradient, picture with a yellow frame. */
    private fun t14(x: Ctx) = with(x) {
        val tb = max(0.09f * B, 54 * S)
        gradient(0f, 0f, W, B, bgc, Color.BLACK)
        banner(this, 14, tb)
        val ih = (B - tb) * 0.52f * card.fs.toFloat()
        val iy = tb + 0.04f * B
        rect(0.08f * W - 6 * S, iy - 6 * S, 0.84f * W + 12 * S, ih + 12 * S, YELLOW)
        image(0.08f * W, iy, 0.84f * W, ih)
        val y = iy + ih + 0.04f * B
        val h = text(card.head, 0.05f * W, y, 0.9f * W, 46f, tc)
        text(card.desc, 0.05f * W, y + h + 0.01f * B, 0.9f * W, 26f, Color.parseColor("#d6dcff"), bold = false)
        strip(this, YELLOW, ALERT, WHITE, NAVY)
    }

    /** 15: Headline first. Headline on top, picture below. */
    private fun t15(x: Ctx) = with(x) {
        val tb = max(0.09f * B, 54 * S)
        rect(0f, 0f, W, B, bgc)
        banner(this, 15, tb)
        val y = tb + 0.03f * B
        val h1 = text(card.head, 0.04f * W, y, 0.92f * W, 50f, tc)
        rect(0.04f * W, y + h1 + 0.01f * B, 0.2f * W, 5 * S, YELLOW)
        val iy = y + h1 + 0.04f * B
        image(0.04f * W, iy, 0.92f * W, max(0.1f * B, B - iy - 0.03f * B))
        strip(this, ALERT, WHITE, Color.parseColor("#c8102e"))
    }

    /** 16: Clean photo. Picture only, for effects. */
    private fun t16(x: Ctx) = with(x) {
        image(0f, 0f, W, B)
    }

    /** Red circle with VS, used by the two-player templates. */
    private fun Ctx.vsBadge(cx: Float, cy: Float, r: Float) {
        disc(cx, cy, r, ALERT)
        centerText("VS", cx, cy, r * 0.9f, WHITE)
    }

    /** 17: Player duel. Two pictures side by side, VS badge, two stats. */
    private fun t17(x: Ctx) = with(x) {
        val hw = W / 2
        val ph = B * 0.5f
        image(0f, 0f, hw, ph, card.src)
        image(hw, 0f, hw, ph, card.src2)
        rect(hw - 3 * S, 0f, 6 * S, ph, WHITE)
        rect(0f, ph - 0.1f * B, W, 0.1f * B, SCRIM)
        text(card.a, 0f, ph - 0.085f * B, hw, 34f, YELLOW)
        text(card.b, hw, ph - 0.085f * B, hw, 34f, YELLOW)
        vsBadge(W / 2, ph, min(W, H) * 0.06f)
        val y = ph + 0.05f * B
        val h = text(card.head, 0.04f * W, y, 0.92f * W, 40f, tc)
        text(card.c, 0f, y + h + 0.03f * B, hw, 64f, CYAN)
        text(card.d, hw, y + h + 0.03f * B, hw, 64f, YELLOW)
        text(card.desc, 0.04f * W, y + h + 0.03f * B + 0.15f * B, 0.92f * W, 26f, PALE, bold = false)
    }

    /** 18: Player stat bars. Two horizontal bars sized by the numbers in card.c and card.d. */
    private fun t18(x: Ctx) = with(x) {
        rect(0f, 0f, W, B, bgc)
        val tb = 0.16f * B
        rect(0f, 0f, W, tb, ALERT)
        rect(0f, tb, W, 4 * S, YELLOW)
        val h = text(card.head, 0.04f * W, tb * 0.12f, 0.92f * W, 36f, WHITE)
        text(card.desc, 0.04f * W, tb * 0.12f + h + 6 * S, 0.92f * W, 24f, Color.parseColor("#ffe6a8"), bold = false)
        val va = numv(card.c)
        val vb = numv(card.d)
        val mx = max(va, vb).let { if (it == 0f) 1f else it }
        val rows = listOf(
            listOf(card.a, va, CYAN, card.c),
            listOf(card.b, vb, YELLOW, card.d),
        )
        rows.forEachIndexed { i, row ->
            val name = row[0] as String
            val v = row[1] as Float
            val col = row[2] as Int
            val raw = row[3] as String
            val y = tb + 0.12f * B + i * 0.3f * B
            val bh = 0.1f * B
            val bw = max(bh, 0.92f * W * v / mx)
            text(name, 0.04f * W, y, 0.92f * W, 38f, WHITE, leftAlign = true)
            rect(0.04f * W, y + 0.12f * B, 0.92f * W, bh, white(0.12f), radius = bh / 2)
            rect(0.04f * W, y + 0.12f * B, bw, bh, col, radius = bh / 2)
            centerText(
                raw.ifEmpty { "0" }, 0.04f * W + bw - bh * 0.3f, y + 0.12f * B + bh / 2,
                bh * 0.6f, Color.BLACK, align = android.graphics.Paint.Align.RIGHT,
            )
        }
    }

    /** 19: Versus split screen. Two full-height pictures, header, two stat panels. */
    private fun t19(x: Ctx) = with(x) {
        val hw = W / 2
        val tb = 0.17f * B
        image(0f, 0f, hw, B, card.src)
        image(hw, 0f, hw, B, card.src2)
        rect(0f, 0f, W, tb, PANEL)
        rect(0f, tb, W, 4 * S, YELLOW)
        text(card.head, 0.04f * W, tb * 0.12f, 0.92f * W, 38f, tc)
        text(card.desc, 0.04f * W, tb * 0.6f, 0.92f * W, 24f, PALE, bold = false)
        rect(hw - 3 * S, tb, 6 * S, B - tb, WHITE)
        vsBadge(W / 2, B * 0.5f, min(W, H) * 0.065f)
        val py = B * 0.7f
        rect(0f, py, hw, B - py, SCRIM)
        rect(hw, py, hw, B - py, SCRIM)
        text(card.a, 0f, py + 0.04f * B, hw, 36f, YELLOW)
        text(card.c, 0f, py + 0.12f * B, hw, 52f, WHITE)
        text(card.b, hw, py + 0.04f * B, hw, 36f, YELLOW)
        text(card.d, hw, py + 0.12f * B, hw, 52f, WHITE)
    }

    /** 20: Head-to-head table. Rows from comma separated lists in card.c, card.d and card.desc. */
    private fun t20(x: Ctx) = with(x) {
        rect(0f, 0f, W, B, bgc)
        val tb = 0.12f * B
        rect(0f, 0f, W, tb, ALERT)
        text(card.head, 0.04f * W, tb * 0.2f, 0.92f * W, 38f, WHITE)
        fun parts(s: String) = s.split(',').map { it.trim() }
        val colA = parts(card.c)
        val colB = parts(card.d)
        val labels = parts(card.desc)
        val n = max(max(colA.size, colB.size), max(labels.size, 1))
        val top = tb + 0.03f * B
        val rr = (B - top - 0.03f * B) / (n + 1)
        val rh = min(rr, 0.14f * B)
        val cx0 = 0.2f * W
        val cx1 = 0.5f * W
        val cx2 = 0.8f * W
        centerText(card.a, cx0, top + rh / 2, min(rh * 0.42f, 48 * S), CYAN)
        centerText(card.b, cx2, top + rh / 2, min(rh * 0.42f, 48 * S), YELLOW)
        for (i in 0 until n) {
            val y = top + rh * (i + 1)
            val fs = min(rh * 0.4f, 44 * S)
            rect(0f, y, W, rh, white(if (i % 2 == 1) 0.07f else 0.02f))
            centerText(colA.getOrNull(i)?.ifEmpty { null } ?: "-", cx0, y + rh / 2, fs, WHITE)
            centerText(labels.getOrNull(i) ?: "", cx1, y + rh / 2, min(rh * 0.34f, 36 * S), PALE)
            centerText(colB.getOrNull(i)?.ifEmpty { null } ?: "-", cx2, y + rh / 2, fs, WHITE)
        }
    }

    /** One player card for template 21. */
    private fun Ctx.playerCard(px: Float, py: Float, pw: Float, ph: Float, name: String, value: String, win: Boolean, src: String) {
        if (win) rect(px - 5 * S, py - 5 * S, pw + 10 * S, ph + 10 * S, YELLOW, radius = 18 * S)
        rect(px, py, pw, ph, Color.parseColor("#141c33"), radius = 14 * S)
        image(px, py, pw, ph * 0.6f, src)
        text(name, px, py + ph * 0.62f, pw, 40f, WHITE)
        text(value, px, py + ph * 0.62f + 56 * S, pw, 64f, if (win) YELLOW else WHITE)
        if (win) label("WINNER", px + pw / 2 - 110 * S, py + ph * 0.6f - 24 * S, 220 * S, 48 * S, YELLOW, NAVY)
    }

    /** 21: Winner highlight. Two player cards, the higher number gets a yellow frame and WINNER tag. */
    private fun t21(x: Ctx) = with(x) {
        rect(0f, 0f, W, B, bgc)
        val tb = 0.14f * B
        rect(0f, 0f, W, tb, NAVY)
        rect(0f, tb, W, 4 * S, YELLOW)
        text(card.head, 0.04f * W, tb * 0.2f, 0.92f * W, 38f, tc)
        val va = numv(card.c)
        val vb = numv(card.d)
        val cw = (W - 0.12f * W) / 2
        val cy = tb + 0.08f * B
        val ch = B - cy - 0.06f * B
        playerCard(0.04f * W, cy, cw, ch, card.a, card.c, va > vb, card.src)
        playerCard(W - 0.04f * W - cw, cy, cw, ch, card.b, card.d, vb > va, card.src2)
        text(card.desc, 0.04f * W, B - 0.05f * B, 0.92f * W, 24f, PALE, bold = false)
    }
}
