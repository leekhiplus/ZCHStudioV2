package com.zch.studio.ui

import android.os.Handler
import android.os.Looper

/** Runs work on a background thread and delivers the result on the main thread. */
fun <T> background(work: () -> T, done: (Result<T>) -> Unit) {
    Thread {
        val result = runCatching(work)
        Handler(Looper.getMainLooper()).post { done(result) }
    }.start()
}

/** Runs block on the main thread. */
fun onMain(block: () -> Unit) {
    Handler(Looper.getMainLooper()).post(block)
}
