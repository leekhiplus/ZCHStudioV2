package com.zch.studio.gemini

/** Model and voice lists of the WebView app. Names can also be typed in by hand. */
object GeminiModels {

    val TEXT = listOf(
        "gemini-3.8-flash" to "Gemini 3.8 Flash",
        "gemini-flash-latest" to "Latest Flash (automatic)",
        "gemini-3.5-flash-lite" to "Gemini 3.5 Flash-Lite",
        "gemini-2.5-pro" to "Gemini 2.5 Pro",
        "gemini-2.5-flash" to "Gemini 2.5 Flash",
        "gemini-2.5-flash-lite" to "Gemini 2.5 Flash-Lite",
    )

    val TTS = listOf(
        "gemini-3.8-flash-tts" to "Gemini 3.8 Flash TTS (latest, best quality)",
        "gemini-3.8-flash-lite-tts" to "Gemini 3.8 Flash-Lite TTS (fast, cheaper)",
        "gemini-3.1-flash-tts" to "Gemini 3.1 Flash TTS",
        "gemini-2.5-pro-preview-tts" to "Gemini 2.5 Pro TTS",
        "gemini-2.5-flash-preview-tts" to "Gemini 2.5 Flash TTS",
    )

    val VOICES = listOf(
        "Zephyr" to "Bright", "Puck" to "Upbeat", "Charon" to "Informative", "Kore" to "Firm", "Fenrir" to "Excitable",
        "Leda" to "Youthful", "Orus" to "Firm", "Aoede" to "Breezy", "Callirrhoe" to "Easy-going", "Autonoe" to "Bright",
        "Enceladus" to "Breathy", "Iapetus" to "Clear", "Umbriel" to "Easy-going", "Algieba" to "Smooth", "Despina" to "Smooth",
        "Erinome" to "Clear", "Algenib" to "Gravelly", "Rasalgethi" to "Informative", "Laomedeia" to "Upbeat", "Achernar" to "Soft",
        "Alnilam" to "Firm", "Schedar" to "Even", "Gacrux" to "Mature", "Pulcherrima" to "Forward", "Achird" to "Friendly",
        "Zubenelgenubi" to "Casual", "Vindemiatrix" to "Gentle", "Sadachbia" to "Lively", "Sadaltager" to "Knowledgeable", "Sulafat" to "Warm",
    )
}
