package com.zch.studio.ui

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.zch.studio.model.Project

/** Video tab: shape, size, frame rate, when the video ends, and the news ticker. */
@Composable
fun VideoScreen(project: Project, onProject: (Project) -> Unit) {
    ScreenColumn {
        Heading("Video")
        Caption("Shape")
        Chips(listOf("16:9", "9:16", "1:1").map { it to it }, project.asp) { onProject(project.copy(asp = it)) }
        Caption("Size (short side)")
        Chips(listOf("480", "720", "1080").map { it to "${it}p" }, project.res.toString()) { onProject(project.copy(res = it.toInt())) }
        Caption("Frame rate")
        Chips(listOf("24", "25", "30").map { it to "$it fps" }, project.fps.toString()) { onProject(project.copy(fps = it.toInt())) }
        Caption("Video ends with")
        Chips(listOf("voice" to "Audio length", "card" to "Last card"), if (project.endm == "card") "card" else "voice") {
            onProject(project.copy(endm = it))
        }

        Heading("News ticker")
        SwitchRow("Show ticker", project.tickOn != 0) { onProject(project.copy(tickOn = if (it) 1 else 0)) }
        OutlinedTextField(
            value = project.tick,
            onValueChange = { onProject(project.copy(tick = it)) },
            label = { Text("Ticker text") },
            minLines = 2,
            modifier = Modifier.fillMaxWidth(),
        )
        Caption("Direction")
        Chips(listOf("1" to "Right to left", "-1" to "Left to right"), project.tdir.toString()) { onProject(project.copy(tdir = it.toInt())) }
        LabeledSlider("Speed", project.tickSpd.toFloat(), 40f..300f, 0) { onProject(project.copy(tickSpd = it.toDouble())) }
        ColorField("Text color", project.tickC) { onProject(project.copy(tickC = it)) }
        ColorField("Bar color", project.tickBg) { onProject(project.copy(tickBg = it)) }
    }
}
