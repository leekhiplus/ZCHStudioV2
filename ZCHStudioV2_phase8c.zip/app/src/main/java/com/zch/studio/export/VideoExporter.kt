package com.zch.studio.export

import android.graphics.Canvas
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.os.Build
import android.view.Surface
import com.zch.studio.model.Project
import com.zch.studio.model.outputSize
import com.zch.studio.model.totalDuration
import com.zch.studio.render.Fonts
import com.zch.studio.render.FrameRenderer
import com.zch.studio.render.ImageCache
import java.io.File
import kotlin.math.ceil

/**
 * Renders the project straight into a MediaCodec H.264 input Surface and writes an MP4.
 * No JPEG bridge: every frame is drawn by FrameRenderer onto the encoder's Surface.
 * Video only. Audio is added in a later phase.
 */
class VideoExporter {

    class CancelledException : RuntimeException("Export cancelled")

    /**
     * Writes the whole project to out. Blocks until done, so call it from a background thread.
     * onProgress gets 0..1. isCancelled is checked before every frame.
     */
    fun export(
        project: Project,
        out: File,
        fonts: Fonts,
        images: ImageCache,
        onProgress: (Float) -> Unit,
        isCancelled: () -> Boolean,
    ) {
        val (w, h) = project.outputSize()
        val fps = project.fps.coerceIn(1, 60)
        val frames = ceil(project.totalDuration() * fps).toInt().coerceAtLeast(1)
        val bitrate = (w.toLong() * h * fps / 5).coerceIn(1_000_000L, 20_000_000L).toInt()

        val format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, w, h).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, bitrate)
            setInteger(MediaFormat.KEY_FRAME_RATE, fps)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
        }

        var encoder: MediaCodec? = null
        var surface: Surface? = null
        var muxer: MediaMuxer? = null
        var finished = false
        try {
            encoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
            encoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            surface = encoder.createInputSurface()
            encoder.start()
            muxer = MediaMuxer(out.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val drain = Drain(encoder, muxer, fps)

            for (i in 0 until frames) {
                if (isCancelled()) throw CancelledException()
                val canvas = lock(surface)
                try {
                    FrameRenderer.draw(canvas, project, i / fps.toFloat(), w, h, fonts, images)
                } finally {
                    surface.unlockCanvasAndPost(canvas)
                }
                drain.pump(false)
                onProgress((i + 1) / frames.toFloat())
            }
            encoder.signalEndOfInputStream()
            drain.pump(true)
            if (drain.started) muxer.stop()
            finished = true
        } finally {
            runCatching { encoder?.stop() }
            runCatching { encoder?.release() }
            runCatching { surface?.release() }
            runCatching { muxer?.release() }
            if (!finished) out.delete()
        }
    }

    private fun lock(surface: Surface): Canvas =
        if (Build.VERSION.SDK_INT >= 23) {
            runCatching { surface.lockHardwareCanvas() }.getOrElse { surface.lockCanvas(null) }
        } else {
            surface.lockCanvas(null)
        }

    /**
     * Moves encoded frames into the muxer. Drawing on a Surface gives timestamps from the system clock,
     * so each output frame is stamped with its own frame number / fps instead.
     */
    private class Drain(private val codec: MediaCodec, private val muxer: MediaMuxer, private val fps: Int) {
        private val info = MediaCodec.BufferInfo()
        private var track = -1
        private var count = 0L
        var started = false
            private set

        /** Takes every frame that is ready. With end = true, waits until the stream ends. */
        fun pump(end: Boolean) {
            var idle = 0
            while (true) {
                val index = codec.dequeueOutputBuffer(info, if (end) 10_000L else 0L)
                if (index == MediaCodec.INFO_TRY_AGAIN_LATER) {
                    if (!end) return
                    if (++idle > 1000) throw IllegalStateException("Encoder did not finish")
                    continue
                }
                idle = 0
                if (index == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    track = muxer.addTrack(codec.outputFormat)
                    muxer.start()
                    started = true
                } else if (index >= 0) {
                    val buffer = codec.getOutputBuffer(index)
                    if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
                    if (info.size > 0 && buffer != null && started) {
                        buffer.position(info.offset)
                        buffer.limit(info.offset + info.size)
                        info.presentationTimeUs = count * 1_000_000L / fps
                        count++
                        muxer.writeSampleData(track, buffer, info)
                    }
                    codec.releaseOutputBuffer(index, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) return
                }
            }
        }
    }
}
