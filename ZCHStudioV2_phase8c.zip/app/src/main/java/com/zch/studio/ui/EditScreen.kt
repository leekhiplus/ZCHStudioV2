package com.zch.studio.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.zch.studio.media.ImageImport
import com.zch.studio.model.NewsCard
import com.zch.studio.model.Project
import com.zch.studio.model.replaceCard
import com.zch.studio.render.ImageCache

/** The pictures of a card. Old projects may hold a single picture in src only. */
private fun pictures(c: NewsCard): List<String> = c.imgs.ifEmpty { if (c.src.isNotEmpty()) listOf(c.src) else emptyList() }

/** Edit tab: pictures of the selected card and how they sit in the frame. */
@Composable
fun EditScreen(project: Project, onProject: (Project) -> Unit) {
    val context = LocalContext.current
    val latest by rememberUpdatedState(project)
    val save by rememberUpdatedState(onProject)
    val cache = remember { ImageCache() }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }

    fun changeSelected(change: (NewsCard) -> NewsCard) {
        val p = latest
        if (p.cards.isEmpty()) return
        val i = p.sel.coerceIn(0, p.cards.lastIndex)
        save(p.replaceCard(i, change(p.cards[i])))
    }

    val addPictures = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        if (uris.isEmpty()) return@rememberLauncherForActivityResult
        busy = true
        message = "Adding pictures..."
        val app = context.applicationContext
        background({ uris.map { ImageImport.toDataUri(app, it, 1280) } }) { result ->
            busy = false
            result.onSuccess { added ->
                message = ""
                changeSelected { c ->
                    val all = pictures(c) + added
                    c.copy(imgs = all, src = all.first())
                }
            }.onFailure { message = it.message ?: "Could not add the pictures" }
        }
    }
    val pickSecond = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        busy = true
        message = "Adding picture..."
        val app = context.applicationContext
        background({ ImageImport.toDataUri(app, uri, 1280) }) { result ->
            busy = false
            result.onSuccess { data -> message = ""; changeSelected { it.copy(src2 = data) } }
                .onFailure { message = it.message ?: "Could not add the picture" }
        }
    }

    CardSettings(project, onProject) { card, update ->
        Heading("Pictures")
        val list = pictures(card)
        if (list.isEmpty()) Text("No pictures on this card.", style = MaterialTheme.typography.bodySmall)
        list.forEachIndexed { i, src ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Thumb(cache, src)
                Text("Picture ${i + 1}", modifier = Modifier.weight(1f))
                OutlinedButton(onClick = {
                    changeSelected { c ->
                        val left = pictures(c).filterIndexed { n, _ -> n != i }
                        c.copy(imgs = left, src = left.firstOrNull() ?: "")
                    }
                }) { Text("Remove") }
            }
        }
        Button(onClick = { addPictures.launch("image/*") }, enabled = !busy) { Text("Add pictures") }
        Text(
            "With several pictures the card shows them one after another. Change the style in the Effects tab.",
            style = MaterialTheme.typography.bodySmall,
        )

        Heading("Second picture")
        Text("Used by the versus and player templates.", style = MaterialTheme.typography.bodySmall)
        if (card.src2.isNotEmpty()) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Thumb(cache, card.src2)
                OutlinedButton(onClick = { update(card.copy(src2 = "")) }) { Text("Remove") }
            }
        }
        Button(onClick = { pickSecond.launch("image/*") }, enabled = !busy) {
            Text(if (card.src2.isEmpty()) "Choose picture" else "Replace picture")
        }
        if (message.isNotEmpty()) Text(message, style = MaterialTheme.typography.bodySmall)

        Heading("Picture in the frame")
        Chips(listOf("fill" to "Fill the frame", "fit" to "Fit whole picture"), card.fit) { update(card.copy(fit = it)) }
        LabeledSlider("Zoom", card.iz.toFloat(), 0.5f..3f) { update(card.copy(iz = it.toDouble())) }
        LabeledSlider("Position X (%)", card.fx.toFloat(), 0f..100f, 0) { update(card.copy(fx = it.toDouble())) }
        LabeledSlider("Position Y (%)", card.fy.toFloat(), 0f..100f, 0) { update(card.copy(fy = it.toDouble())) }
        LabeledSlider("Picture frame size", card.fs.toFloat(), 0.6f..1.3f) { update(card.copy(fs = it.toDouble())) }
        OutlinedButton(onClick = { update(card.copy(fit = "fill", iz = 1.0, fx = 50.0, fy = 35.0, fs = 1.0)) }) { Text("Reset picture") }
    }
}
