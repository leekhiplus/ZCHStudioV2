package com.zch.studio.render

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import android.util.LruCache

/** Decodes "data:image/...;base64,..." strings once and keeps them in memory. */
class ImageCache {

    private val cache = object : LruCache<String, Bitmap>((Runtime.getRuntime().maxMemory() / 8 / 1024).toInt()) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount / 1024
    }

    fun get(src: String): Bitmap? {
        if (src.isBlank()) return null
        cache.get(src)?.let { return it }
        val bytes = runCatching { Base64.decode(src.substringAfter(',', src), Base64.DEFAULT) }.getOrNull()
            ?: return null
        val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return null
        cache.put(src, bmp)
        return bmp
    }
}
