package com.zch.studio.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.unit.dp
import com.zch.studio.model.Project
import com.zch.studio.model.closeGaps
import com.zch.studio.model.withEqualLengths
import java.util.Locale
import kotlin.math.max

/** Timing tab: start and end of the selected card, and tools for all cards. The timeline above shows the result. */
@Composable
fun TimingScreen(project: Project, onProject: (Project) -> Unit, player: PlayerState) {
    var every by remember { mutableFloatStateOf(5f) }
    CardSettings(project, onProject) { card, update ->
        Heading("This card")
        Stepper("Start (s)", card.s) { update(card.copy(s = it.coerceIn(0.0, card.e - 0.3))) }
        Stepper("End (s)", card.e) { update(card.copy(e = max(it, card.s + 0.3))) }
        Text(
            "Length: " + String.format(Locale.US, "%.1f", card.e - card.s) + " s",
            style = MaterialTheme.typography.bodyMedium,
        )
        Button(onClick = { player.time = card.s.toFloat(); player.playing = true }) { Text("Play from this card") }

        Heading("All cards")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { onProject(project.closeGaps()) }, contentPadding = PaddingValues(horizontal = 16.dp)) {
                Text("Back to back")
            }
        }
        LabeledSlider("Same length for every card (s)", every, 2f..12f, 1) { every = it }
        OutlinedButton(onClick = { onProject(project.withEqualLengths(every.toDouble())) }) { Text("Apply same length") }
        Text(
            "In the timeline, long-press a card bar and drag to move it. Drag near its left or right edge to change its start or end. " +
                "Cards made with a Gemini voice are timed to the speech, so changing them can move picture and voice apart.",
            style = MaterialTheme.typography.bodySmall,
        )
    }
}
