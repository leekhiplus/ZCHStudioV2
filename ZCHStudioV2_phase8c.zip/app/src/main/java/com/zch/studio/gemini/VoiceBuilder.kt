package com.zch.studio.gemini

import android.content.Context
import com.zch.studio.audio.AudioImport
import com.zch.studio.export.AudioMix
import com.zch.studio.model.Project
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** One voiceover for the whole video, and matching the cards to a voice, genAll() and syncCards() of the WebView app. */
object VoiceBuilder {

    private class Words(val items: List<String>, val ws: List<List<String>>)

    private fun cardWords(project: Project): Words {
        val items = project.cards.map { it.script.ifBlank { it.desc }.ifBlank { it.head }.trim() }
        val bad = items.indexOfFirst { it.isEmpty() }
        if (bad >= 0) throw IllegalArgumentException("Card ${bad + 1} has no script. Write what is said on each card.")
        return Words(items, items.map { t -> t.split(Regex("\\s+")).filter { it.isNotEmpty() } })
    }

    /** Speaks all card scripts as one recording, finds the word times and sets the cards to follow the voice. */
    fun generateAll(context: Context, project: Project, key: String, onStatus: (String) -> Unit): Project {
        val cw = cardWords(project)
        val ws = cw.ws
        val groups = ArrayList<List<Int>>()
        var g = ArrayList<Int>()
        var n = 0
        ws.indices.forEach { i ->
            if (g.isNotEmpty() && n + ws[i].size > 500) {
                groups.add(g)
                g = ArrayList()
                n = 0
            }
            g.add(i)
            n += ws[i].size
        }
        groups.add(g)

        val parts = ArrayList<ShortArray>()
        val times = ArrayList<Double>()
        var offset = 0.0
        var rate = 24000
        for (q in groups.indices) {
            onStatus("Generating the voiceover" + (if (groups.size > 1) " (part ${q + 1} of ${groups.size})" else "") + "...")
            val ids = groups[q]
            val words = ids.flatMap { ws[it] }
            val spoken = GeminiClient.speak(ids.joinToString(" ") { cw.items[it] }, project.gm, project.gv, project.gs, key)
            rate = spoken.rate
            val pcm = VoiceAlign.clean(toShorts(spoken.bytes), rate)
            val aligned = VoiceAlign.align(pcm, rate, words)
            aligned.t.forEach { times.add(CardText.r2(offset + it)) }
            parts.add(aligned.p)
            offset += aligned.p.size.toDouble() / rate
            if (q < groups.size - 1) {
                parts.add(ShortArray(Math.round(rate * 0.25).toInt()))
                offset += 0.25
            }
        }
        val all = ShortArray(parts.sumOf { it.size })
        var o = 0
        parts.forEach { System.arraycopy(it, 0, all, o, it.size); o += it.size }
        val fade = minOf(all.size, Math.round(rate * 0.03).toInt())
        for (i in 0 until fade) all[all.size - 1 - i] = (all[all.size - 1 - i] * (i.toDouble() / fade)).toInt().toShort()

        AudioImport.voiceFile(context).writeBytes(wav(all, rate))
        val seconds = all.size.toDouble() / rate
        val timed = VoiceAlign.applyTimes(project, times, ws.map { it.size }, ws.flatten(), seconds)
        return timed.copy(audioName = "Gemini voice", audioSec = seconds)
    }

    /** Finds the words of every card in the voice that is already loaded and sets the card times from it. */
    fun syncCards(context: Context, project: Project, onStatus: (String) -> Unit): Project {
        val voice = AudioImport.voiceFile(context)
        if (project.audioName.isEmpty() || !voice.exists()) throw IllegalArgumentException("Import or generate a voiceover first.")
        val cw = cardWords(project)
        onStatus("Matching the cards to the voice...")
        val (pcm, rate) = AudioMix.decodeMono(voice)
        val aligned = VoiceAlign.align(pcm, rate, cw.ws.flatten())
        val times = aligned.t.map { CardText.r2(it + aligned.off) }
        return VoiceAlign.applyTimes(project, times, cw.ws.map { it.size }, cw.ws.flatten(), project.audioSec)
    }

    private fun toShorts(bytes: ByteArray): ShortArray {
        val out = ShortArray(bytes.size / 2)
        ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().get(out)
        return out
    }

    /** 16-bit mono PCM wrapped in a WAV header. */
    private fun wav(pcm: ShortArray, rate: Int): ByteArray {
        val buf = ByteBuffer.allocate(44 + pcm.size * 2).order(ByteOrder.LITTLE_ENDIAN)
        buf.put("RIFF".toByteArray()).putInt(36 + pcm.size * 2).put("WAVE".toByteArray())
        buf.put("fmt ".toByteArray()).putInt(16).putShort(1).putShort(1)
        buf.putInt(rate).putInt(rate * 2).putShort(2).putShort(16)
        buf.put("data".toByteArray()).putInt(pcm.size * 2)
        for (s in pcm) buf.putShort(s)
        return buf.array()
    }
}
