package com.zch.studio.audio

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File

/** Copies a chosen audio file into the app so it stays available, and reads its name and length. */
object AudioImport {

    class Imported(val name: String, val seconds: Double)

    /** The one voiceover file of the project. */
    fun voiceFile(context: Context): File = File(context.filesDir, "voiceover")

    /** Blocks while copying. Call from a background thread. Throws if the file is not readable audio. */
    fun import(context: Context, uri: Uri): Imported {
        val dest = voiceFile(context)
        val input = context.contentResolver.openInputStream(uri)
            ?: throw IllegalArgumentException("Could not open the file")
        input.use { i -> dest.outputStream().use { o -> i.copyTo(o) } }
        val retriever = MediaMetadataRetriever()
        val ms = try {
            retriever.setDataSource(dest.absolutePath)
            retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        } catch (e: Exception) {
            0L
        } finally {
            retriever.release()
        }
        if (ms <= 0L) {
            dest.delete()
            throw IllegalArgumentException("This does not look like an audio file")
        }
        return Imported(displayName(context, uri), ms / 1000.0)
    }

    fun remove(context: Context) {
        voiceFile(context).delete()
    }

    private fun displayName(context: Context, uri: Uri): String {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val name = c.getString(0)
                if (!name.isNullOrBlank()) return name
            }
        }
        return "Voiceover"
    }
}
