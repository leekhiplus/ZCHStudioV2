package com.zch.studio.gemini

import com.zch.studio.model.NewsCard
import com.zch.studio.model.Project
import kotlin.math.ceil
import kotlin.math.max

/** Splitting news text into cards without any AI, and the helpers around it (splitNews, hd, brk, splitCard, mkCards of the WebView app). */
object CardText {

    private val FUNCTION_WORDS = setOf(
        "کے", "کی", "کا", "نے", "میں", "کو", "سے", "پر", "اور", "لیے", "کیلئے", "کیلیے", "نئے", "نئی", "نیا", "ہی", "بھی", "کہ",
        "جو", "جس", "تک", "ہیں", "ہے", "تھا", "تھی", "تھے", "ان", "اس", "گئی", "گئے", "گیا", "گئیں", "کیے", "کیا",
    )

    /** A script longer than this many words is split into several cards when the voiceover is made. */
    const val LONG_SCRIPT = 45

    fun wc(x: String): Int = x.split(Regex("\\s+")).count { it.isNotEmpty() }

    fun r1(v: Double) = Math.round(v * 10) / 10.0
    fun r2(v: Double) = Math.round(v * 100) / 100.0

    /** A short headline from the first sentence of a text. */
    fun headline(t: String): String {
        val first = t.split(Regex("(?<=[۔.!؟?])\\s+")).first().replace(Regex("[۔.!؟?]+$"), "")
        var w = first.split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (w.size > 12) {
            val i = first.indexOfFirst { it == '،' || it == ',' }
            val c = if (i > 0) first.substring(0, i).split(Regex("\\s+")).filter { it.isNotEmpty() } else emptyList()
            w = if (c.size in 4..12) c else w.take(10)
        }
        val list = w.toMutableList()
        while (list.size > 3 && FUNCTION_WORDS.contains(list.last().replace(Regex("[،,]+$"), ""))) list.removeAt(list.lastIndex)
        return list.joinToString(" ").replace(Regex("[،,:;\\s]+$"), "")
    }

    /** Breaks a very long sentence into pieces of about lim words, preferring commas. */
    private fun breakLong(x: String, lim: Int): List<String> {
        val w = x.split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (w.size <= lim) return listOf(x)
        val out = ArrayList<String>()
        var g = ArrayList<String>()
        for (t in w) {
            g.add(t)
            if (g.size >= lim || (g.size >= lim * 0.6 && Regex("[،,;:]$").containsMatchIn(t))) {
                out.add(g.joinToString(" "))
                g = ArrayList()
            }
        }
        if (g.isNotEmpty()) out.add(g.joinToString(" "))
        return out
    }

    /** Groups the sentences of a text into at most limit pieces of about tg0 words each. */
    fun splitNews(text: String, limit: Int, tg0: Int? = null): List<String> {
        var sentences = ArrayList<String>()
        text.replace("\r", "").split(Regex("\n+")).map { it.trim() }.filter { it.isNotEmpty() }.forEach { p ->
            p.split(Regex("(?<=[۔!؟?])\\s*|(?<=\\.)\\s+")).forEach { x ->
                val t = x.trim()
                if (t.isNotEmpty()) sentences.add(t)
            }
        }
        val total = sentences.sumOf { wc(it) }
        val tg = tg0 ?: max(28, ceil(total.toDouble() / limit).toInt())
        sentences = ArrayList(sentences.flatMap { breakLong(it, Math.round(tg * 1.4).toInt()) })
        val out = ArrayList<String>()
        var g = ArrayList<String>()
        var n = 0
        for (x in sentences) {
            if (g.isNotEmpty() && n + wc(x) > tg * 1.3) {
                out.add(g.joinToString(" "))
                g = ArrayList()
                n = 0
            }
            g.add(x)
            n += wc(x)
            if (n >= tg) {
                out.add(g.joinToString(" "))
                g = ArrayList()
                n = 0
            }
        }
        if (g.isNotEmpty()) out.add(g.joinToString(" "))
        while (out.size > limit) {
            val l = out.removeAt(out.lastIndex)
            out[out.lastIndex] = out.last() + " " + l
        }
        return out
    }

    /** Cards from text with no AI: every piece becomes one card with its first sentence as headline. */
    fun localDrafts(text: String, wordsPerCard: Int): List<GeminiClient.Draft> =
        splitNews(text, 200, wordsPerCard).map { GeminiClient.Draft(headline(it), it, it) }
}

/** Splits the script of one card into several cards and moves the later cards back. Null if the script is too short. */
fun Project.splitCard(index: Int, target: Int = 32): Project? {
    val c = cards.getOrNull(index) ?: return null
    val parts = CardText.splitNews(c.script, 200, target)
    if (parts.size < 2) return null
    val first = c.copy(
        script = parts[0], vd = 0.0, vw = emptyList(), wt = emptyList(),
        e = CardText.r2(c.s + max(3.0, CardText.wc(parts[0]) / 2.6)),
    )
    var t0 = first.e
    val added = parts.drop(1).map { t ->
        val d = max(3.0, CardText.r1(CardText.wc(t) / 2.6))
        val n = first.copy(
            imgs = emptyList(), src = "", src2 = "", vd = 0.0, vw = emptyList(), wt = emptyList(),
            head = CardText.headline(t), desc = t, script = t, s = CardText.r2(t0), e = CardText.r2(t0 + d),
        )
        t0 += d
        n
    }
    val shift = t0 - c.e
    val later = cards.drop(index + 1).map { it.copy(s = CardText.r2(it.s + shift), e = CardText.r2(it.e + shift)) }
    return copy(cards = cards.take(index) + first + added + later, sel = index)
}

/** Adds cards from drafts, styled like the selected card. replace = true swaps all cards, otherwise they go at the end. */
fun Project.withDrafts(drafts: List<GeminiClient.Draft>, replace: Boolean): Project {
    val base = cards.getOrNull(sel) ?: NewsCard()
    var t0 = if (replace) 0.0 else (cards.maxOfOrNull { it.e } ?: 0.0)
    val made = drafts.map { d ->
        val length = max(3.0, CardText.r1(CardText.wc(d.script.ifBlank { d.desc }) / 2.6))
        val begin = t0
        t0 += length
        base.copy(
            head = d.head, desc = d.desc, script = d.script,
            src = "", src2 = "", imgs = emptyList(),
            s = CardText.r2(begin), e = CardText.r2(begin + length), vd = 0.0, vw = emptyList(), wt = emptyList(),
        )
    }
    return if (replace) copy(cards = made, sel = 0) else copy(cards = cards + made, sel = cards.size)
}
