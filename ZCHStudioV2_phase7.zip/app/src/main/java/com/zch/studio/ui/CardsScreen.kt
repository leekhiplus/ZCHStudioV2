package com.zch.studio.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.zch.studio.model.NewsCard
import com.zch.studio.model.Project
import com.zch.studio.model.TEMPLATE_NAMES
import com.zch.studio.model.addCard
import com.zch.studio.model.deleteCard
import com.zch.studio.model.replaceCard

/** Cards tab: list of slides, add/delete, and an editor for the selected slide. */
@Composable
fun CardsScreen(
    project: Project,
    onProject: (Project) -> Unit,
) {
    val cards = project.cards
    val index = project.sel.coerceIn(0, (cards.size - 1).coerceAtLeast(0))
    val card = cards.getOrNull(index)

    LazyColumn(
        modifier = Modifier.fillMaxWidth().padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { onProject(project.addCard()) }) { Text("Add card") }
                OutlinedButton(
                    onClick = { onProject(project.deleteCard(index)) },
                    enabled = cards.size > 1,
                ) { Text("Delete") }
            }
        }
        itemsIndexed(cards) { i, c ->
            CardRow(
                number = i + 1,
                card = c,
                selected = i == index,
                onClick = { onProject(project.copy(sel = i)) },
            )
        }
        if (card != null) {
            item {
                key(index) {
                    CardEditor(
                        card = card,
                        onChange = { onProject(project.replaceCard(index, it)) },
                    )
                }
            }
        }
    }
}

@Composable
private fun CardRow(number: Int, card: NewsCard, selected: Boolean, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        colors = CardDefaults.cardColors(
            containerColor = if (selected) MaterialTheme.colorScheme.primaryContainer
            else MaterialTheme.colorScheme.surfaceVariant,
        ),
    ) {
        Column(Modifier.padding(12.dp)) {
            Text("$number. ${card.head.ifBlank { "(empty)" }}")
            Text(
                "${TEMPLATE_NAMES.getOrElse(card.tpl) { "" }}  •  ${card.s}s to ${card.e}s",
                style = MaterialTheme.typography.bodySmall,
            )
        }
    }
}

@Composable
private fun CardEditor(card: NewsCard, onChange: (NewsCard) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        TemplatePicker(
            selected = card.tpl,
            onSelect = { onChange(card.copy(tpl = it)) },
        )
        TextField("Headline", card.head) { onChange(card.copy(head = it)) }
        TextField("Description", card.desc, minLines = 3) { onChange(card.copy(desc = it)) }
        TextField("Name A / team A", card.a) { onChange(card.copy(a = it)) }
        TextField("Name B / team B", card.b) { onChange(card.copy(b = it)) }
        TextField("Value A / score A", card.c) { onChange(card.copy(c = it)) }
        TextField("Value B / score B", card.d) { onChange(card.copy(d = it)) }
        NumberField("Start (seconds)", card.s) { onChange(card.copy(s = it)) }
        NumberField("End (seconds)", card.e) { onChange(card.copy(e = it)) }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun TemplatePicker(selected: Int, onSelect: (Int) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Column {
        Text("Template", style = MaterialTheme.typography.labelMedium)
        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
            Text(TEMPLATE_NAMES.getOrElse(selected) { "Choose" }, modifier = Modifier.weight(1f))
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            TEMPLATE_NAMES.forEachIndexed { i, name ->
                DropdownMenuItem(
                    text = { Text("${i + 1}. $name") },
                    onClick = {
                        expanded = false
                        onSelect(i)
                    },
                )
            }
        }
    }
}

@Composable
private fun TextField(label: String, value: String, minLines: Int = 1, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        minLines = minLines,
        modifier = Modifier.fillMaxWidth(),
    )
}

/** Keeps what the user typed (like "5.") and only saves when it is a valid number. */
@Composable
private fun NumberField(label: String, value: Double, onChange: (Double) -> Unit) {
    var text by remember { mutableStateOf(value.toString()) }
    OutlinedTextField(
        value = text,
        onValueChange = { new ->
            text = new
            new.toDoubleOrNull()?.let(onChange)
        },
        label = { Text(label) },
        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = KeyboardType.Decimal),
        modifier = Modifier.fillMaxWidth(),
    )
}
