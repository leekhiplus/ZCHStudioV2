package com.zch.studio.ui

import android.media.MediaPlayer
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import com.zch.studio.audio.AudioImport
import com.zch.studio.audio.SfxPlayer
import com.zch.studio.audio.SfxSynth
import com.zch.studio.model.NewsCard
import com.zch.studio.model.Project
import com.zch.studio.model.totalDuration
import com.zch.studio.render.Fonts
import com.zch.studio.render.FrameRenderer
import com.zch.studio.render.ImageCache
import java.io.File
import kotlin.math.max
import kotlin.math.min

/** Playback position shared by the whole app, so the preview keeps its place when the tab changes. */
class PlayerState {
    var time by mutableFloatStateOf(0f)
    var playing by mutableStateOf(false)
}

/**
 * The preview that stays on screen above every tab: play controls, the video itself and the multi-track timeline.
 * It plays the voiceover and the card start sounds, and follows the selected card.
 */
@Composable
fun PreviewPanel(
    project: Project,
    onProject: (Project) -> Unit,
    player: PlayerState,
    expanded: Boolean,
    onToggle: () -> Unit,
) {
    val context = LocalContext.current
    val fonts = remember { Fonts(context) }
    val images = remember { ImageCache() }
    val total = project.totalDuration()
    val totalNow by rememberUpdatedState(total)
    val projectNow by rememberUpdatedState(project)
    val saveNow by rememberUpdatedState(onProject)

    val voiceFile = AudioImport.voiceFile(context)
    val voice = remember(project.audioName, project.audioSec, voiceFile.lastModified()) {
        if (project.audioName.isEmpty()) null else makePlayer(voiceFile)
    }
    DisposableEffect(voice) { onDispose { runCatching { voice?.release() } } }
    val sfx = remember { SfxPlayer() }
    DisposableEffect(Unit) { onDispose { sfx.release() } }

    // Choosing another card, in any tab, shows that card. A card that is already on screen stays as it is.
    LaunchedEffect(project.sel) {
        if (player.playing) return@LaunchedEffect
        val p = projectNow
        val card = p.cards.getOrNull(p.sel) ?: return@LaunchedEffect
        val inside = player.time >= card.s && player.time <= card.e
        val atStart = player.time - card.s < 0.15f
        if (!inside || atStart) player.time = settledTime(p, card).coerceIn(0f, totalNow)
    }

    // Playback. When the voiceover is sounding its clock drives the time, so picture and voice stay together.
    LaunchedEffect(player.playing) {
        if (!player.playing) return@LaunchedEffect
        val p = voice
        val startT = player.time
        runCatching {
            if (p != null && startT * 1000f < p.duration) {
                p.seekTo((startT * 1000f).toInt())
                p.start()
            }
        }
        // Sounds that began just before the start point play from the middle.
        for (c in projectNow.cards) {
            val n = SfxSynth.nameFor(c, projectNow) ?: continue
            val begin = c.s.toFloat() - (SfxSynth.LEAD[n] ?: 0f)
            val dur = SfxSynth.DUR.getValue(n)
            if (begin < startT - 0.0005f && startT < begin + dur) sfx.play(n, projectNow.sfv.toFloat(), startT - begin)
        }
        try {
            var last = withFrameNanos { it }
            var checked = startT - 0.0005f
            while (true) {
                val now = withFrameNanos { it }
                val dt = (now - last) / 1_000_000_000f
                last = now
                val heard = p != null && runCatching { p.isPlaying }.getOrDefault(false)
                val after = if (heard && p != null) p.currentPosition / 1000f else player.time + dt
                player.time = after
                for (c in projectNow.cards) {
                    val n = SfxSynth.nameFor(c, projectNow) ?: continue
                    val begin = c.s.toFloat() - (SfxSynth.LEAD[n] ?: 0f)
                    if (begin > checked && begin <= after) sfx.play(n, projectNow.sfv.toFloat())
                }
                checked = after
                if (after >= totalNow) {
                    player.time = totalNow
                    player.playing = false
                    break
                }
            }
        } finally {
            runCatching { p?.pause() }
            sfx.stopAll()
        }
    }

    val shown = player.time.coerceIn(0f, total)
    val (pw, ph) = when (project.asp) {
        "9:16" -> 720 to 1280
        "1:1" -> 720 to 720
        else -> 1280 to 720
    }
    // With the keyboard open there is no room for the picture and timeline.
    val keyboardOpen = WindowInsets.ime.getBottom(LocalDensity.current) > 0
    val showFull = expanded && !keyboardOpen

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 2.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            val buttonPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp)
            Button(
                onClick = {
                    if (player.playing) {
                        player.playing = false
                    } else {
                        if (player.time >= total - 0.05f) player.time = 0f
                        player.playing = true
                    }
                },
                contentPadding = buttonPadding,
            ) { Text(if (player.playing) "Pause" else "Play") }
            OutlinedButton(
                onClick = {
                    player.playing = false
                    player.time = 0f
                    runCatching { voice?.seekTo(0) }
                },
                contentPadding = buttonPadding,
            ) { Text("Stop") }
            Text("${clock(shown)} / ${clock(total)}", modifier = Modifier.weight(1f))
            TextButton(onClick = onToggle) { Text(if (expanded) "Hide" else "Show") }
        }

        if (showFull) {
            Box(modifier = Modifier.fillMaxWidth().heightIn(max = 220.dp), contentAlignment = Alignment.Center) {
                Canvas(modifier = Modifier.aspectRatio(pw.toFloat() / ph).background(Color.Black)) {
                    val t = player.time.coerceIn(0f, (totalNow - 0.001f).coerceAtLeast(0f))
                    drawFrame(projectNow, t, pw, ph, fonts, images)
                }
            }
            MultiTrackTimeline(
                project = project,
                total = total,
                time = shown,
                playing = player.playing,
                onSeek = { player.playing = false; player.time = it },
                onSelect = { saveNow(projectNow.copy(sel = it)) },
                onCardsChange = { cards -> saveNow(projectNow.copy(cards = cards)) },
            )
        }
    }
}

/** A moment of the card when its entrance animation and transition are done. */
internal fun settledTime(project: Project, card: NewsCard): Float {
    val settle = max(project.td, project.ad) + 0.15
    return min(card.s + settle, card.e - 0.05).coerceAtLeast(card.s).toFloat()
}

private fun DrawScope.drawFrame(project: Project, t: Float, pw: Int, ph: Int, fonts: Fonts, images: ImageCache) {
    val native = drawContext.canvas.nativeCanvas
    native.save()
    native.scale(size.width / pw, size.height / ph)
    FrameRenderer.draw(native, project, t, pw, ph, fonts, images)
    native.restore()
}

private fun makePlayer(file: File): MediaPlayer? {
    if (!file.exists()) return null
    return runCatching {
        MediaPlayer().apply {
            setDataSource(file.absolutePath)
            prepare()
        }
    }.getOrNull()
}

/** m:ss, fm() in the WebView app. */
internal fun clock(seconds: Float): String {
    val s = seconds.toInt().coerceAtLeast(0)
    return "${s / 60}:${(s % 60).toString().padStart(2, '0')}"
}
