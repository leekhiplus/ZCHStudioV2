package com.zch.newscard

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.util.Base64
import java.io.File
import java.io.FileOutputStream

/**
 * Encodes frames as fast as the phone can (not real-time like MediaRecorder).
 * Timestamps come from the frame number, so timing is exact.
 * The voiceover (sent from JS via audioBegin/audioChunk/audioEnd) is mixed in at finish().
 */
class VideoExporter(private val ctx: Context) {

    private var codec: MediaCodec? = null
    private var muxer: MediaMuxer? = null
    private var file: File? = null
    private var name = ""
    private var track = -1
    private var muxerStarted = false
    private var w = 0
    private var h = 0
    private var fps = 30
    private var frameNo = 0L
    private var pixels = IntArray(0)
    private var yuv = ByteArray(0)
    private val info = MediaCodec.BufferInfo()

    private var voiceOut: FileOutputStream? = null
    private var voiceFile: File? = null
    private var voiceOk = false

    fun start(width: Int, height: Int, rate: Int, bitrate: Int, fileName: String): Boolean {
        cancel()
        // H.264 needs even dimensions
        w = width and 1.inv()
        h = height and 1.inv()
        fps = if (rate > 0) rate else 30
        frameNo = 0
        name = fileName
        pixels = IntArray(w * h)
        yuv = ByteArray(w * h * 3 / 2)
        return try {
            val format = MediaFormat.createVideoFormat("video/avc", w, h).apply {
                setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420SemiPlanar)
                setInteger(MediaFormat.KEY_BIT_RATE, bitrate)
                setInteger(MediaFormat.KEY_FRAME_RATE, fps)
                setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
            }
            val c = MediaCodec.createEncoderByType("video/avc")
            c.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            c.start()
            codec = c
            val f = File(ctx.cacheDir, "export.mp4")
            file = f
            muxer = MediaMuxer(f.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            true
        } catch (e: Exception) {
            cancel()
            false
        }
    }

    fun frame(jpeg: ByteArray): Boolean {
        val c = codec ?: return false
        val src = BitmapFactory.decodeByteArray(jpeg, 0, jpeg.size) ?: return false
        val bmp = if (src.width == w && src.height == h) src else Bitmap.createScaledBitmap(src, w, h, true)
        bmp.getPixels(pixels, 0, w, 0, 0, w, h)
        if (bmp !== src) bmp.recycle()
        src.recycle()
        toNV12()

        var idx = -1
        while (idx < 0) {
            drain(false)
            idx = c.dequeueInputBuffer(10_000)
        }
        val buf = c.getInputBuffer(idx) ?: return false
        buf.clear()
        buf.put(yuv, 0, w * h * 3 / 2)
        c.queueInputBuffer(idx, 0, w * h * 3 / 2, frameNo * 1_000_000L / fps, 0)
        frameNo++
        drain(false)
        return true
    }

    // ---- voiceover from JavaScript ----

    fun voiceBegin(): Boolean {
        voiceOk = false
        return try {
            voiceOut?.close()
            voiceFile?.delete()
            val f = File(ctx.cacheDir, "voice.src")
            voiceFile = f
            voiceOut = FileOutputStream(f)
            true
        } catch (e: Exception) {
            false
        }
    }

    fun voiceChunk(base64: String): Boolean {
        val o = voiceOut ?: return false
        return try {
            o.write(Base64.decode(base64, Base64.DEFAULT))
            true
        } catch (e: Exception) {
            false
        }
    }

    fun voiceEnd(): Boolean {
        return try {
            voiceOut?.close()
            voiceOut = null
            voiceOk = voiceFile != null
            voiceOk
        } catch (e: Exception) {
            false
        }
    }

    // ---- finish / cancel ----

    fun finish(saver: Saver): String {
        val c = codec ?: return "Nothing to save."
        return try {
            var idx = -1
            while (idx < 0) {
                drain(false)
                idx = c.dequeueInputBuffer(10_000)
            }
            c.queueInputBuffer(idx, 0, 0, frameNo * 1_000_000L / fps, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
            drain(true)
            c.stop()
            c.release()
            codec = null
            muxer?.stop()
            muxer?.release()
            muxer = null

            val videoFile = file!!
            val durUs = frameNo * 1_000_000L / fps
            val voice = voiceFile
            val hasVoice = voiceOk && voice != null
            val mixed = File(ctx.cacheDir, "export_mixed.mp4")
            val withAudio = hasVoice && AudioMux.mixVoice(ctx.cacheDir, voice!!, videoFile, mixed, durUs)

            val result = saver.copyFile(if (withAudio) mixed else videoFile, name, "video/mp4")
            val note = if (hasVoice && !withAudio) " (saved without voiceover: the voice file could not be read)" else ""

            videoFile.delete()
            mixed.delete()
            voice?.delete()
            voiceFile = null
            voiceOk = false
            file = null
            result + note
        } catch (e: Exception) {
            cancel()
            "Export failed: ${e.message}"
        }
    }

    fun cancel() {
        try { codec?.stop() } catch (_: Exception) {}
        codec?.release()
        codec = null
        try { muxer?.stop() } catch (_: Exception) {}
        muxer?.release()
        muxer = null
        file?.delete()
        file = null
        muxerStarted = false
        track = -1
    }

    /** ARGB pixels -> NV12 (Y plane, then interleaved U/V at half resolution). */
    private fun toNV12() {
        val ySize = w * h
        for (j in 0 until h) {
            for (i in 0 until w) {
                val p = pixels[j * w + i]
                val r = (p shr 16) and 0xFF
                val g = (p shr 8) and 0xFF
                val b = p and 0xFF
                val y = ((66 * r + 129 * g + 25 * b + 128) shr 8) + 16
                yuv[j * w + i] = y.coerceIn(0, 255).toByte()
            }
        }
        var j = 0
        while (j < h) {
            var i = 0
            while (i < w) {
                val p = pixels[j * w + i]
                val r = (p shr 16) and 0xFF
                val g = (p shr 8) and 0xFF
                val b = p and 0xFF
                val u = ((-38 * r - 74 * g + 112 * b + 128) shr 8) + 128
                val v = ((112 * r - 94 * g - 18 * b + 128) shr 8) + 128
                val o = ySize + (j / 2) * w + i
                yuv[o] = u.coerceIn(0, 255).toByte()
                yuv[o + 1] = v.coerceIn(0, 255).toByte()
                i += 2
            }
            j += 2
        }
    }

    private fun drain(endOfStream: Boolean) {
        val c = codec ?: return
        while (true) {
            val o = c.dequeueOutputBuffer(info, 10_000)
            if (o == MediaCodec.INFO_TRY_AGAIN_LATER) {
                if (!endOfStream) return else continue
            }
            if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                track = muxer!!.addTrack(c.outputFormat)
                muxer!!.start()
                muxerStarted = true
                continue
            }
            if (o < 0) continue
            val buf = c.getOutputBuffer(o)
            if (buf != null && info.size > 0 && (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0 && muxerStarted) {
                buf.position(info.offset)
                buf.limit(info.offset + info.size)
                muxer!!.writeSampleData(track, buf, info)
            }
            c.releaseOutputBuffer(o, false)
            if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) return
        }
    }
}
