package com.zch.newscard

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat

/**
 * Foreground service that keeps the export alive when the app goes to the background.
 * It shows a progress notification and holds a partial wake lock so the CPU keeps running
 * with the screen off. The rendering itself still runs in the WebView, which is kept active
 * during export (see MainActivity).
 */
class ExportService : Service() {

    private var wake: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_PROGRESS -> updateNotification(intent.getIntExtra(EXTRA_PCT, 0))
            ACTION_STOP -> stopRendering()
            else -> startRendering()
        }
        return START_NOT_STICKY
    }

    private fun startRendering() {
        createChannel()
        ServiceCompat.startForeground(
            this,
            NOTIF_ID,
            buildNotification(0),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
        )
        if (wake == null) {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "zch:export").apply {
                setReferenceCounted(false)
                acquire(6 * 60 * 60 * 1000L)
            }
        }
    }

    private fun updateNotification(percent: Int) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(NOTIF_ID, buildNotification(percent))
    }

    private fun stopRendering() {
        releaseWake()
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        releaseWake()
        super.onDestroy()
    }

    private fun releaseWake() {
        wake?.let { if (it.isHeld) it.release() }
        wake = null
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Video export", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(percent: Int): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_upload)
            .setContentTitle("Rendering video")
            .setContentText("$percent% done. Keep this running until it is saved.")
            .setProgress(100, percent, false)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()

    companion object {
        private const val CHANNEL_ID = "export"
        private const val NOTIF_ID = 42
        private const val ACTION_PROGRESS = "com.zch.newscard.PROGRESS"
        private const val ACTION_STOP = "com.zch.newscard.STOP"
        private const val EXTRA_PCT = "pct"

        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, ExportService::class.java))
        }

        fun progress(ctx: Context, percent: Int) {
            ctx.startService(
                Intent(ctx, ExportService::class.java)
                    .setAction(ACTION_PROGRESS)
                    .putExtra(EXTRA_PCT, percent.coerceIn(0, 100))
            )
        }

        fun stop(ctx: Context) {
            ctx.startService(Intent(ctx, ExportService::class.java).setAction(ACTION_STOP))
        }
    }
}
