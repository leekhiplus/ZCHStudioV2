package com.zch.studio.gemini

import android.content.Context
import com.zch.studio.audio.AudioImport
import com.zch.studio.model.NewsCard
import com.zch.studio.model.Project
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.max
import kotlin.math.roundToInt

/** Turns card scripts into one voiceover file and sets every card's start and end from its spoken length. */
object VoiceBuilder {

    private const val GAP = 0.35
    private const val MIN_SPOKEN_CARD = 1.5

    /** Returns a project whose cards are timed to the new voiceover. onProgress gets (card number, cards with script). */
    fun build(context: Context, project: Project, key: String, onProgress: (Int, Int) -> Unit): Project {
        val scripted = project.cards.count { it.script.isNotBlank() }
        if (scripted == 0) throw IllegalArgumentException("No card has a script yet. Write scripts below, or use Text to make cards.")

        // Phase 1: speech for every card that has a script.
        var done = 0
        val speech: List<GeminiClient.Pcm?> = project.cards.map { card ->
            if (card.script.isBlank()) {
                null
            } else {
                onProgress(++done, scripted)
                GeminiClient.speak(card.script, project.gm, project.gv, project.gs, key).let { Pcm16.trim(it) }
            }
        }
        val rate = speech.firstNotNullOf { it }.rate
        if (speech.any { it != null && it.rate != rate }) throw GeminiException("Voice sample rate changed between cards")

        // Phase 2: lay the cards end to end. Cards without a script keep their old length as silence.
        val pcm = ByteArrayOutputStream()
        var cursor = 0.0
        val cards = project.cards.mapIndexed { i, card ->
            val spoken = speech[i]
            val length = if (spoken != null) {
                max(MIN_SPOKEN_CARD, spoken.bytes.size / 2.0 / rate + GAP)
            } else {
                max(1.0, card.e - card.s)
            }
            val wanted = (length * rate).roundToInt() * 2
            if (spoken != null) pcm.write(spoken.bytes, 0, minOf(spoken.bytes.size, wanted))
            pcm.write(ByteArray(wanted - minOf(spoken?.bytes?.size ?: 0, wanted)))
            val start = cursor
            cursor += wanted / 2.0 / rate
            if (spoken != null) {
                val speechSec = spoken.bytes.size / 2.0 / rate
                val times = wordTimes(card.script, speechSec)
                card.copy(s = start, e = cursor, vd = cursor - start, vw = times.first, wt = times.second)
            } else {
                card.copy(s = start, e = cursor, vd = 0.0, vw = emptyList(), wt = emptyList())
            }
        }

        AudioImport.voiceFile(context).writeBytes(wav(pcm.toByteArray(), rate))
        return project.copy(cards = cards, audioName = "Gemini voice", audioSec = cursor, endm = "voice")
    }

    /** Words of the script with an estimated start time each: longer words and words before a pause take more time. */
    private fun wordTimes(script: String, speechSec: Double): Pair<List<String>, List<Double>> {
        val words = script.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (words.isEmpty()) return emptyList<String>() to emptyList()
        val pause = Regex("[.!?۔،,؟:;]$")
        val weights = words.map { it.length + (if (pause.containsMatchIn(it)) 2 else 0) }
        val total = weights.sum().toDouble().coerceAtLeast(1.0)
        var acc = 0.0
        val times = weights.map { w ->
            val t = acc / total * speechSec
            acc += w
            Math.round(t * 100) / 100.0
        }
        return words to times
    }

    /** 16-bit mono PCM wrapped in a WAV header. */
    private fun wav(pcm: ByteArray, rate: Int): ByteArray {
        val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        header.put("RIFF".toByteArray()).putInt(36 + pcm.size).put("WAVE".toByteArray())
        header.put("fmt ".toByteArray()).putInt(16).putShort(1).putShort(1)
        header.putInt(rate).putInt(rate * 2).putShort(2).putShort(16)
        header.put("data".toByteArray()).putInt(pcm.size)
        return header.array() + pcm
    }
}

/** Adds cards from Gemini drafts, styled like the selected card. replace = true swaps all cards, otherwise they go at the end. */
fun Project.withDrafts(drafts: List<GeminiClient.Draft>, replace: Boolean): Project {
    val base = cards.getOrNull(sel) ?: NewsCard()
    val start = if (replace) 0.0 else (cards.maxOfOrNull { it.e } ?: 0.0)
    var t0 = start
    val made = drafts.map { d ->
        val words = d.script.ifBlank { d.desc }.trim().split(Regex("\\s+")).count { it.isNotEmpty() }
        val length = maxOf(3.0, Math.round(words / 2.6 * 10) / 10.0)
        val begin = t0
        t0 += length
        base.copy(
            head = d.head, desc = d.desc, script = d.script,
            src = "", src2 = "", imgs = emptyList(),
            s = begin, e = begin + length, vd = 0.0, vw = emptyList(), wt = emptyList(),
        )
    }
    return if (replace) copy(cards = made, sel = 0) else copy(cards = cards + made, sel = cards.size)
}


/** Cuts silence from the start and end of speech so cards do not carry dead air. */
private object Pcm16 {
    fun trim(pcm: GeminiClient.Pcm): GeminiClient.Pcm {
        val frame = (pcm.rate / 100) * 2
        if (frame <= 0 || pcm.bytes.size < frame * 4) return pcm
        val frames = pcm.bytes.size / frame
        val bb = ByteBuffer.wrap(pcm.bytes).order(ByteOrder.LITTLE_ENDIAN)
        fun loud(f: Int): Boolean {
            var peak = 0
            var i = f * frame
            while (i < (f + 1) * frame) {
                peak = maxOf(peak, kotlin.math.abs(bb.getShort(i).toInt()))
                i += 2
            }
            return peak > 400
        }
        var first = 0
        while (first < frames && !loud(first)) first++
        if (first == frames) return pcm
        var last = frames - 1
        while (last > first && !loud(last)) last--
        val from = maxOf(0, first - 5) * frame
        val to = minOf(frames, last + 12) * frame
        return GeminiClient.Pcm(pcm.bytes.copyOfRange(from, to), pcm.rate)
    }
}
