package com.zch.studio.ui

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.zch.studio.model.Project

private val TEXT_ANIMATIONS = listOf(
    "Fade In", "Slide From Right", "Slide From Left", "Slide From Bottom", "Pop In", "Zoom In", "Slide From Top",
    "Zoom Out", "Bounce Drop", "Spin In", "Flip In", "Wipe (right to left)", "Wipe (left to right)", "No animation",
)
private val PICTURE_ANIMATIONS = listOf(
    "Slow Zoom In", "Slow Zoom Out", "Pan Left", "Pan Right", "Static Image", "Pan Up", "Pan Down",
    "Zoom In + Pan Right", "Zoom Out + Pan Left", "Pulse", "Fast Zoom In",
)
private val TRANSITIONS = listOf(
    "cut" to "Cut", "cross" to "Crossfade", "fade" to "Fade through black", "flash" to "Flash", "push" to "Push",
    "slide" to "Slide from right", "slidel" to "Slide from left", "slideu" to "Slide up", "zoom" to "Zoom in", "wipe" to "Wipe",
)
private val PICTURE_CHANGES = listOf("cross" to "Crossfade", "slide" to "Slide", "zoom" to "Zoom", "flash" to "Flash", "wipe" to "Wipe")

/** Effects tab: animations, transitions, shine, lower third and captions. */
@Composable
fun EffectsScreen(project: Project, onProject: (Project) -> Unit) {
    CardSettings(project, onProject) { card, update ->
        Heading("This card")
        Caption("Text animation")
        IndexChips(TEXT_ANIMATIONS, card.ta) { update(card.copy(ta = it)) }
        Caption("Picture animation")
        IndexChips(PICTURE_ANIMATIONS, card.ia) { update(card.copy(ia = it)) }
        LabeledSlider("Animation speed", card.sp.toFloat(), 0.5f..3f) { update(card.copy(sp = it.toDouble())) }
        Caption("When the picture changes")
        Chips(PICTURE_CHANGES, card.it) { update(card.copy(it = it)) }
        SwitchRow("Small pop when the card starts", card.pz != 0) { update(card.copy(pz = if (it) 1 else 0)) }
        SwitchRow("Captions (needs a Gemini voiceover)", card.cap != 0) { update(card.copy(cap = if (it) 1 else 0)) }

        Heading("Lower third")
        SwitchRow("Tag at the top left", card.ot != 0) { update(card.copy(ot = if (it) 1 else 0)) }
        if (card.ot != 0) {
            OutlinedTextField(
                value = card.ot1, onValueChange = { update(card.copy(ot1 = it)) },
                label = { Text("Red part") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
            )
            OutlinedTextField(
                value = card.ot2, onValueChange = { update(card.copy(ot2 = it)) },
                label = { Text("White part (can be empty)") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
            )
        }
        SwitchRow("Text bar at the bottom", card.ol != 0) { update(card.copy(ol = if (it) 1 else 0)) }
        if (card.ol != 0) {
            OutlinedTextField(
                value = card.lt, onValueChange = { update(card.copy(lt = it)) },
                label = { Text("Bar text (empty uses the headline)") }, modifier = Modifier.fillMaxWidth(),
            )
            Caption("Bar text at the end")
            Chips(listOf("fade" to "Fade out", "slide" to "Slide out", "stay" to "Stay"), card.olx.ifBlank { "fade" }) {
                update(card.copy(olx = it))
            }
            ColorField("Bar color", card.olc) { update(card.copy(olc = it)) }
        }
        SwitchRow("Shine on the tag and bar", card.sh != 0) { update(card.copy(sh = if (it) 1 else 0)) }

        Heading("Whole video")
        Caption("Transition between cards")
        Chips(TRANSITIONS, project.trans) { onProject(project.copy(trans = it)) }
        LabeledSlider("Transition length (s)", project.td.toFloat(), 0.2f..1.5f) { onProject(project.copy(td = it.toDouble())) }
        Caption("Shine sweep")
        Chips(listOf("bars" to "Panels only", "all" to "Whole card", "off" to "Off"), project.ls) { onProject(project.copy(ls = it)) }
        LabeledSlider("Shine strength", project.lsi.toFloat(), 0.1f..1f) { onProject(project.copy(lsi = it.toDouble())) }
        LabeledSlider("Seconds between sweeps", project.lsp.toFloat(), 1f..6f, 1) { onProject(project.copy(lsp = it.toDouble())) }
        Text(
            "Card start sounds (whoosh, pop and others) are not in this version yet.",
            style = MaterialTheme.typography.bodySmall,
        )
    }
}
