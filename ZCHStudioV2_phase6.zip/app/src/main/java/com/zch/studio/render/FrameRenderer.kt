package com.zch.studio.render

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import com.zch.studio.model.NewsCard
import com.zch.studio.model.Project
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

/**
 * Draws one full video frame at project time t, frame() in the WebView app: the current card,
 * the transition from the previous card, the shine sweep, the lower third overlay, captions, the logo and the ticker.
 */
object FrameRenderer {

    private val YELLOW = Color.parseColor("#f5c518")
    private val RED = Color.parseColor("#c8102e")
    private val ALERT = Color.parseColor("#e10600")

    private fun clamp(v: Float, lo: Float, hi: Float) = min(hi, max(lo, v))
    private fun ez(p: Float) = 1f - (1f - p).pow(3)

    /** Frame at project time t, using card start and end times and the project transition. */
    fun draw(canvas: Canvas, project: Project, t: Float, width: Int, height: Int, fonts: Fonts, images: ImageCache) {
        var k = -1
        project.cards.forEachIndexed { i, c -> if (t >= c.s && t < c.e) k = i }
        render(canvas, project, k, t, true, width, height, fonts, images)
    }

    /** One card at project time t with no transition. Used by the editor preview. */
    fun drawCard(canvas: Canvas, project: Project, index: Int, t: Float, width: Int, height: Int, fonts: Fonts, images: ImageCache) {
        render(canvas, project, index, t, false, width, height, fonts, images)
    }

    private fun render(
        canvas: Canvas, project: Project, k: Int, t: Float, transitions: Boolean,
        width: Int, height: Int, fonts: Fonts, images: ImageCache,
    ) {
        val w = width.toFloat()
        val h = height.toFloat()
        val s = min(width, height) / 720f
        val cur = project.cards.getOrNull(k)
        val tickH = if (project.tickOn != 0) 0.075f * h else 0f
        val footer = if (cur?.tpl == 10) 0.07f * h else 0f
        val strip = if (cur != null && cur.tpl in 11..15) 0.06f * h else 0f
        val bottomBars = tickH + footer + strip
        val adDur = project.ad.toFloat()
        val shineAlpha = project.lsi.toFloat()
        val shinePeriod = if (project.lsp > 0.0) project.lsp.toFloat() else 2.4f
        val cu = if (cur != null) t - cur.s.toFloat() else 0f

        canvas.save()
        canvas.drawColor(Color.BLACK)

        fun card(c: NewsCard, tAbs: Float) = CardRenderer.draw(
            canvas, c, tAbs - c.s.toFloat(), width, height, fonts, images, tickH, true, adDur,
            project.ls, shineAlpha, shinePeriod,
        )

        if (cur != null) {
            val pv = project.cards.getOrNull(k - 1)
            val td = if (project.td > 0.0) project.td.toFloat() else 0.6f
            val p = (t - cur.s.toFloat()) / td
            val m = project.trans
            if (transitions && pv != null && p < 1f && m != "cut" && pv.e >= cur.s - 0.05) {
                val q = ez(clamp(p, 0f, 1f))
                val tp = min(t, pv.e.toFloat() - 0.01f)
                when (m) {
                    "fade" -> layer(canvas, w, h, if (q < 0.5f) 1 - q * 2 else (q - 0.5f) * 2) {
                        if (q < 0.5f) card(pv, tp) else card(cur, t)
                    }
                    "flash" -> {
                        if (q < 0.5f) card(pv, tp) else card(cur, t)
                        canvas.drawColor(Color.argb((255 * (1 - abs(q * 2 - 1))).toInt(), 255, 255, 255))
                    }
                    "push" -> {
                        canvas.save(); canvas.translate(-q * w, 0f); card(pv, tp); canvas.restore()
                        canvas.save(); canvas.translate((1 - q) * w, 0f); card(cur, t); canvas.restore()
                    }
                    else -> {
                        card(pv, tp)
                        when (m) {
                            "cross" -> layer(canvas, w, h, q) { card(cur, t) }
                            "slide" -> { canvas.save(); canvas.translate((1 - q) * w, 0f); card(cur, t); canvas.restore() }
                            "slidel" -> { canvas.save(); canvas.translate(-(1 - q) * w, 0f); card(cur, t); canvas.restore() }
                            "slideu" -> { canvas.save(); canvas.translate(0f, (1 - q) * h); card(cur, t); canvas.restore() }
                            "zoom" -> {
                                canvas.save()
                                canvas.translate(w / 2, h / 2)
                                canvas.scale(0.3f + 0.7f * q, 0.3f + 0.7f * q)
                                canvas.translate(-w / 2, -h / 2)
                                layer(canvas, w, h, q) { card(cur, t) }
                                canvas.restore()
                            }
                            "wipe" -> { canvas.save(); canvas.clipRect(w * (1 - q), 0f, w, h); card(cur, t); canvas.restore() }
                            else -> card(cur, t)
                        }
                    }
                }
            } else {
                card(cur, t)
            }
        }

        // Overlays use card time (cu) for their animation, like CU in the WebView app.
        val x = Ctx(canvas, w, h, s, cur ?: NewsCard(), cu, fonts, images, shineMode = project.ls, shineAlpha = shineAlpha, shinePeriod = shinePeriod)
        if (cur != null) {
            if (project.ls == "all") x.shine(0f, 0f, w, h, cu, 1.2f, 0.55f)
            drawOverlay(x, bottomBars)
            drawCaptions(x, bottomBars)
        }
        drawLogo(x, project, bottomBars)
        drawTicker(x, project, t, footer)
        canvas.restore()
    }

    /** Runs block into an offscreen layer that is blended with the given alpha (0 to 1). */
    private inline fun layer(canvas: Canvas, w: Float, h: Float, alpha: Float, block: () -> Unit) {
        val saved = canvas.saveLayerAlpha(0f, 0f, w, h, (clamp(alpha, 0f, 1f) * 255).toInt())
        block()
        canvas.restoreToCount(saved)
    }

    /** Lower-third tag (top left) and text bar, FXO() in the WebView app. */
    private fun drawOverlay(x: Ctx, bottomBars: Float) = with(x) {
        val cd = card
        if (cd.ot == 0 && cd.ol == 0) return@with
        val u = t
        val d = (cd.e - cd.s).toFloat()
        val bot = H - bottomBars

        if (cd.ot != 0) {
            val th = max(30 * S, 0.045f * H)
            val pad = 14 * S
            val x0 = 0.025f * W
            val y0 = 0.035f * H
            val px = th * 0.5f
            val w1 = measure(cd.ot1, px) + 2 * pad
            val w2 = if (cd.ot2.isNotEmpty()) measure(cd.ot2, px) + 2 * pad else 0f
            val tw = w1 + w2
            val q = ez(clamp((u - 0.35f) / 0.4f, 0f, 1f))
            c.save()
            c.translate(-(tw + x0) * (1 - q), 0f)
            rect(x0, y0, w1, th, Color.parseColor("#d70026"))
            centerText(cd.ot1, x0 + w1 / 2, y0 + th / 2, px, Color.WHITE)
            if (cd.ot2.isNotEmpty()) {
                rect(x0 + w1, y0, w2, th, Color.WHITE)
                centerText(cd.ot2, x0 + w1 + w2 / 2, y0 + th / 2, px, Color.parseColor("#d70026"))
            }
            if (cd.sh != 0) shine(x0, y0, tw, th, u, 0.9f)
            c.restore()
        }

        if (cd.ol != 0) {
            val bh = 0.085f * H
            val y = bot - bh
            val q = ez(clamp((u - 0.55f) / 0.45f, 0f, 1f))
            val bw = W * q
            c.save()
            rect(W - bw, y, bw, bh, Ctx.safeColor(cd.olc, Color.parseColor("#0e1a4a")))
            rect(W - bw, y, 6 * S, bh, YELLOW)
            if (cd.sh != 0) shine(W - bw, y, bw, bh, u, 1.1f)
            c.restore()
            val tx = cd.lt.ifBlank { cd.head }.trim()
            if (tx.isNotEmpty() && u >= 1f) {
                val ex = cd.olx.ifBlank { "fade" }
                val qi = ez(clamp((u - 1f) / 0.4f, 0f, 1f))
                val qo = if (ex == "stay") 0f else ez(clamp((u - d * 0.55f) / 0.45f, 0f, 1f))
                val rt = isUrdu(tx)
                var sz = bh * 0.4f
                val mw = measure(tx, sz, false)
                if (mw > 0.9f * W) sz *= 0.9f * W / mw
                val dx = (1 - qi) * 40 * S + (if (ex == "slide") qo * 0.25f * W else 0f)
                c.save()
                c.clipRect(0f, y, W, y + bh)
                centerText(
                    tx, (if (rt) 0.96f * W else 0.04f * W) + dx, y + bh / 2, sz, Color.WHITE,
                    align = if (rt) Paint.Align.RIGHT else Paint.Align.LEFT,
                    alpha = (qi * (1 - qo) * 255).toInt().coerceIn(0, 255),
                )
                c.restore()
            }
        }
    }

    /** Spoken words shown as captions, the current word in yellow, CAP() in the WebView app. */
    private fun drawCaptions(x: Ctx, bottomBars: Float) = with(x) {
        val cd = card
        if (cd.cap == 0 || cd.vd <= 0.0 || cd.vw.isEmpty()) return@with
        val ws = cd.vw
        var wi = 0
        for (i in cd.wt.indices) if (cd.wt[i] <= t) wi = i

        // Groups of up to 8 words and about 44 characters.
        val groups = ArrayList<Pair<Int, Int>>()
        var i = 0
        while (i < ws.size) {
            var j = i
            var len = 0
            while (j < ws.size && (j == i || (j - i < 8 && len + ws[j].length < 44))) {
                len += ws[j].length + 1
                j++
            }
            groups += i to j
            i = j
        }
        val g = groups.firstOrNull { wi < it.second } ?: groups.last()
        val words = ws.subList(g.first, g.second)
        val rt = isUrdu(words.joinToString(" "))
        val sz = 30 * S
        val lh = sz * (if (rt) fonts.urduLineFactor else 1.4f)
        val maxW = 0.9f * W
        val space = measure(" ", sz).let { if (it > 0f) it else sz * 0.3f }
        val wd = words.map { measure(it, sz) }

        val lines = ArrayList<List<Int>>()
        var cur = ArrayList<Int>()
        var cw = 0f
        words.indices.forEach { n ->
            if (cur.isNotEmpty() && cw + space + wd[n] > maxW) {
                lines += cur
                cur = ArrayList()
                cw = 0f
            }
            cw += (if (cur.isNotEmpty()) space else 0f) + wd[n]
            cur += n
        }
        lines += cur

        val bot = H - bottomBars - 0.02f * H - (if (cd.ol != 0) 0.09f * H else 0f)
        val hh = lines.size * lh + 20 * S
        val y0 = bot - hh
        rect(0.04f * W, y0, 0.92f * W, hh, Color.argb(158, 0, 0, 0), radius = 14 * S)
        lines.forEachIndexed { row, li ->
            val lineW = li.sumOf { wd[it].toDouble() }.toFloat() + space * (li.size - 1)
            var px = if (rt) W / 2 + lineW / 2 else W / 2 - lineW / 2
            li.forEach { n ->
                val color = if (g.first + n <= wi) YELLOW else Color.argb(209, 255, 255, 255)
                centerText(words[n], if (rt) px - wd[n] else px, y0 + 10 * S + lh * (row + 0.5f), sz, color, align = Paint.Align.LEFT)
                px += if (rt) -(wd[n] + space) else wd[n] + space
            }
        }
    }

    /** Channel logo. A picture if the project has one, otherwise a red box with the channel name. */
    private fun drawLogo(x: Ctx, p: Project, bottomBars: Float) = with(x) {
        val m = 0.025f * W
        val a = (clamp(p.lop.toFloat(), 0f, 1f) * 255).toInt()
        val bmp = images.get(p.logo)
        val fs = 26 * S * p.lsz.toFloat() / 0.14f
        val w: Float
        val h: Float
        if (bmp != null) {
            w = p.lsz.toFloat() * W
            h = w * bmp.height / bmp.width
        } else {
            w = measure(p.chan, fs) + 30 * S
            h = fs * 1.9f
        }
        val lx = if (p.lpos.getOrNull(1) == 'r') W - m - w else m
        val ly = if (p.lpos.getOrNull(0) == 't') m else H - m - bottomBars - h
        if (bmp != null) {
            drawBitmap(bmp, lx, ly, w, h, a)
        } else if (p.chan.isNotBlank()) {
            rect(lx, ly, w, h, RED, radius = h / 5, alpha = a)
            outline(lx, ly, w, h, h / 5, YELLOW, 2 * S, a)
            centerText(p.chan, lx + w / 2, ly + h / 2, fs, Color.WHITE, alpha = a)
        }
    }

    /** Scrolling news ticker along the bottom, above the footer of template 10. */
    private fun drawTicker(x: Ctx, p: Project, t: Float, footer: Float) = with(x) {
        if (p.tickOn == 0) return@with
        val h = 0.075f * H
        val y = H - footer - h
        val lw = max(0.17f * W, 190 * S)
        rect(0f, y, W, h, Ctx.safeColor(p.tickBg, RED))
        rect(0f, y, W, 3 * S, YELLOW)
        shb(0f, y, W, h)
        val left = p.tdir < 0
        val vx = if (left) lw else 0f
        val vw = W - lw
        c.save()
        c.clipRect(vx, y, vx + vw, y + h)
        val px = h * 0.5f
        val tw = measure(p.tick, px)
        val cycle = tw + vw
        val o = (t * p.tickSpd.toFloat() * S) % cycle
        centerText(
            p.tick, if (left) vx - tw + o else vx + vw - o, y + h / 2, px,
            Ctx.safeColor(p.tickC, Color.WHITE), align = Paint.Align.LEFT,
        )
        c.restore()
        label("BREAKING NEWS", if (left) 6 * S else W - lw + 6 * S, y + h * 0.12f, lw - 12 * S, h * 0.76f, ALERT, Color.WHITE)
    }
}
