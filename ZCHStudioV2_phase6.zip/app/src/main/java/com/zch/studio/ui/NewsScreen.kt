package com.zch.studio.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.zch.studio.gemini.GeminiClient
import com.zch.studio.gemini.SecureKey
import com.zch.studio.gemini.withDrafts
import com.zch.studio.model.Project

private val TEXT_MODELS = listOf("gemini-2.5-flash", "gemini-2.5-flash-lite", "gemini-2.5-pro", "gemini-3.8-flash")

/** News to cards: paste news text and let Gemini write headlines, descriptions and anchor scripts in Urdu. */
@Composable
fun NewsScreen(project: Project, onProject: (Project) -> Unit) {
    val context = LocalContext.current
    val latest by rememberUpdatedState(project)
    val save by rememberUpdatedState(onProject)
    var news by remember { mutableStateOf("") }
    var max by remember { mutableStateOf("6") }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }

    fun makeCards(replace: Boolean) {
        val key = SecureKey.load(context)
        if (key.isEmpty()) { message = "Save your Gemini API key first. It is at the top of the Voice tab."; return }
        if (news.isBlank()) { message = "Paste some news text first."; return }
        busy = true
        message = "Asking Gemini..."
        val model = latest.tm
        val text = news
        val n = max.toInt()
        background({ GeminiClient.newsToCards(text, n, model, key) }) { result ->
            busy = false
            result.onSuccess { drafts ->
                save(latest.withDrafts(drafts, replace))
                message = "Made ${drafts.size} cards. Open the Cards tab to see them."
            }.onFailure { message = it.message ?: "Something went wrong" }
        }
    }

    ScreenColumn {
        Heading("News to cards")
        Caption("Text model")
        Chips(TEXT_MODELS.map { it to it }, project.tm, enabled = !busy) { onProject(project.copy(tm = it)) }
        OutlinedTextField(
            value = project.tm,
            onValueChange = { onProject(project.copy(tm = it.trim())) },
            label = { Text("Model name") },
            singleLine = true,
            enabled = !busy,
            modifier = Modifier.fillMaxWidth(),
        )
        OutlinedTextField(
            value = news,
            onValueChange = { news = it },
            label = { Text("News text") },
            minLines = 6,
            maxLines = 14,
            modifier = Modifier.fillMaxWidth(),
        )
        Caption("Most cards")
        Chips(listOf("4", "6", "8", "12").map { it to it }, max, enabled = !busy) { max = it }
        Text(
            "New cards copy the look of the selected card. Each gets a headline, a short description and an anchor script. Gemini is told to use only facts from your text.",
            style = MaterialTheme.typography.bodySmall,
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { makeCards(true) }, enabled = !busy) { Text("Replace all cards") }
            OutlinedButton(onClick = { makeCards(false) }, enabled = !busy) { Text("Add at end") }
        }
        if (message.isNotEmpty()) Text(message, style = MaterialTheme.typography.bodyMedium)
    }
}
