package com.zch.studio

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.PrimaryScrollableTabRow
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import com.zch.studio.data.ProjectStore
import com.zch.studio.model.Project
import com.zch.studio.ui.CardsScreen
import java.io.File

/** Same nine sections as the WebView app. Only Cards is real so far. */
private val SECTIONS = listOf(
    "Cards", "Edit", "Timing", "Video", "Brand", "Export", "Text", "Effects", "Voice"
)

class MainActivity : ComponentActivity() {

    private val store by lazy { ProjectStore(File(filesDir, "project.json")) }
    private var project by mutableStateOf(Project())
    private var message by mutableStateOf("")

    private val importPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                val text = contentResolver.openInputStream(uri)!!.bufferedReader().use { it.readText() }
                update(store.importOld(text))
                message = "Imported ${project.cards.size} cards."
            } catch (e: Exception) {
                message = "Could not import: this is not a valid project file."
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        project = store.load()
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                AppShell(
                    project = project,
                    message = message,
                    onProject = { update(it) },
                    onImport = { importPicker.launch(arrayOf("application/json", "text/plain", "*/*")) },
                )
            }
        }
    }

    private fun update(p: Project) {
        project = p
        store.save(p)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppShell(
    project: Project,
    message: String,
    onProject: (Project) -> Unit,
    onImport: () -> Unit,
) {
    var selected by remember { mutableIntStateOf(0) }
    Scaffold { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            PrimaryScrollableTabRow(selectedTabIndex = selected) {
                SECTIONS.forEachIndexed { index, title ->
                    Tab(
                        selected = selected == index,
                        onClick = { selected = index },
                        text = { Text(title) },
                    )
                }
            }
            if (selected == 0) {
                CardsScreen(project, message, onProject, onImport)
            } else {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("${SECTIONS[selected]}: coming in the next phase")
                }
            }
        }
    }
}
