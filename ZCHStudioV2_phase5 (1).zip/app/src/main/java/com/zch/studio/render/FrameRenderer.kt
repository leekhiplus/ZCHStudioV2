package com.zch.studio.render

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import com.zch.studio.model.NewsCard
import com.zch.studio.model.Project
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

/**
 * Draws one full video frame at project time t: the current card, the transition from the
 * previous card, the logo and the news ticker. Ported from frame(), LOGO() and TICK()
 * in the WebView app.
 * Not yet ported: lower third overlay (its code was not in the handoff) and the shine effect.
 */
object FrameRenderer {

    private val YELLOW = Color.parseColor("#f5c518")
    private val RED = Color.parseColor("#c8102e")
    private val ALERT = Color.parseColor("#e10600")

    private fun clamp(v: Float, lo: Float, hi: Float) = min(hi, max(lo, v))
    private fun ez(p: Float) = 1f - (1f - p).pow(3)

    /** Frame at project time t, using card start and end times and the project transition. */
    fun draw(canvas: Canvas, project: Project, t: Float, width: Int, height: Int, fonts: Fonts, images: ImageCache) {
        var k = -1
        project.cards.forEachIndexed { i, c -> if (t >= c.s && t < c.e) k = i }
        render(canvas, project, k, t, true, width, height, fonts, images)
    }

    /** One card at project time t with no transition. Used by the editor preview. */
    fun drawCard(canvas: Canvas, project: Project, index: Int, t: Float, width: Int, height: Int, fonts: Fonts, images: ImageCache) {
        render(canvas, project, index, t, false, width, height, fonts, images)
    }

    private fun render(
        canvas: Canvas, project: Project, k: Int, t: Float, transitions: Boolean,
        width: Int, height: Int, fonts: Fonts, images: ImageCache,
    ) {
        val w = width.toFloat()
        val h = height.toFloat()
        val s = min(width, height) / 720f
        val cur = project.cards.getOrNull(k)
        val tickH = if (project.tickOn != 0) 0.075f * h else 0f
        val footer = if (cur?.tpl == 10) 0.07f * h else 0f
        val strip = if (cur != null && cur.tpl in 11..15) 0.06f * h else 0f
        val adDur = project.ad.toFloat()

        canvas.save()
        canvas.drawColor(Color.BLACK)

        fun card(c: NewsCard, tAbs: Float) =
            CardRenderer.draw(canvas, c, tAbs - c.s.toFloat(), width, height, fonts, images, tickH, true, adDur)

        if (cur != null) {
            val pv = project.cards.getOrNull(k - 1)
            val td = if (project.td > 0.0) project.td.toFloat() else 0.6f
            val p = (t - cur.s.toFloat()) / td
            val m = project.trans
            if (transitions && pv != null && p < 1f && m != "cut" && pv.e >= cur.s - 0.05) {
                val q = ez(clamp(p, 0f, 1f))
                val tp = min(t, pv.e.toFloat() - 0.01f)
                when (m) {
                    "fade" -> layer(canvas, w, h, if (q < 0.5f) 1 - q * 2 else (q - 0.5f) * 2) {
                        if (q < 0.5f) card(pv, tp) else card(cur, t)
                    }
                    "flash" -> {
                        if (q < 0.5f) card(pv, tp) else card(cur, t)
                        canvas.drawColor(Color.argb((255 * (1 - abs(q * 2 - 1))).toInt(), 255, 255, 255))
                    }
                    "push" -> {
                        canvas.save(); canvas.translate(-q * w, 0f); card(pv, tp); canvas.restore()
                        canvas.save(); canvas.translate((1 - q) * w, 0f); card(cur, t); canvas.restore()
                    }
                    else -> {
                        card(pv, tp)
                        when (m) {
                            "cross" -> layer(canvas, w, h, q) { card(cur, t) }
                            "slide" -> { canvas.save(); canvas.translate((1 - q) * w, 0f); card(cur, t); canvas.restore() }
                            "slidel" -> { canvas.save(); canvas.translate(-(1 - q) * w, 0f); card(cur, t); canvas.restore() }
                            "slideu" -> { canvas.save(); canvas.translate(0f, (1 - q) * h); card(cur, t); canvas.restore() }
                            "zoom" -> {
                                canvas.save()
                                canvas.translate(w / 2, h / 2)
                                canvas.scale(0.3f + 0.7f * q, 0.3f + 0.7f * q)
                                canvas.translate(-w / 2, -h / 2)
                                layer(canvas, w, h, q) { card(cur, t) }
                                canvas.restore()
                            }
                            "wipe" -> { canvas.save(); canvas.clipRect(w * (1 - q), 0f, w, h); card(cur, t); canvas.restore() }
                            else -> card(cur, t)
                        }
                    }
                }
            } else {
                card(cur, t)
            }
        }

        val x = Ctx(canvas, w, h, s, NewsCard(), t, fonts, images)
        drawLogo(x, project, tickH + footer + strip)
        drawTicker(x, project, t, footer)
        canvas.restore()
    }

    /** Runs block into an offscreen layer that is blended with the given alpha (0 to 1). */
    private inline fun layer(canvas: Canvas, w: Float, h: Float, alpha: Float, block: () -> Unit) {
        val saved = canvas.saveLayerAlpha(0f, 0f, w, h, (clamp(alpha, 0f, 1f) * 255).toInt())
        block()
        canvas.restoreToCount(saved)
    }

    /** Channel logo. A picture if the project has one, otherwise a red box with the channel name. */
    private fun drawLogo(x: Ctx, p: Project, bottomBars: Float) = with(x) {
        val m = 0.025f * W
        val a = (clamp(p.lop.toFloat(), 0f, 1f) * 255).toInt()
        val bmp = images.get(p.logo)
        val fs = 26 * S * p.lsz.toFloat() / 0.14f
        val w: Float
        val h: Float
        if (bmp != null) {
            w = p.lsz.toFloat() * W
            h = w * bmp.height / bmp.width
        } else {
            w = measure(p.chan, fs) + 30 * S
            h = fs * 1.9f
        }
        val lx = if (p.lpos.getOrNull(1) == 'r') W - m - w else m
        val ly = if (p.lpos.getOrNull(0) == 't') m else H - m - bottomBars - h
        if (bmp != null) {
            drawBitmap(bmp, lx, ly, w, h, a)
        } else if (p.chan.isNotBlank()) {
            rect(lx, ly, w, h, RED, radius = h / 5, alpha = a)
            outline(lx, ly, w, h, h / 5, YELLOW, 2 * S, a)
            centerText(p.chan, lx + w / 2, ly + h / 2, fs, Color.WHITE, alpha = a)
        }
    }

    /** Scrolling news ticker along the bottom, above the footer of template 10. */
    private fun drawTicker(x: Ctx, p: Project, t: Float, footer: Float) = with(x) {
        if (p.tickOn == 0) return@with
        val h = 0.075f * H
        val y = H - footer - h
        val lw = max(0.17f * W, 190 * S)
        rect(0f, y, W, h, Ctx.safeColor(p.tickBg, RED))
        rect(0f, y, W, 3 * S, YELLOW)
        val left = p.tdir < 0
        val vx = if (left) lw else 0f
        val vw = W - lw
        c.save()
        c.clipRect(vx, y, vx + vw, y + h)
        val px = h * 0.5f
        val tw = measure(p.tick, px)
        val cycle = tw + vw
        val o = (t * p.tickSpd.toFloat() * S) % cycle
        centerText(
            p.tick, if (left) vx - tw + o else vx + vw - o, y + h / 2, px,
            Ctx.safeColor(p.tickC, Color.WHITE), align = Paint.Align.LEFT,
        )
        c.restore()
        label("BREAKING NEWS", if (left) 6 * S else W - lw + 6 * S, y + h * 0.12f, lw - 12 * S, h * 0.76f, ALERT, Color.WHITE)
    }
}
