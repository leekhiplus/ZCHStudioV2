package com.zch.studio.render

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import com.zch.studio.model.NewsCard
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.round
import kotlin.math.sin

private fun clamp(v: Float, lo: Float, hi: Float): Float = min(hi, max(lo, v))

/** Ease-out cubic, ez() in the WebView app. */
private fun ez(p: Float): Float = 1f - (1f - p).pow(3)

/** Bounce-out, bo() in the WebView app. */
private fun bounce(x: Float): Float = when {
    x < 1f / 2.75f -> 7.5625f * x * x
    x < 2f / 2.75f -> { val y = x - 1.5f / 2.75f; 7.5625f * y * y + .75f }
    x < 2.5f / 2.75f -> { val y = x - 2.25f / 2.75f; 7.5625f * y * y + .9375f }
    else -> { val y = x - 2.625f / 2.75f; 7.5625f * y * y + .984375f }
}

/** Canvas.rotate takes degrees; the WebView code works in radians. */
private val DEG = (180.0 / PI).toFloat()

/**
 * Drawing helpers for one card frame. Ported from the WebView helpers
 * R, T_, LB, IMG, FLAG, PG, IT, TG, SHB, anim and blur.
 * Coordinates are canvas pixels. t is seconds into the card (0 at the card's start).
 */
class Ctx(
    val c: Canvas,
    val W: Float,
    val H: Float,
    /** 1.0 at a 720 px short side, same as the WebView app's S. */
    val S: Float,
    val card: NewsCard,
    val t: Float,
    val fonts: Fonts,
    val images: ImageCache,
    /** Bottom edge of the card area, above any footer or ticker. */
    val B: Float = H,
    /** P.ad in the WebView app: entrance animation length in seconds. */
    val adDur: Float = 0.7f,
    /** Text entrance animation. Off by default so a still preview at t = 0 shows full text. */
    val animate: Boolean = false,
) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    val tc: Int get() = safeColor(card.tc, Color.WHITE)
    val bgc: Int get() = safeColor(card.bg, Color.parseColor("#0a1630"))
    val hasImage: Boolean get() = card.imgs.isNotEmpty() || card.src.isNotEmpty()

    fun firstImage(): String = card.imgs.firstOrNull() ?: card.src

    fun isUrdu(s: String): Boolean = s.any { it in '\u0600'..'\u06FF' }

    private fun typeface(rtl: Boolean, bold: Boolean): Typeface = when {
        rtl -> fonts.urdu
        bold -> fonts.latinBold
        else -> fonts.latinRegular
    }

    private fun lineHeight(size: Float, rtl: Boolean): Float = size * if (rtl) fonts.urduLineFactor else 1.3f

    fun rect(x: Float, y: Float, w: Float, h: Float, color: Int, radius: Float = 0f, alpha: Int = 255) {
        paint.reset()
        paint.isAntiAlias = true
        paint.style = Paint.Style.FILL
        paint.color = color
        paint.alpha = Color.alpha(color) * alpha / 255
        if (radius > 0f) c.drawRoundRect(RectF(x, y, x + w, y + h), radius, radius, paint)
        else c.drawRect(x, y, x + w, y + h, paint)
    }

    /** Vertical gradient unless diagonal is true. */
    fun gradient(x: Float, y: Float, w: Float, h: Float, from: Int, to: Int, diagonal: Boolean = false) {
        paint.reset()
        paint.shader = LinearGradient(
            x, y,
            if (diagonal) x + w else x,
            if (diagonal) y + h else y + h,
            from, to, Shader.TileMode.CLAMP,
        )
        c.drawRect(x, y, x + w, y + h, paint)
        paint.shader = null
    }

    /** Filled circle. */
    fun disc(cx: Float, cy: Float, r: Float, color: Int) {
        paint.reset()
        paint.isAntiAlias = true
        paint.color = color
        c.drawCircle(cx, cy, r, paint)
    }

    /** Parallelogram, PG() in the WebView app. skew moves the top edge to the right. */
    fun para(x: Float, y: Float, w: Float, h: Float, skew: Float, fill: Int, stroke: Int? = null, strokeW: Float = 0f) {
        val path = Path().apply {
            moveTo(x + skew, y)
            lineTo(x + w + skew, y)
            lineTo(x + w, y + h)
            lineTo(x, y + h)
            close()
        }
        paint.reset()
        paint.isAntiAlias = true
        paint.style = Paint.Style.FILL
        paint.color = fill
        c.drawPath(path, paint)
        if (stroke != null) {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = strokeW
            paint.color = stroke
            c.drawPath(path, paint)
            paint.style = Paint.Style.FILL
        }
    }

    /** Wraps text to the given width, in pixels. */
    private fun wrap(s: String, size: Float, tf: Typeface, maxW: Float): List<String> {
        paint.reset()
        paint.typeface = tf
        paint.textSize = size
        val lines = mutableListOf<String>()
        for (para in s.split('\n')) {
            var line = ""
            for (word in para.trim().split(Regex("\\s+"))) {
                if (word.isEmpty()) continue
                val candidate = if (line.isEmpty()) word else "$line $word"
                if (line.isNotEmpty() && paint.measureText(candidate) > maxW) {
                    lines += line
                    line = word
                } else {
                    line = candidate
                }
            }
            lines += line
        }
        return lines
    }

    /** Width of one line of text, in pixels. */
    fun measure(s: String, px: Float, bold: Boolean = true): Float {
        paint.reset()
        paint.typeface = typeface(isUrdu(s), bold)
        paint.textSize = px
        return paint.measureText(s)
    }

    /** Height that text() would use. Same scaling rules as text(). */
    fun textHeight(s: String, w: Float, size: Float, bold: Boolean = true): Float {
        if (s.isBlank()) return 0f
        val rtl = isUrdu(s)
        val px = size * S * card.ts.toFloat()
        val lines = wrap(s, px, typeface(rtl, bold), w)
        return lineHeight(px, rtl) * lines.size
    }

    /**
     * Entrance animation, anim() in the WebView app. Call between c.save() and c.restore().
     * Applies the transform and returns the alpha factor to multiply into the text.
     */
    fun enter(cx: Float, cy: Float): Float {
        val a = card.ta
        if (!animate || a == 13) return 1f
        val u = clamp(t / max(0.2f, adDur / card.sp.toFloat()), 0f, 1f)
        val p = ez(u)
        when (a) {
            1 -> c.translate((1 - p) * W * .5f, 0f)
            2 -> c.translate(-(1 - p) * W * .5f, 0f)
            3 -> c.translate(0f, (1 - p) * H * .3f)
            6 -> c.translate(0f, -(1 - p) * H * .3f)
            8 -> c.translate(0f, -(1 - bounce(u)) * H * .35f)
            11 -> c.clipRect(W * (1 - p), 0f, W, H)
            12 -> c.clipRect(0f, 0f, W * p, H)
            4, 5, 7, 9, 10 -> {
                c.translate(cx, cy)
                if (a == 9) c.rotate(-(1 - p) * 0.9f * DEG)
                if (a == 10) {
                    c.scale(max(.02f, p), 1f)
                } else {
                    val q = when (a) {
                        4 -> 1 + 2.70158f * (p - 1).pow(3) + 1.70158f * (p - 1).pow(2)
                        5 -> .6f + .4f * p
                        7 -> 1.6f - .6f * p
                        else -> .4f + .6f * p
                    }
                    c.scale(q, q)
                }
                c.translate(-cx, -cy)
            }
        }
        return if (a > 10) 1f else p
    }

    /** Wrapped text in the box (x, y, w), centred by default. leftAlign starts lines at x (right edge for Urdu). Returns the height used. */
    fun text(
        s: String, x: Float, y: Float, w: Float, size: Float, color: Int,
        bold: Boolean = true, alpha: Int = 255, leftAlign: Boolean = false,
    ): Float {
        if (s.isBlank()) return 0f
        val rtl = isUrdu(s)
        val px = size * S * card.ts.toFloat()
        val tf = typeface(rtl, bold)
        val lines = wrap(s, px, tf, w)
        val lh = lineHeight(px, rtl)
        val h = lh * lines.size
        c.save()
        val mul = enter(x + w / 2f, y + h / 2f)
        paint.reset()
        paint.isAntiAlias = true
        paint.typeface = tf
        paint.textSize = px
        paint.textAlign = when {
            !leftAlign -> Paint.Align.CENTER
            rtl -> Paint.Align.RIGHT
            else -> Paint.Align.LEFT
        }
        paint.color = color
        paint.alpha = (Color.alpha(color) * alpha / 255f * mul).toInt()
        val fm = paint.fontMetrics
        val mid = -(fm.ascent + fm.descent) / 2f
        val anchorX = when {
            !leftAlign -> x + w / 2f
            rtl -> x + w
            else -> x
        }
        lines.forEachIndexed { i, line ->
            c.drawText(line, anchorX, y + lh * i + lh / 2f + mid, paint)
        }
        c.restore()
        return h
    }

    /** One line of text centred on (cx, cy), absolute pixel size. Picks Urdu or Latin font automatically. */
    fun centerText(
        s: String, cx: Float, cy: Float, px: Float, color: Int,
        bold: Boolean = true, italic: Boolean = false, align: Paint.Align = Paint.Align.CENTER,
        alpha: Int = 255,
    ) {
        if (s.isEmpty()) return
        val rtl = isUrdu(s)
        var tf = typeface(rtl, bold)
        if (italic && !rtl) tf = Typeface.create(tf, Typeface.BOLD_ITALIC)
        paint.reset()
        paint.isAntiAlias = true
        paint.typeface = tf
        paint.textSize = px
        paint.textAlign = align
        paint.color = color
        paint.alpha = Color.alpha(color) * alpha / 255
        val fm = paint.fontMetrics
        c.drawText(s, cx, cy - (fm.ascent + fm.descent) / 2f, paint)
    }

    /** Rounded outline, used for the logo box border. */
    fun outline(x: Float, y: Float, w: Float, h: Float, radius: Float, color: Int, strokeW: Float, alpha: Int = 255) {
        paint.reset()
        paint.isAntiAlias = true
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = strokeW
        paint.color = color
        paint.alpha = Color.alpha(color) * alpha / 255
        c.drawRoundRect(RectF(x, y, x + w, y + h), radius, radius, paint)
    }

    /** Draws a bitmap stretched into the box with the given alpha (0 to 255). */
    fun drawBitmap(bmp: Bitmap, x: Float, y: Float, w: Float, h: Float, alpha: Int = 255) {
        paint.reset()
        paint.isAntiAlias = true
        paint.isFilterBitmap = true
        paint.alpha = alpha
        c.drawBitmap(bmp, null, RectF(x, y, x + w, y + h), paint)
    }

    /** Coloured label box with centred text, like LB() in the WebView app. */
    fun label(s: String, x: Float, y: Float, w: Float, h: Float, bg: Int, fg: Int, alpha: Int = 255) {
        rect(x, y, w, h, bg, radius = h / 4f, alpha = alpha)
        centerText(s, x + w / 2f, y + h / 2f, h * 0.52f, fg)
    }

    /**
     * Picture in a box, IMG() in the WebView app.
     * src == null: the card's pictures, with slideshow, transitions, fit/fill, zoom, position and picture animation.
     * src given: that one picture, drawn plain (blank draws a placeholder gradient).
     */
    fun image(x: Float, y: Float, w: Float, h: Float, src: String? = null) {
        val ad = src == null
        val list = if (src == null) card.imgs.ifEmpty { listOf(card.src) } else listOf(src)
        val n = list.size
        val sg = max(.1f, (card.e - card.s).toFloat() / n)
        val i = (t / sg).toInt().coerceIn(0, n - 1)
        val ts = t - i * sg
        val td = min(.6f, sg * .5f)
        c.save()
        c.clipRect(x, y, x + w, y + h)
        if (n > 1 && i > 0 && ts < td) {
            val q = ez(ts / td)
            val prev = list[i - 1]
            val cur = list[i]
            when (card.it) {
                "slide" -> {
                    drawPicture(x, y, w, h, prev, sg, sg, 1f, ad)
                    c.save()
                    c.translate((1 - q) * w, 0f)
                    drawPicture(x, y, w, h, cur, ts, sg, 1f, ad)
                    c.restore()
                }
                "zoom" -> {
                    drawPicture(x, y, w, h, prev, sg, sg, 1f, ad)
                    c.save()
                    val cx = x + w / 2
                    val cy = y + h / 2
                    val s = 1.3f - .3f * q
                    c.translate(cx, cy)
                    c.scale(s, s)
                    c.translate(-cx, -cy)
                    drawPicture(x, y, w, h, cur, ts, sg, q, ad)
                    c.restore()
                }
                "flash" -> {
                    val useCur = q >= .5f
                    drawPicture(x, y, w, h, if (useCur) cur else prev, if (useCur) ts else sg, sg, 1f, ad)
                    paint.reset()
                    paint.color = Color.WHITE
                    paint.alpha = (255 * (1 - abs(q * 2 - 1)) * .9f).toInt()
                    c.drawRect(x, y, x + w, y + h, paint)
                }
                "wipe" -> {
                    drawPicture(x, y, w, h, prev, sg, sg, 1f, ad)
                    c.save()
                    c.clipRect(x + w * (1 - q), y, x + w, y + h)
                    drawPicture(x, y, w, h, cur, ts, sg, 1f, ad)
                    c.restore()
                }
                else -> {
                    drawPicture(x, y, w, h, prev, sg, sg, 1f, ad)
                    drawPicture(x, y, w, h, cur, ts, sg, q, ad)
                }
            }
        } else {
            drawPicture(x, y, w, h, list[i], ts, sg, 1f, ad)
        }
        c.restore()
    }

    /** One picture at local time tt within its slot of length sg, with alpha al. */
    private fun drawPicture(x: Float, y: Float, w: Float, h: Float, src: String, tt: Float, sg: Float, al: Float, ad: Boolean) {
        val im: Bitmap? = images.get(src)
        if (im == null) {
            paint.reset()
            paint.isAntiAlias = true
            paint.alpha = (255 * al).toInt()
            paint.shader = LinearGradient(
                x, y, x + w, y + h,
                Color.parseColor("#1c2f66"), Color.parseColor("#0a1630"), Shader.TileMode.CLAMP,
            )
            c.drawRect(x, y, x + w, y + h, paint)
            paint.shader = null
            return
        }
        val p = clamp(tt / sg, 0f, 1f)
        var z = 1f
        var px = 0f
        var py = 0f
        when (card.ia) {
            0 -> z = 1 + .15f * p
            1 -> z = 1.15f - .15f * p
            2, 3 -> { z = 1.2f; px = (if (card.ia == 2) -1 else 1) * (p - .5f) * .18f * w }
            5, 6 -> { z = 1.2f; py = (if (card.ia == 5) -1 else 1) * (p - .5f) * .18f * h }
            7 -> { z = 1 + .2f * p; px = (p - .5f) * .12f * w }
            8 -> { z = 1.2f - .2f * p; px = -(p - .5f) * .12f * w }
            9 -> z = 1.06f + .04f * sin(tt * 2.5f)
            10 -> z = 1 + .35f * ez(clamp(tt / 1.5f, 0f, 1f))
        }
        if (card.pz != 0) z *= 1 + .07f * max(0f, 1 - tt / .4f)
        val fit = ad && card.fit == "fit"
        val zm = if (ad) card.iz.toFloat() else 1f
        val fx = if (ad) card.fx.toFloat() / 100f else .5f
        val fy = if (ad) card.fy.toFloat() / 100f else .5f
        val base = if (fit) min(w / im.width, h / im.height) else max(w / im.width, h / im.height)
        val r = base * zm * z
        val dw = im.width * r
        val dh = im.height * r
        if (fit || zm < 1f) blurFill(im, x, y, w, h, al)
        val left = x + (w - dw) * fx + px
        val top = y + (h - dh) * fy + py
        paint.reset()
        paint.isAntiAlias = true
        paint.isFilterBitmap = true
        paint.alpha = (255 * al).toInt()
        c.drawBitmap(im, null, RectF(left, top, left + dw, top + dh), paint)
    }

    /** Blurred cover fill behind a fitted picture, blur() in the WebView app. */
    private fun blurFill(im: Bitmap, x: Float, y: Float, w: Float, h: Float, al: Float) {
        val bw = 24
        val bh = max(8, round(24f * h / w).toInt())
        val small = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        val k = max(bw.toFloat() / im.width, bh.toFloat() / im.height)
        val dw = im.width * k
        val dh = im.height * k
        Canvas(small).drawBitmap(
            im, null,
            RectF((bw - dw) / 2, (bh - dh) / 2, (bw + dw) / 2, (bh + dh) / 2), null,
        )
        paint.reset()
        paint.isAntiAlias = true
        paint.isFilterBitmap = true
        paint.alpha = (255 * al).toInt()
        c.drawBitmap(small, null, RectF(x, y, x + w, y + h), paint)
    }

    /** Circular flag badge with a yellow ring and the team name below it, FLAG() in the WebView app. */
    fun flag(name: String, cx: Float, cy: Float, r: Float) {
        c.save()
        val circle = Path().apply { addCircle(cx, cy, r, Path.Direction.CW) }
        c.clipPath(circle)
        val isPak = name.contains("pak", ignoreCase = true) || name.contains("پاک")
        if (isPak) {
            rect(cx - r, cy - r, 2 * r, 2 * r, Color.parseColor("#01411c"))
            rect(cx - r, cy - r, r * 0.5f, 2 * r, Color.WHITE)
            disc(cx + r * 0.1f, cy, r * 0.5f, Color.WHITE)
            disc(cx + r * 0.25f, cy - r * 0.08f, r * 0.42f, Color.parseColor("#01411c"))
        } else {
            rect(cx - r, cy - r, 2 * r, 2 * r, Color.parseColor("#24418f"))
            centerText(name.replace(" ", "").take(3).uppercase(), cx, cy, r * 0.6f, Color.WHITE)
        }
        c.restore()
        paint.reset()
        paint.isAntiAlias = true
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 3 * S
        paint.color = Color.parseColor("#f5c518")
        c.drawCircle(cx, cy, r, paint)
        centerText(name, cx, cy + r + 26 * S, 24 * S, Color.WHITE)
    }

    companion object {
        fun safeColor(s: String, fallback: Int): Int =
            runCatching { Color.parseColor(s) }.getOrDefault(fallback)
    }
}
