package com.zch.studio.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.zch.studio.gemini.GeminiClient
import com.zch.studio.gemini.SecureKey
import com.zch.studio.gemini.withDrafts
import com.zch.studio.model.Project

private val TEXT_MODELS = listOf("gemini-2.5-flash", "gemini-2.5-flash-lite", "gemini-2.5-pro", "gemini-3.8-flash")

/** Text tab: Gemini API key, and turning pasted news text into cards with headline, description and anchor script. */
@Composable
fun TextScreen(project: Project, onProject: (Project) -> Unit) {
    val context = LocalContext.current
    val latest by rememberUpdatedState(project)
    val save by rememberUpdatedState(onProject)
    var typedKey by remember { mutableStateOf("") }
    var hasKey by remember { mutableStateOf(SecureKey.load(context).isNotEmpty()) }
    var news by remember { mutableStateOf("") }
    var count by remember { mutableIntStateOf(5) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }

    fun makeCards(replace: Boolean) {
        val key = SecureKey.load(context)
        if (key.isEmpty()) { message = "Save your Gemini API key first."; return }
        if (news.isBlank()) { message = "Paste some news text first."; return }
        busy = true
        message = "Asking Gemini..."
        val model = latest.tm
        val text = news
        val n = count
        background({ GeminiClient.newsToCards(text, n, model, key) }) { result ->
            busy = false
            result.onSuccess { drafts ->
                save(latest.withDrafts(drafts, replace))
                message = "Made ${drafts.size} cards. See them in the Cards tab."
            }.onFailure { message = it.message ?: "Something went wrong" }
        }
    }

    Column(
        modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("Gemini API key", style = MaterialTheme.typography.titleMedium)
        Text(
            if (hasKey) "A key is saved on this phone, encrypted." else "No key saved yet.",
            style = MaterialTheme.typography.bodySmall,
        )
        OutlinedTextField(
            value = typedKey,
            onValueChange = { typedKey = it },
            label = { Text(if (hasKey) "Replace key" else "Paste key") },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth(),
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = {
                    runCatching { SecureKey.save(context, typedKey) }
                        .onSuccess { hasKey = true; typedKey = ""; message = "Key saved." }
                        .onFailure { message = "Could not save the key: " + (it.message ?: "") }
                },
                enabled = typedKey.isNotBlank(),
            ) { Text("Save key") }
            if (hasKey) {
                OutlinedButton(onClick = { SecureKey.clear(context); hasKey = false; message = "Key removed." }) { Text("Remove key") }
            }
        }

        Text("News to cards", style = MaterialTheme.typography.titleMedium)
        Text("Text model", style = MaterialTheme.typography.labelMedium)
        Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TEXT_MODELS.forEach { m ->
                FilterChip(selected = project.tm == m, onClick = { onProject(project.copy(tm = m)) }, label = { Text(m) })
            }
        }
        OutlinedTextField(
            value = project.tm,
            onValueChange = { onProject(project.copy(tm = it.trim())) },
            label = { Text("Model name") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )
        OutlinedTextField(
            value = news,
            onValueChange = { news = it },
            label = { Text("News text") },
            minLines = 6,
            maxLines = 14,
            modifier = Modifier.fillMaxWidth(),
        )
        Text("Number of cards", style = MaterialTheme.typography.labelMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(3, 5, 8).forEach { n ->
                FilterChip(selected = count == n, onClick = { count = n }, label = { Text("$n") })
            }
        }
        Text(
            "New cards copy the look of the selected card. Each gets a headline, a description and an anchor script.",
            style = MaterialTheme.typography.bodySmall,
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { makeCards(true) }, enabled = !busy) { Text("Replace all cards") }
            OutlinedButton(onClick = { makeCards(false) }, enabled = !busy) { Text("Add at end") }
        }
        if (message.isNotEmpty()) Text(message, style = MaterialTheme.typography.bodyMedium)
    }
}
