package com.zch.studio.ui

import android.media.MediaPlayer
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.zch.studio.audio.AudioImport
import com.zch.studio.model.Project
import com.zch.studio.model.totalDuration
import com.zch.studio.render.Fonts
import com.zch.studio.render.FrameRenderer
import com.zch.studio.render.ImageCache
import java.io.File

/** Timing tab: live preview of the whole video, play and pause, scrub bar and a card timeline. */
@Composable
fun TimelineScreen(project: Project, onProject: (Project) -> Unit) {
    val context = LocalContext.current
    val fonts = remember { Fonts(context) }
    val images = remember { ImageCache() }

    val total = project.totalDuration()
    val totalNow by rememberUpdatedState(total)
    var time by remember { mutableFloatStateOf(0f) }
    var playing by remember { mutableStateOf(false) }

    // Voiceover player. Rebuilt when a different audio file is chosen.
    val voiceFile = AudioImport.voiceFile(context)
    val voice = remember(project.audioName, project.audioSec, voiceFile.lastModified()) {
        if (project.audioName.isEmpty()) null else makePlayer(voiceFile)
    }
    DisposableEffect(voice) { onDispose { runCatching { voice?.release() } } }

    // Advances time while playing. When the voiceover is sounding, its clock drives the time so picture and voice stay in sync.
    LaunchedEffect(playing) {
        if (!playing) return@LaunchedEffect
        val p = voice
        runCatching {
            if (p != null && time * 1000f < p.duration) {
                p.seekTo((time * 1000f).toInt())
                p.start()
            }
        }
        try {
            var last = withFrameNanos { it }
            while (true) {
                val now = withFrameNanos { it }
                val dt = (now - last) / 1_000_000_000f
                last = now
                val heard = p != null && runCatching { p.isPlaying }.getOrDefault(false)
                time = if (heard && p != null) p.currentPosition / 1000f else time + dt
                if (time >= totalNow) {
                    time = totalNow
                    playing = false
                    break
                }
            }
        } finally {
            runCatching { p?.pause() }
        }
    }

    val (pw, ph) = when (project.asp) {
        "9:16" -> 720 to 1280
        "1:1" -> 720 to 720
        else -> 1280 to 720
    }
    val shown = time.coerceIn(0f, total)
    val currentIndex = project.cards.indexOfLast { shown >= it.s && shown < it.e }

    Column(
        modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(pw.toFloat() / ph)
                .background(Color.Black),
        ) {
            drawFrame(project, time.coerceIn(0f, (totalNow - 0.001f).coerceAtLeast(0f)), pw, ph, fonts, images)
        }

        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Button(onClick = {
                if (playing) {
                    playing = false
                } else {
                    if (time >= total - 0.05f) time = 0f
                    playing = true
                }
            }) { Text(if (playing) "Pause" else "Play") }
            OutlinedButton(onClick = {
                playing = false
                time = 0f
                runCatching { voice?.seekTo(0) }
            }) { Text("Stop") }
            Text("${clock(shown)} / ${clock(total)}", style = MaterialTheme.typography.bodyMedium)
        }

        Slider(
            value = shown,
            onValueChange = { playing = false; time = it },
            valueRange = 0f..total,
        )

        TimelineStrip(
            project = project,
            time = shown,
            total = total,
            onSeek = { t ->
                playing = false
                time = t
                val i = project.cards.indexOfLast { t >= it.s && t < it.e }
                if (i >= 0 && i != project.sel) onProject(project.copy(sel = i))
            },
        )

        val label = project.cards.getOrNull(currentIndex)?.let { "Card ${currentIndex + 1}: ${it.head.ifBlank { "(empty)" }}" }
            ?: "No card at this time"
        Text(label, style = MaterialTheme.typography.bodySmall)
    }
}

/** One bar per card, placed by its start and end time. Tap to jump. */
@Composable
private fun TimelineStrip(project: Project, time: Float, total: Float, onSeek: (Float) -> Unit) {
    val active = MaterialTheme.colorScheme.primary
    val idle = MaterialTheme.colorScheme.surfaceVariant
    val line = MaterialTheme.colorScheme.onSurface
    Canvas(
        modifier = Modifier
            .fillMaxWidth()
            .height(56.dp)
            .pointerInput(total) {
                detectTapGestures { pos -> onSeek((pos.x / size.width * total).coerceIn(0f, total)) }
            },
    ) {
        val w = size.width
        val h = size.height
        project.cards.forEachIndexed { i, c ->
            val x0 = (c.s / total * w).toFloat()
            val x1 = (c.e / total * w).toFloat()
            drawRect(
                color = if (i == project.sel) active else idle,
                topLeft = Offset(x0 + 1f, 6f),
                size = Size((x1 - x0 - 2f).coerceAtLeast(3f), h - 12f),
            )
        }
        drawRect(color = line, topLeft = Offset(time / total * w - 1.5f, 0f), size = Size(3f, h))
    }
}

private fun DrawScope.drawFrame(project: Project, t: Float, pw: Int, ph: Int, fonts: Fonts, images: ImageCache) {
    val native = drawContext.canvas.nativeCanvas
    native.save()
    native.scale(size.width / pw, size.height / ph)
    FrameRenderer.draw(native, project, t, pw, ph, fonts, images)
    native.restore()
}

/** m:ss, fm() in the WebView app. */
private fun clock(seconds: Float): String {
    val s = seconds.toInt().coerceAtLeast(0)
    return "${s / 60}:${(s % 60).toString().padStart(2, '0')}"
}

private fun makePlayer(file: File): MediaPlayer? {
    if (!file.exists()) return null
    return runCatching {
        MediaPlayer().apply {
            setDataSource(file.absolutePath)
            prepare()
        }
    }.getOrNull()
}
