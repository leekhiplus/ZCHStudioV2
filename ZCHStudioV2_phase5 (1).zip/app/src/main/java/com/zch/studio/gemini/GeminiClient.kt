package com.zch.studio.gemini

import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class GeminiException(message: String) : Exception(message)

/** Minimal Gemini REST client: news text to card drafts, and text to speech. Blocking, call from a background thread. */
object GeminiClient {

    class Draft(val head: String, val desc: String, val script: String)

    /** 16-bit mono PCM audio and its sample rate. */
    class Pcm(val bytes: ByteArray, val rate: Int)

    private const val BASE = "https://generativelanguage.googleapis.com/v1beta/models/"

    fun newsToCards(text: String, count: Int, model: String, key: String): List<Draft> {
        val prompt = "You are a TV news editor. Turn the news text below into exactly $count short video news cards. " +
            "Write in the same language as the text: Urdu stays Urdu, English stays English. " +
            "For each card give: head = a punchy headline of at most 12 words; desc = one supporting sentence; " +
            "script = what the news anchor says aloud for this card, one or two natural spoken sentences. " +
            "Use only facts from the text.\n\nNEWS TEXT:\n$text"
        fun string() = JSONObject().put("type", "STRING")
        val schema = JSONObject()
            .put("type", "ARRAY")
            .put(
                "items",
                JSONObject()
                    .put("type", "OBJECT")
                    .put("properties", JSONObject().put("head", string()).put("desc", string()).put("script", string()))
                    .put("required", JSONArray(listOf("head", "desc", "script"))),
            )
        val body = request(prompt)
            .put("generationConfig", JSONObject().put("responseMimeType", "application/json").put("responseSchema", schema))
        val raw = firstText(post(model, key, body)).trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        val array = try {
            JSONArray(raw)
        } catch (e: Exception) {
            throw GeminiException("Gemini did not return cards in the expected form. Try again.")
        }
        val drafts = (0 until array.length()).map {
            val o = array.getJSONObject(it)
            Draft(o.optString("head"), o.optString("desc"), o.optString("script"))
        }
        if (drafts.isEmpty()) throw GeminiException("Gemini returned no cards")
        return drafts
    }

    fun speak(text: String, model: String, voice: String, style: String, key: String): Pcm {
        val prompt = if (style.isBlank()) text else "Say in this style ($style): $text"
        val body = request(prompt).put(
            "generationConfig",
            JSONObject()
                .put("responseModalities", JSONArray(listOf("AUDIO")))
                .put(
                    "speechConfig",
                    JSONObject().put(
                        "voiceConfig",
                        JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", voice)),
                    ),
                ),
        )
        val parts = parts(post(model, key, body))
        for (i in 0 until parts.length()) {
            val inline = parts.optJSONObject(i)?.optJSONObject("inlineData") ?: continue
            val data = inline.optString("data")
            if (data.isEmpty()) continue
            val rate = Regex("rate=(\\d+)").find(inline.optString("mimeType"))?.groupValues?.get(1)?.toIntOrNull() ?: 24000
            return Pcm(Base64.decode(data, Base64.DEFAULT), rate)
        }
        throw GeminiException("Gemini returned no audio for this text")
    }

    private fun request(prompt: String): JSONObject =
        JSONObject().put(
            "contents",
            JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))),
        )

    private fun parts(reply: JSONObject): JSONArray =
        reply.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
            ?: throw GeminiException(
                "Gemini gave no answer" +
                    (reply.optJSONObject("promptFeedback")?.optString("blockReason")?.takeIf { it.isNotEmpty() }
                        ?.let { " (blocked: $it)" } ?: ""),
            )

    private fun firstText(reply: JSONObject): String {
        val parts = parts(reply)
        val text = StringBuilder()
        for (i in 0 until parts.length()) text.append(parts.optJSONObject(i)?.optString("text").orEmpty())
        if (text.isEmpty()) throw GeminiException("Gemini gave an empty answer")
        return text.toString()
    }

    private fun post(model: String, key: String, body: JSONObject): JSONObject {
        val connection = URL(BASE + model.trim() + ":generateContent").openConnection() as HttpURLConnection
        try {
            connection.requestMethod = "POST"
            connection.doOutput = true
            connection.connectTimeout = 20_000
            connection.readTimeout = 180_000
            connection.setRequestProperty("Content-Type", "application/json")
            connection.setRequestProperty("x-goog-api-key", key)
            connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (code !in 200..299) throw GeminiException(errorText(code, text))
            return JSONObject(text)
        } catch (e: GeminiException) {
            throw e
        } catch (e: java.io.IOException) {
            throw GeminiException("Network problem: " + (e.message ?: "check your internet connection"))
        } finally {
            connection.disconnect()
        }
    }

    private fun errorText(code: Int, body: String): String {
        val message = runCatching { JSONObject(body).getJSONObject("error").getString("message") }.getOrNull()
        val hint = when (code) {
            400, 403 -> " Check the API key and the model name."
            404 -> " This model name was not found."
            429 -> " Quota or rate limit reached. Wait a little and try again."
            else -> ""
        }
        return "Gemini error $code: " + (message ?: "no details") + hint
    }
}
