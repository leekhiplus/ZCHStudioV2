package com.zch.studio.gemini

import android.content.Context
import com.zch.studio.audio.AudioImport
import com.zch.studio.model.NewsCard
import com.zch.studio.model.Project
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.max
import kotlin.math.roundToInt

/** Turns card scripts into one voiceover file and sets every card's start and end from its spoken length. */
object VoiceBuilder {

    private const val GAP = 0.35
    private const val MIN_SPOKEN_CARD = 1.5

    /** Returns a project whose cards are timed to the new voiceover. onProgress gets (card number, cards with script). */
    fun build(context: Context, project: Project, key: String, onProgress: (Int, Int) -> Unit): Project {
        val scripted = project.cards.count { it.script.isNotBlank() }
        if (scripted == 0) throw IllegalArgumentException("No card has a script yet. Write scripts below, or use Text to make cards.")

        // Phase 1: speech for every card that has a script.
        var done = 0
        val speech = project.cards.map { card ->
            if (card.script.isBlank()) {
                null
            } else {
                onProgress(++done, scripted)
                GeminiClient.speak(card.script, project.gm, project.gv, project.gs, key)
            }
        }
        val rate = speech.firstNotNullOf { it }.rate
        if (speech.any { it != null && it.rate != rate }) throw GeminiException("Voice sample rate changed between cards")

        // Phase 2: lay the cards end to end. Cards without a script keep their old length as silence.
        val pcm = ByteArrayOutputStream()
        var cursor = 0.0
        val cards = project.cards.mapIndexed { i, card ->
            val spoken = speech[i]
            val length = if (spoken != null) {
                max(MIN_SPOKEN_CARD, spoken.bytes.size / 2.0 / rate + GAP)
            } else {
                max(1.0, card.e - card.s)
            }
            val wanted = (length * rate).roundToInt() * 2
            if (spoken != null) pcm.write(spoken.bytes, 0, minOf(spoken.bytes.size, wanted))
            pcm.write(ByteArray(wanted - minOf(spoken?.bytes?.size ?: 0, wanted)))
            val start = cursor
            cursor += wanted / 2.0 / rate
            card.copy(s = start, e = cursor)
        }

        AudioImport.voiceFile(context).writeBytes(wav(pcm.toByteArray(), rate))
        return project.copy(cards = cards, audioName = "Gemini voice", audioSec = cursor, endm = "voice")
    }

    /** 16-bit mono PCM wrapped in a WAV header. */
    private fun wav(pcm: ByteArray, rate: Int): ByteArray {
        val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        header.put("RIFF".toByteArray()).putInt(36 + pcm.size).put("WAVE".toByteArray())
        header.put("fmt ".toByteArray()).putInt(16).putShort(1).putShort(1)
        header.putInt(rate).putInt(rate * 2).putShort(2).putShort(16)
        header.put("data".toByteArray()).putInt(pcm.size)
        return header.array() + pcm
    }
}

/** Adds cards from Gemini drafts, styled like the selected card. replace = true swaps all cards, otherwise they go at the end. */
fun Project.withDrafts(drafts: List<GeminiClient.Draft>, replace: Boolean): Project {
    val base = cards.getOrNull(sel) ?: NewsCard()
    val start = if (replace) 0.0 else (cards.maxOfOrNull { it.e } ?: 0.0)
    val made = drafts.mapIndexed { i, d ->
        base.copy(
            head = d.head, desc = d.desc, script = d.script,
            src = "", src2 = "", imgs = emptyList(),
            s = start + i * 5.0, e = start + (i + 1) * 5.0,
        )
    }
    return if (replace) copy(cards = made, sel = 0) else copy(cards = cards + made, sel = cards.size)
}
