package com.zch.studio.export

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.content.Intent
import android.os.Environment
import android.os.PowerManager
import android.provider.MediaStore
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.core.content.ContextCompat
import androidx.compose.runtime.setValue
import com.zch.studio.audio.AudioImport
import com.zch.studio.model.Project
import com.zch.studio.model.totalDuration
import com.zch.studio.render.Fonts
import com.zch.studio.render.ImageCache
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Runs an export (video, optional voiceover, join) on a background thread and exposes progress for the Export tab. Lives as long as the activity. */
class ExportController private constructor(private val app: Context) {

    var running by mutableStateOf(false)
        private set
    var progress by mutableFloatStateOf(0f)
        private set
    var status by mutableStateOf("")
        private set

    @Volatile
    private var cancelled = false
    private var lastPercent = -1

    /** Sets the status text and refreshes the notification. */
    private fun postStatus(text: String) {
        status = text
        ExportNotification.update(app, (progress * 100).toInt(), text)
    }

    /** Called for every frame. Updates the notification only when the whole percent changes. */
    private fun report(value: Float) {
        progress = value
        val percent = (value * 100).toInt()
        if (percent != lastPercent) {
            lastPercent = percent
            ExportNotification.update(app, percent, status)
        }
    }

    fun start(project: Project) {
        if (running) return
        running = true
        cancelled = false
        progress = 0f
        lastPercent = -1
        status = "Rendering video..."
        ExportNotification.ensureChannel(app)
        // Keeps the export running when the app goes to the background. If Android refuses, the export still runs.
        runCatching { ContextCompat.startForegroundService(app, Intent(app, ExportService::class.java)) }
        Thread({
            val wakeLock = app.getSystemService(PowerManager::class.java)
                .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "zch:export")
            wakeLock.acquire(2 * 60 * 60 * 1000L)
            val videoOnly = File(app.cacheDir, "zch-video.mp4")
            val audioAac = File(app.cacheDir, "zch-audio.m4a")
            val finalFile = File(app.cacheDir, "zch-export.mp4")
            try {
                val voice = AudioImport.voiceFile(app)
                val withAudio = project.audioName.isNotEmpty() && voice.exists()
                val share = if (withAudio) 0.85f else 1f
                VideoExporter().export(
                    project, if (withAudio) videoOnly else finalFile,
                    Fonts(app), ImageCache(), { report(it * share) }, { cancelled },
                )
                var note = ""
                if (withAudio) {
                    try {
                        postStatus("Processing audio...")
                        val maxUs = (project.totalDuration() * 1_000_000f).toLong()
                        AudioTranscoder().transcode(voice, audioAac, maxUs) { cancelled }
                        report(0.95f)
                        postStatus("Combining video and audio...")
                        Mp4Mux.combine(videoOnly, audioAac, finalFile, maxUs)
                    } catch (e: VideoExporter.CancelledException) {
                        throw e
                    } catch (e: Throwable) {
                        // Keep the finished video rather than lose it.
                        note = " (without audio: " + (e.message ?: e.javaClass.simpleName) + ")"
                        videoOnly.copyTo(finalFile, overwrite = true)
                    }
                }
                report(1f)
                postStatus("Saving...")
                status = "Saved: " + save(finalFile) + note
            } catch (e: VideoExporter.CancelledException) {
                status = "Export cancelled"
            } catch (e: Throwable) {
                status = "Export failed: " + (e.message ?: e.javaClass.simpleName)
            } finally {
                videoOnly.delete()
                audioAac.delete()
                finalFile.delete()
                runCatching { if (wakeLock.isHeld) wakeLock.release() }
                runCatching { app.stopService(Intent(app, ExportService::class.java)) }
                if (!cancelled) ExportNotification.finished(app, status)
                running = false
            }
        }, "zch-export").start()
    }

    fun cancel() {
        cancelled = true
    }

    /** Android 10 and newer: Movies/ZCH in the gallery. Older: the app's own Movies folder. Returns where it went. */
    private fun save(source: File): String {
        val name = "ZCH-" + SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date()) + ".mp4"
        if (Build.VERSION.SDK_INT >= 29) {
            val resolver = app.contentResolver
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, name)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/ZCH")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("Could not create the video file")
            resolver.openOutputStream(uri)!!.use { out -> source.inputStream().use { it.copyTo(out) } }
            values.clear()
            values.put(MediaStore.Video.Media.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            return "Movies/ZCH/$name"
        }
        val dir = app.getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: app.filesDir
        val dest = File(dir, name)
        source.copyTo(dest, overwrite = true)
        return dest.absolutePath
    }

    companion object {
        @Volatile
        private var instance: ExportController? = null

        /** One controller for the whole process, shared by the screen and the service. */
        fun get(context: Context): ExportController =
            instance ?: synchronized(this) {
                instance ?: ExportController(context.applicationContext).also { instance = it }
            }
    }
}
