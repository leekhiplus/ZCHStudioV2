package com.zch.studio.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.zch.studio.audio.AudioImport
import com.zch.studio.gemini.SecureKey
import com.zch.studio.gemini.VoiceBuilder
import com.zch.studio.model.Project
import com.zch.studio.model.replaceCard

private val TTS_MODELS = listOf("gemini-2.5-flash-preview-tts", "gemini-2.5-pro-preview-tts", "gemini-3.8-flash-tts")
private val VOICES = listOf("Kore", "Puck", "Charon", "Zephyr", "Aoede", "Fenrir", "Leda", "Orus")

/** Voice tab: a voiceover from a file or from Gemini (card scripts), and when the video ends. */
@Composable
fun VoiceScreen(project: Project, onProject: (Project) -> Unit) {
    val context = LocalContext.current
    val latest by rememberUpdatedState(project)
    val save by rememberUpdatedState(onProject)
    var message by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        busy = true
        message = "Importing..."
        val app = context.applicationContext
        background({ AudioImport.import(app, uri) }) { result ->
            busy = false
            result.onSuccess {
                message = ""
                save(latest.copy(audioName = it.name, audioSec = it.seconds))
            }.onFailure { message = it.message ?: "Could not import this file" }
        }
    }

    fun generate() {
        val key = SecureKey.load(context)
        if (key.isEmpty()) { message = "Save your Gemini API key in the Text tab first."; return }
        busy = true
        message = "Starting..."
        val app = context.applicationContext
        val snapshot = latest
        background({
            VoiceBuilder.build(app, snapshot, key) { i, n -> onMain { message = "Making voice for card $i of $n..." } }
        }) { result ->
            busy = false
            result.onSuccess {
                save(latest.copy(cards = it.cards, audioName = it.audioName, audioSec = it.audioSec, endm = it.endm))
                message = "Voiceover ready. Card times now follow the voice. Play it in the Timing tab."
            }.onFailure { message = it.message ?: "Could not make the voiceover" }
        }
    }

    Column(
        modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("Voiceover", style = MaterialTheme.typography.titleMedium)
        if (project.audioName.isEmpty()) {
            Text("No audio yet.")
        } else {
            Text("${project.audioName}  (${project.audioSec.toInt() / 60}:${(project.audioSec.toInt() % 60).toString().padStart(2, '0')})")
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { picker.launch(arrayOf("audio/*")) }, enabled = !busy) {
                Text(if (project.audioName.isEmpty()) "Choose audio file" else "Replace with file")
            }
            if (project.audioName.isNotEmpty()) {
                OutlinedButton(
                    onClick = {
                        AudioImport.remove(context)
                        onProject(project.copy(audioName = "", audioSec = 0.0))
                    },
                    enabled = !busy,
                ) { Text("Remove") }
            }
        }

        Text("Gemini voice", style = MaterialTheme.typography.titleMedium)
        Text("Speech model", style = MaterialTheme.typography.labelMedium)
        Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TTS_MODELS.forEach { m ->
                FilterChip(selected = project.gm == m, onClick = { onProject(project.copy(gm = m)) }, label = { Text(m) }, enabled = !busy)
            }
        }
        OutlinedTextField(
            value = project.gm,
            onValueChange = { onProject(project.copy(gm = it.trim())) },
            label = { Text("Model name") },
            singleLine = true,
            enabled = !busy,
            modifier = Modifier.fillMaxWidth(),
        )
        Text("Voice", style = MaterialTheme.typography.labelMedium)
        Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            VOICES.forEach { v ->
                FilterChip(selected = project.gv == v, onClick = { onProject(project.copy(gv = v)) }, label = { Text(v) }, enabled = !busy)
            }
        }
        OutlinedTextField(
            value = project.gs,
            onValueChange = { onProject(project.copy(gs = it)) },
            label = { Text("Speaking style") },
            enabled = !busy,
            modifier = Modifier.fillMaxWidth(),
        )

        Text("Anchor scripts", style = MaterialTheme.typography.labelMedium)
        project.cards.forEachIndexed { i, card ->
            OutlinedTextField(
                value = card.script,
                onValueChange = { onProject(project.replaceCard(i, card.copy(script = it))) },
                label = { Text("Card ${i + 1}: ${card.head.take(30)}") },
                minLines = 2,
                enabled = !busy,
                modifier = Modifier.fillMaxWidth(),
            )
        }
        Button(onClick = { generate() }, enabled = !busy) { Text("Make voiceover from scripts") }
        Text(
            "Each card is spoken once. Card start and end times are set to the length of its speech, with a short pause. Cards with no script keep their length as silence.",
            style = MaterialTheme.typography.bodySmall,
        )
        if (message.isNotEmpty()) Text(message, style = MaterialTheme.typography.bodyMedium)

        Text("Video ends with", style = MaterialTheme.typography.labelMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(
                selected = project.endm != "card",
                onClick = { onProject(project.copy(endm = "voice")) },
                label = { Text("Audio length") },
            )
            FilterChip(
                selected = project.endm == "card",
                onClick = { onProject(project.copy(endm = "card")) },
                label = { Text("Last card") },
            )
        }
    }
}
