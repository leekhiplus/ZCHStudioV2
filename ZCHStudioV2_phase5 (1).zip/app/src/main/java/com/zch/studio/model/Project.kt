package com.zch.studio.model

import kotlinx.serialization.Serializable

/** Whole project: slides plus output and ticker settings. */
@Serializable
data class Project(
    val cards: List<NewsCard> = listOf(NewsCard()),
    val sel: Int = 0,
    val asp: String = "16:9",
    val res: Int = 720,
    val fps: Int = 30,
    val trans: String = "cross",
    val td: Double = 0.6,
    /** Text entrance animation length in seconds (P.ad in the WebView app). */
    val ad: Double = 0.7,
    val endm: String = "voice",
    val tickOn: Int = 1,
    val tick: String = "بریکنگ نیوز • ZCH NEWS • Zafar Cricket Hub • تازہ ترین خبریں",
    val tickSpd: Double = 120.0,
    val tickC: String = "#ffffff",
    val tickBg: String = "#c8102e",
    /** Ticker direction: 1 scrolls right to left, -1 left to right. */
    val tdir: Int = 1,
    val chan: String = "ZAFAR CRICKET HUB",
    /** Logo picture as a data:image base64 string. Empty means the channel name box is drawn instead. */
    val logo: String = "",
    val lpos: String = "tr",
    val lsz: Double = 0.14,
    val lop: Double = 0.9,
    /** Voiceover file name shown to the user. The audio itself is copied to filesDir/voiceover. Empty means no audio. */
    val audioName: String = "",
    /** Voiceover length in seconds. */
    val audioSec: Double = 0.0,
    /** Gemini text model for news to cards (P.tm). */
    val tm: String = "gemini-3.8-flash",
    /** Gemini speech model (P.gm). */
    val gm: String = "gemini-3.8-flash-tts",
    /** Gemini voice name (P.gv). */
    val gv: String = "Kore",
    /** Speaking style (P.gs). */
    val gs: String = "professional news anchor, clear and steady",
)

/** Helpers that return a new Project. The data stays immutable for Compose. */
fun Project.replaceCard(index: Int, card: NewsCard): Project =
    copy(cards = cards.mapIndexed { i, c -> if (i == index) card else c })

fun Project.addCard(): Project {
    val start = cards.lastOrNull()?.e ?: 0.0
    return copy(cards = cards + NewsCard(s = start, e = start + 5.0), sel = cards.size)
}

fun Project.deleteCard(index: Int): Project {
    if (cards.size <= 1) return copy(cards = listOf(NewsCard()), sel = 0)
    val rest = cards.filterIndexed { i, _ -> i != index }
    return copy(cards = rest, sel = index.coerceAtMost(rest.size - 1))
}

/**
 * Length of the video in seconds, tot() in the WebView app: the voiceover length when there is one
 * and the end mode is not "card", otherwise the end of the last card (at least 0.1 s).
 */
fun Project.totalDuration(): Float {
    val byCards = maxOf(0.1, cards.maxOfOrNull { it.e } ?: 0.1)
    return (if (endm != "card" && audioSec > 0.0) audioSec else byCards).toFloat()
}

/** Output size in pixels, size() in the WebView app. Both sides are made even for the video encoder. */
fun Project.outputSize(): Pair<Int, Int> {
    val long = Math.round(res * 16f / 9f)
    val (w, h) = when (asp) {
        "16:9" -> long to res
        "9:16" -> res to long
        else -> res to res
    }
    return (w / 2 * 2) to (h / 2 * 2)
}
