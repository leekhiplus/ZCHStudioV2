package com.zch.studio.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.zch.studio.media.ImageImport
import com.zch.studio.model.Project
import com.zch.studio.render.ImageCache

private val TOOLS = listOf(ToolDef("Name", "tag"), ToolDef("Logo", "photo"), ToolDef("Position", "frame"))

/** Brand tab: channel name, logo picture, and where the logo sits. */
@Composable
fun BrandScreen(project: Project, onProject: (Project) -> Unit) {
    val context = LocalContext.current
    val latest by rememberUpdatedState(project)
    val save by rememberUpdatedState(onProject)
    val cache = remember { ImageCache() }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }

    val pickLogo = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        busy = true
        message = "Adding logo..."
        val app = context.applicationContext
        background({ ImageImport.toDataUri(app, uri, 512, keepAlpha = true) }) { result ->
            busy = false
            result.onSuccess { save(latest.copy(logo = it)); message = "" }
                .onFailure { message = it.message ?: "Could not add the logo" }
        }
    }
    BusyDialog(busy, message)

    ToolScreen("brand", TOOLS) { tool ->
        when (tool) {
            0 -> {
                OutlinedTextField(
                    value = project.chan,
                    onValueChange = { onProject(project.copy(chan = it)) },
                    label = { Text("Channel name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                Hint("The name is shown in a red box when there is no logo picture.")
            }
            1 -> {
                if (project.logo.isNotEmpty()) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Thumb(cache, project.logo)
                        OutlinedButton(onClick = { onProject(project.copy(logo = "")) }) { Text("Remove logo") }
                    }
                }
                Button(onClick = { pickLogo.launch("image/*") }, enabled = !busy) {
                    Text(if (project.logo.isEmpty()) "Choose logo" else "Replace logo")
                }
                if (message.isNotEmpty() && !busy) Hint(message)
            }
            else -> {
                Choice(
                    "Position",
                    listOf("tl" to "Top left", "tr" to "Top right", "bl" to "Bottom left", "br" to "Bottom right"),
                    project.lpos,
                ) { onProject(project.copy(lpos = it)) }
                LabeledSlider("Size", project.lsz.toFloat(), 0.05f..0.4f) { onProject(project.copy(lsz = it.toDouble())) }
                LabeledSlider("Opacity", project.lop.toFloat(), 0.1f..1f) { onProject(project.copy(lop = it.toDouble())) }
            }
        }
    }
}
