package com.zch.studio.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.zch.studio.model.Project
import com.zch.studio.model.TEMPLATE_NAMES
import com.zch.studio.model.addCard
import com.zch.studio.model.deleteCard
import com.zch.studio.model.duplicateCard
import com.zch.studio.model.replaceCard

private val TOOLS = listOf(
    ToolDef("Cards", "film"), ToolDef("Template", "template"), ToolDef("Text", "text"),
    ToolDef("Scores", "trophy"), ToolDef("News", "lines"),
)

/** Cards tab: the cards as a strip, and tools for the card list, template, text, scores and creating cards from news. */
@Composable
fun CardsScreen(project: Project, onProject: (Project) -> Unit) {
    val cards = project.cards
    val index = project.sel.coerceIn(0, (cards.size - 1).coerceAtLeast(0))
    val card = cards.getOrNull(index)

    ToolScreen(
        key = "cards",
        tools = TOOLS,
        header = {
            Caption("${cards.size} cards. Tap one to edit it.")
            CardStrip(project, onProject)
        },
    ) { tool ->
        when (tool) {
            0 -> {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { onProject(project.addCard()) }) { Text("Add") }
                    OutlinedButton(onClick = { onProject(project.duplicateCard(index)) }, enabled = cards.isNotEmpty()) { Text("Duplicate") }
                    OutlinedButton(onClick = { onProject(project.deleteCard(index)) }, enabled = cards.size > 1) { Text("Delete") }
                }
                Hint("Duplicate copies the selected card right after itself.")
            }
            1 -> if (card != null) {
                PickerRow(
                    label = "Template",
                    selected = card.tpl.toString(),
                    options = TEMPLATE_NAMES.mapIndexed { i, n -> i.toString() to "${i + 1}. $n" },
                ) { onProject(project.replaceCard(index, card.copy(tpl = it.toInt()))) }
                Hint("The template decides how the card looks.")
            }
            2 -> if (card != null) {
                Field("Headline", card.head) { onProject(project.replaceCard(index, card.copy(head = it))) }
                Field("Description", card.desc, minLines = 3) { onProject(project.replaceCard(index, card.copy(desc = it))) }
            }
            3 -> if (card != null) {
                Hint("For sports and versus templates.")
                Field("Name A / team A", card.a) { onProject(project.replaceCard(index, card.copy(a = it))) }
                Field("Name B / team B", card.b) { onProject(project.replaceCard(index, card.copy(b = it))) }
                Field("Value A / score A", card.c) { onProject(project.replaceCard(index, card.copy(c = it))) }
                Field("Value B / score B", card.d) { onProject(project.replaceCard(index, card.copy(d = it))) }
            }
            else -> NewsContent(project, onProject)
        }
    }
}

@Composable
private fun Field(label: String, value: String, minLines: Int = 1, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        minLines = minLines,
        modifier = Modifier.fillMaxWidth(),
    )
}
