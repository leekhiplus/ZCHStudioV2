package com.zch.studio.ui

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.zch.studio.model.NewsCard
import com.zch.studio.model.Project
import com.zch.studio.model.replaceCard
import com.zch.studio.render.Ctx
import com.zch.studio.render.ImageCache
import java.util.Locale

private val BoxColor = Color(0xFF1C1C21)

/** A scrolling screen with the standard padding and spacing. Put Panels in it. */
@Composable
fun ScreenColumn(content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        content = content,
    )
}

@Composable
fun Heading(text: String) {
    Text(text, style = MaterialTheme.typography.titleMedium)
}

@Composable
fun Caption(text: String) {
    Text(text, style = MaterialTheme.typography.labelMedium, color = MutedColor)
}

/** Small grey explanation text. */
@Composable
fun Hint(text: String) {
    Text(text, fontSize = 12.sp, color = MutedColor)
}

/**
 * A titled box, like the groups in CapCut or KineMaster. Tap the title to open or close it.
 * A closed box shows its hint under the title. The open or closed state is remembered.
 */
@Composable
fun Panel(title: String, startOpen: Boolean = true, hint: String = "", content: @Composable ColumnScope.() -> Unit) {
    var open by rememberSaveable(title) { mutableStateOf(startOpen) }
    Surface(color = BoxColor, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth().clickable { open = !open }.padding(horizontal = 14.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(title, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    if (hint.isNotEmpty() && !open) Text(hint, fontSize = 11.sp, color = MutedColor, maxLines = 1)
                }
                Text(if (open) "\u25BE" else "\u25B8", color = MutedColor)
            }
            if (open) {
                Column(
                    modifier = Modifier.padding(start = 14.dp, end = 14.dp, bottom = 14.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    content = content,
                )
            }
        }
    }
}

/** One-choice chips that wrap onto several lines. For short lists. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun Chips(options: List<Pair<String, String>>, selected: String, enabled: Boolean = true, onSelect: (String) -> Unit) {
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        options.forEach { (value, label) ->
            FilterChip(selected = value == selected, onClick = { onSelect(value) }, label = { Text(label) }, enabled = enabled)
        }
    }
}

/** Chips for a list picked by position. */
@Composable
fun IndexChips(labels: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Chips(labels.mapIndexed { i, l -> i.toString() to l }, selected.toString()) { onSelect(it.toInt()) }
}

/** A row that shows the current choice and opens a list to change it. For long lists. */
@Composable
fun PickerRow(label: String, selected: String, options: List<Pair<String, String>>, enabled: Boolean = true, onSelect: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    val shown = options.firstOrNull { it.first == selected }?.second ?: selected
    Row(
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(FieldColor)
            .clickable(enabled = enabled) { open = true }.padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(label, fontSize = 11.sp, color = MutedColor)
            Text(shown, fontSize = 14.sp, maxLines = 1)
        }
        Text("\u25B8", color = MutedColor)
    }
    if (open) {
        AlertDialog(
            onDismissRequest = { open = false },
            title = { Text(label) },
            text = {
                Column(modifier = Modifier.heightIn(max = 400.dp).verticalScroll(rememberScrollState())) {
                    options.forEach { (value, text) ->
                        Row(
                            modifier = Modifier.fillMaxWidth().clickable { onSelect(value); open = false }.padding(vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            RadioButton(selected = value == selected, onClick = null)
                            Text(text, modifier = Modifier.padding(start = 12.dp))
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { open = false }) { Text("Close") } },
        )
    }
}

/** A labelled choice: chips for a short list, a picker row for a long one. */
@Composable
fun Choice(label: String, options: List<Pair<String, String>>, selected: String, enabled: Boolean = true, onSelect: (String) -> Unit) {
    if (options.size > 6) {
        PickerRow(label, selected, options, enabled, onSelect)
    } else {
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Caption(label)
            Chips(options, selected, enabled, onSelect)
        }
    }
}

@Composable
fun IndexChoice(label: String, labels: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Choice(label, labels.mapIndexed { i, l -> i.toString() to l }, selected.toString()) { onSelect(it.toInt()) }
}

@Composable
fun LabeledSlider(label: String, value: Float, range: ClosedFloatingPointRange<Float>, decimals: Int = 2, onChange: (Float) -> Unit) {
    Column {
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(label, fontSize = 13.sp, modifier = Modifier.weight(1f))
            Text(String.format(Locale.US, "%.${decimals}f", value), fontSize = 13.sp, color = AccentColor)
        }
        Slider(value = value.coerceIn(range.start, range.endInclusive), onValueChange = onChange, valueRange = range)
    }
}

@Composable
fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(label, fontSize = 14.sp, modifier = Modifier.weight(1f).padding(end = 12.dp))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

private val SWATCHES = listOf("#ffffff", "#000000", "#f5c518", "#e10600", "#c8102e", "#0a1630", "#0e3290", "#01411c", "#25f4ee", "#1877f2")

/** Colour as #RRGGBB text with a preview and quick swatches. */
@Composable
fun ColorField(label: String, value: String, onChange: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Caption(label)
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(Modifier.size(40.dp).background(Color(Ctx.safeColor(value, 0xFF888888.toInt())), RoundedCornerShape(8.dp)))
            OutlinedTextField(
                value = value,
                onValueChange = { onChange(it.trim()) },
                singleLine = true,
                modifier = Modifier.width(150.dp),
            )
        }
        Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SWATCHES.forEach { hex ->
                Box(
                    Modifier.size(32.dp)
                        .background(Color(Ctx.safeColor(hex, 0xFF888888.toInt())), CircleShape)
                        .clickable { onChange(hex) },
                )
            }
        }
    }
}

/** Small picture preview of a data:image string. */
@Composable
fun Thumb(cache: ImageCache, src: String) {
    val bitmap = remember(src) { cache.get(src) }
    if (bitmap != null) {
        Image(
            bitmap = bitmap.asImageBitmap(),
            contentDescription = null,
            modifier = Modifier.size(56.dp).clip(RoundedCornerShape(8.dp)),
            contentScale = ContentScale.Crop,
        )
    } else {
        Box(Modifier.size(56.dp).clip(RoundedCornerShape(8.dp)).background(Color.DarkGray))
    }
}

/** The cards as a strip of small tiles, like the clips of a video editor. Tap a tile to select that card. */
@Composable
fun CardStrip(project: Project, onProject: (Project) -> Unit) {
    val index = project.sel.coerceIn(0, maxOf(0, project.cards.lastIndex))
    Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        project.cards.forEachIndexed { i, c ->
            val on = i == index
            Column(
                modifier = Modifier
                    .width(96.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(if (on) Color(0xFF34343B) else FieldColor)
                    .then(if (on) Modifier.border(1.5.dp, AccentColor, RoundedCornerShape(10.dp)) else Modifier)
                    .clickable { onProject(project.copy(sel = i)) }
                    .padding(horizontal = 10.dp, vertical = 6.dp),
            ) {
                Text("${i + 1}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (on) AccentColor else MutedColor)
                Text(c.head.ifBlank { "(empty)" }, fontSize = 11.sp, maxLines = 1)
            }
        }
    }
}

/** Card tiles on top, then the settings of the selected card. Settings change that card. */
@Composable
fun CardSettings(project: Project, onProject: (Project) -> Unit, content: @Composable ColumnScope.(NewsCard, (NewsCard) -> Unit) -> Unit) {
    ScreenColumn {
        if (project.cards.isEmpty()) {
            Text("No cards yet. Add one in the Cards tab.")
            return@ScreenColumn
        }
        val index = project.sel.coerceIn(0, project.cards.lastIndex)
        Caption("Editing card ${index + 1} of ${project.cards.size}")
        CardStrip(project, onProject)
        content(project.cards[index]) { onProject(project.replaceCard(index, it)) }
    }
}

/** A time in seconds, changed with -1, +1, -0.1 and +0.1 buttons. Small enough for half the width. */
@Composable
fun Stepper(value: Double, onChange: (Double) -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
        Text(String.format(Locale.US, "%.1f s", value), fontSize = 22.sp, color = AccentColor, fontWeight = FontWeight.SemiBold)
        listOf(listOf(-1.0, 1.0), listOf(-0.1, 0.1)).forEach { pair ->
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                pair.forEach { d ->
                    OutlinedButton(
                        onClick = { onChange(Math.round((value + d) * 10) / 10.0) },
                        contentPadding = PaddingValues(horizontal = 4.dp),
                        modifier = Modifier.weight(1f),
                    ) { Text(if (d > 0) "+$d" else "$d", fontSize = 13.sp, maxLines = 1) }
                }
            }
        }
    }
}

/** One tool of a tab: a label and the name of its icon. */
class ToolDef(val label: String, val icon: String)

/** A row of icon tools, in the style of the bottom bar. Tap a tool to show its settings below. */
@Composable
fun ToolBar(tools: List<ToolDef>, selected: Int, onSelect: (Int) -> Unit) {
    Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        tools.forEachIndexed { i, tool ->
            val on = i == selected
            Column(
                modifier = Modifier
                    .width(74.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (on) Color(0xFF2A2A31) else Color.Transparent)
                    .clickable { onSelect(i) }
                    .padding(vertical = 6.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(2.dp),
            ) {
                Icon(NavIcons.named(tool.icon), contentDescription = tool.label, tint = if (on) AccentColor else MutedColor, modifier = Modifier.size(24.dp))
                Text(tool.label, fontSize = 11.sp, color = if (on) Color.White else MutedColor, maxLines = 1)
            }
        }
    }
}

/**
 * The layout of a tab: an optional header (such as the card strip) and the tool bar stay in place;
 * the settings of the chosen tool scroll below them. Put Groups in the content. initial is the tool shown first.
 */
@Composable
fun ToolScreen(
    key: String,
    tools: List<ToolDef>,
    initial: Int = 0,
    header: @Composable ColumnScope.() -> Unit = {},
    content: @Composable ColumnScope.(Int) -> Unit,
) {
    var selected by rememberSaveable(key) { mutableStateOf(initial) }
    val tool = selected.coerceIn(0, tools.lastIndex)
    Column(modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        header()
        ToolBar(tools, tool) { selected = it }
        Column(
            modifier = Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(bottom = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            content(tool)
        }
    }
}

/**
 * A box that holds one group of settings, with a small title and a Close button.
 * Closed, the box shrinks to its title; tapping it opens the settings in a pop-up.
 * A box without a title is always open. key keeps the open or closed state when the title changes.
 */
@Composable
fun Group(title: String = "", modifier: Modifier = Modifier.fillMaxWidth(), key: String = title, content: @Composable ColumnScope.() -> Unit) {
    var closed by rememberSaveable("group-$key") { mutableStateOf(false) }
    var popup by remember { mutableStateOf(false) }
    val shut = title.isNotEmpty() && closed
    Surface(color = BoxColor, shape = RoundedCornerShape(14.dp), modifier = modifier) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (title.isNotEmpty()) {
                Row(
                    modifier = Modifier.fillMaxWidth().clickable { if (shut) popup = true else closed = true },
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(title, fontSize = 12.sp, color = MutedColor, fontWeight = FontWeight.SemiBold, maxLines = 1, modifier = Modifier.weight(1f))
                    Text(if (shut) "Open \u25B8" else "Close \u25B4", fontSize = 11.sp, color = AccentColor)
                }
            }
            if (!shut) content()
        }
    }
    if (shut && popup) {
        Dialog(onDismissRequest = { popup = false }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
            Surface(color = BoxColor, shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth(0.94f)) {
                Column(
                    modifier = Modifier.heightIn(max = 560.dp).verticalScroll(rememberScrollState()).padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(title, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                        TextButton(onClick = { popup = false }) { Text("Done") }
                    }
                    content()
                }
            }
        }
    }
}

/** A tool screen for settings of the selected card. The card strip is the header. */
@Composable
fun CardToolScreen(
    project: Project,
    onProject: (Project) -> Unit,
    key: String,
    tools: List<ToolDef>,
    content: @Composable ColumnScope.(NewsCard, (NewsCard) -> Unit, Int) -> Unit,
) {
    ToolScreen(
        key = key,
        tools = tools,
        header = {
            if (project.cards.isEmpty()) {
                Text("No cards yet. Add one in the Cards tab.")
            } else {
                val index = project.sel.coerceIn(0, project.cards.lastIndex)
                Group("Card ${index + 1} of ${project.cards.size}", key = "strip") { CardStrip(project, onProject) }
            }
        },
    ) { tool ->
        if (project.cards.isNotEmpty()) {
            val index = project.sel.coerceIn(0, project.cards.lastIndex)
            content(project.cards[index], { onProject(project.replaceCard(index, it)) }, tool)
        }
    }
}
