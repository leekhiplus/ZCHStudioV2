# ZCH NewsCard Studio: project handoff

## Project
- Owner: ظفر (Urdu/English app for making Urdu news videos with cards, voiceover and effects)
- Repo: GitHub, branch main. Repo name seen in screenshot: leekhiplus/<repo>
- Language rules: app UI text in English; chat replies in Urdu; code complete and self-contained.

## Old app (WebView, still working)
- Source: single HTML file, about 480 lines plus helpers (Canvas renderer, 22 templates, transitions, overlays, ticker, logo, voiceover, Gemini TTS and text-to-cards).
- Android host: MainActivity.kt (WebView + JS bridge `ZCH`), VideoExporter.kt (MediaCodec H.264, NV12 from JPEG frames), AudioMux.kt (voiceover WAV/MP3/M4A to AAC, muxed with video), Saver (MediaStore Downloads), ExportService.kt (foreground service, wake lock, progress notification).
- Assets: android/app/src/main/assets/index.html (must match /index.html).
- Zip for GitHub: ZCHNewsCardStudio.zip (root = project). Workflow `android-build.yml` unzips ZCHNewsCard*.zip, SDK 34, Gradle 8.9.
- Launcher icon: ZCH text, STUDIO, round red play badge with yellow ring (icon/ZCH_icon_1024.png).
- Gemini text models: 2.5 Pro/Flash/Flash-Lite and previews; TTS: 2.5 Flash/Pro preview plus 3.8 options.

## New app (Compose, started)
- Zip: ZCHStudioV2.zip; workflow file: android-v2-workflow/android-build-v2.yml (put in .github/workflows/ with a different name from the old one).
- Stack: AGP 9.5.0, Kotlin 2.4.20 with Compose compiler plugin, Compose BOM 2026.09.00, compileSdk 37, targetSdk 37, minSdk 26, Gradle 9.8.2 (workflow).
- Versions verified Nov 2026: AGP 9.5.0 (needs Gradle 9.6+), Gradle 9.8.2, Kotlin 2.4.20, core 1.19.1, lifecycle 2.11.0, activity 1.13.0, Compose BOM 2026.09.00. Still to confirm on first build: build-tools 37.0.0.
- Current state: skeleton only. MainActivity shows 9 scrollable tabs (Cards, Edit, Timing, Video, Brand, Export, Text, Effects, Voice) with placeholders.

## Migration plan (phases)
0. Stack and build (done, pending first build success)
1. Data model: Project and Card (same fields as the HTML `P` and `nc()`), DataStore, kotlinx.serialization, import of old JSON.
2. Renderer: port 22 templates, transitions, text wrap with Urdu shaping (Noto Nastaliq Urdu, Poppins etc. bundled in res/font), overlays, ticker, logo.
3. Timeline and playback: scrub, card selection, voiceover sync.
4. Export: render directly to MediaCodec input Surface (no JPEG bridge), reuse AudioMux, keep foreground service.
5. Gemini: news to cards, scripts, TTS; API key in secure storage.
6. Remove WebView, assets/index.html, JS bridge; final QA.

## Open decisions
- minSdk 26 chosen by default (user did not answer).
- Old saved cards: add JSON export button to the old app before migrating (user did not answer).
- Whether Phase 1 starts immediately.

## Next step
Build ZCHStudioV2 in GitHub Actions. Send the build log if it fails. Then start Phase 1 (data model and DataStore).

## Phase 1 status (Nov 2026)
- Done in ZCHStudioV2 (package com.zch.studio):
  - model: NewsCard (same field names as WebView JSON), Project, template names (22)
  - data: ProjectStore (JSON in filesDir/project.json, importOld for WebView exports)
  - ui: CardsScreen (add, delete, select, edit text/time/template, import)
  - kotlinx-serialization-json 1.11.0 with Kotlin serialization plugin
- Done in old WebView app: "Export project (JSON)" button in the Export tab (zch-project.json).
- Next: Phase 2 (renderer). Before that, confirm the Phase 1 build passes.

## Phase 2a status (Nov 2026)
- Renderer (package com.zch.studio.render): Fonts, ImageCache, Ctx, CardRenderer. Templates 0 to 7 ported.
- Templates 8 to 21 fall back to template 0 until phase 2b.
- Preview in the Cards editor (ui/CardPreview.kt) uses the same renderer.
- Urdu font: put NotoNastaliqUrdu.ttf in app/src/main/assets/fonts/ (download from Google Fonts). Without it, the system Arabic font is used.
- Not yet: transitions, text and picture animations, ticker, logo, lower third, multi-image slideshow, blurred background for "fit".

## Phase 2b status (Nov 2026)
- Templates 8 to 21 ported into render/CardRenderer.kt (t8 to t21). Ctx.kt gained: para (parallelogram), disc, measure, italic text, left-aligned text, outline, drawBitmap.
- Ctx.image() now follows IMG() in the WebView app: slideshow over card.imgs, picture transitions (card.it), fit mode with blurred background, zoom and pan animations (card.ia).
- CardRenderer.draw(..., tickH, animate, adDur): tickH reserves bottom space for the ticker; animate turns on the text entrance animation.

## Phase 2c status (Nov 2026)
- render/FrameRenderer.kt: frame() port. Card selection by time, transitions (cut, cross, fade, flash, push, slide, slidel, slideu, zoom, wipe), logo, ticker.
- FrameRenderer.draw(canvas, project, t, w, h, fonts, images) for playback and export. FrameRenderer.drawCard(...) for the editor preview (no transition).
- Project gained: ad, tdir, logo (data:image base64).
- Editor preview (FramePreview in ui/CardPreview.kt) now shows logo and ticker.
- Not yet: lower third overlay (ot, ot1, ot2, ol, lt, olx, olc) and the shine effect SHB(). Their JS was not in webview_render_8_21.js. Send those functions to finish the renderer.
- Assumption: logo then ticker are drawn after the card, as frame() in the old app seemed to do (that part of the JS was cut off).
- Not compiled by Claude (no Kotlin compiler in its sandbox). First GitHub Actions build is the real test.
- Next: Phase 3 (timeline and playback).

## Phase 3a status (Nov 2026)
- Timing tab = TimelineScreen (ui/TimelineScreen.kt): live preview of the whole video through FrameRenderer, Play/Pause/Stop, scrub slider, time readout, card strip (tap to jump and select card).
- Project.totalDuration(audioSeconds) = tot() from the old app. Voiceover length is passed in once audio exists.
- Playback uses Compose's frame clock (withFrameNanos). No audio yet, so voiceover sync waits for the Voice phase (Phase 5 for Gemini TTS; picking an audio file can come earlier).
- Not done: dragging card edges on the strip to change start and end, per-card timing editing on the Timing tab (use the Cards tab fields for now).
- Not compiled by Claude. First GitHub Actions build is the test.

## Phase 4a status (Nov 2026)
- Export tab (ui/ExportScreen.kt): shape (16:9, 9:16, 1:1), size (480p, 720p, 1080p), fps (24, 30), Export MP4, progress, Cancel.
- export/VideoExporter.kt: FrameRenderer draws every frame onto a MediaCodec H.264 input Surface (lockHardwareCanvas, falls back to lockCanvas), MediaMuxer writes the MP4. Frame timestamps are set from the frame number because drawing on a Surface only gives system-clock times.
- export/ExportController.kt: background thread, progress state, saves to Movies/ZCH (Android 10+) or the app's Movies folder (older). Needs no storage permission.
- Project.outputSize() = size() from the old app, both sides made even.
- Ctx.blurFill no longer recycles its small bitmap (hardware canvases draw later).
- Video only. Not done: audio track (needs audio source; AudioMux from the old app is not in this project), foreground service so export survives leaving the app, lower third and SHB shine.
- Not compiled or run by Claude. Test on a real phone: export a 5 s project at 720p first.

## Phase 4b status (Nov 2026): voiceover from a file
- Voice tab (ui/VoiceScreen.kt): choose an audio file (any format Android can decode), replace, remove. "Video ends with": Audio length (endm "voice") or Last card (endm "card").
- audio/AudioImport.kt copies the file to filesDir/voiceover and reads name and length. Project gained audioName and audioSec. Project.totalDuration() now uses audioSec (tot() in the old app).
- Timing tab plays the voiceover with MediaPlayer. While audio is sounding, its clock drives the picture time (sync). Scrubbing pauses.
- Export: video-only MP4, then export/AudioTranscoder.kt (decode, AAC 128 kbps, cut at video length) to an .m4a, then export/Mp4Mux.kt joins both without re-encoding. If the audio step fails, the video is saved without audio and the status line says why.
- Not done: foreground service for export, lower third overlay, SHB shine, Gemini TTS and script-to-cards (Phase 5), removing the WebView and old assets (Phase 6, nothing to remove in this project yet), per-card audio timing (voice sync points, vw and wt fields from the old app).
- Not compiled or run by Claude. Test: a 10 s project with a short mp3, play on Timing, then export at 720p.

## Phase 4c and 5 status (Nov 2026)
Export service (4c):
- export/ExportService.kt (foreground service, type dataSync), export/ExportNotification.kt (progress notification with Cancel, result notification), wake lock during export, ExportController is now a process singleton (ExportController.get). Export tab asks for the notification permission on Android 13+ before the first export; export starts either way.
- Manifest: FOREGROUND_SERVICE, FOREGROUND_SERVICE_DATA_SYNC, POST_NOTIFICATIONS, WAKE_LOCK. versionCode 4, versionName 2.0.2.

Gemini (5):
- Text tab (ui/TextScreen.kt): API key (gemini/SecureKey.kt, AES-GCM with an Android Keystore key, never in project.json), text model (Project.tm), paste news text, 3/5/8 cards, Replace all or Add at end. gemini/GeminiClient.newsToCards asks for JSON (head, desc, script) with a response schema. New cards copy the look of the selected card.
- Voice tab (ui/VoiceScreen.kt): speech model (Project.gm), voice (gv), style (gs), per-card script fields, "Make voiceover from scripts". gemini/VoiceBuilder speaks each scripted card with GeminiClient.speak, joins the PCM into a WAV at filesDir/voiceover, and sets every card's s/e from its speech length plus a 0.35 s pause (minimum 1.5 s). Cards without a script keep their length as silence. This replaces the old app's per-word timing (vw, wt) with card-level timing.
- export/AudioTranscoder now accepts WAV (audio/raw) directly, without a decoder.
- Defaults come from the old app: tm gemini-3.8-flash, gm gemini-3.8-flash-tts, gv Kore, gs "professional news anchor, clear and steady". Model names are editable text because they change often.
- Not verified against the live API: the request shapes follow the public generateContent format (responseSchema for cards; responseModalities AUDIO and prebuiltVoiceConfig for speech, PCM 24 kHz in inlineData). If a model rejects them, the error text from Gemini is shown in the app.

Still open: lower third overlay (ot, ot1, ot2, ol, lt, olx, olc), SHB shine effect (ls, lsi, lsp), Edit/Video/Brand/Effects tabs (field editors for logo, ticker, transition, sound effects sfx), per-word timing, Phase 6 cleanup. Not compiled or run by Claude.

## Phase 6 status (Nov 2026): all nine tabs, rest of the renderer, Gemini formats fixed
Source: the full old app (ZCHNewsCardStudio zip, assets/index.html) was available this time.
Renderer (render/):
- Shine: Ctx.shine() and shb() = shine() and SHB() of the old app, called in templates 0, 1, 2, 6, 7, 8, 9 (header and panel), 10 and on the ticker. Project.ls (bars, all, off), lsi, lsp. "all" also sweeps the whole card.
- Lower third: FrameRenderer.drawOverlay = FXO() (tag ot, ot1, ot2; text bar ol, lt, olx, olc; shine sh).
- Captions: FrameRenderer.drawCaptions = CAP() (card.cap, vd, vw, wt). While captions show, the card description is hidden (as in CARD()).
- Frame order: card (with transition), shine all, lower third, captions, logo, ticker.
Gemini (gemini/):
- Requests now match the old app: speech uses part.speech_metadata.style and speechConfig.voiceConfig.voice; the audio answer may be WAV or raw PCM; news to cards uses the Urdu editor prompt and {cards:[{headline,summary,script}]}.
- VoiceBuilder trims silence, sets each card's s/e, vd, and estimated word times (vw, wt) for captions. Old app aligned words from the audio of one long voiceover; this version times words by length inside each card's own speech.
- New cards get length max(3, words / 2.6).
Tabs (ui/), following the old app: Cards (CardsTab: Cards or News to cards), Edit (pictures, second picture, fit, zoom, position, frame size; pictures are resized to 1280 px JPEG data URIs, logo 512 px PNG), Timing, Video (shape, size, fps, end mode, ticker), Brand (channel, logo, position, size, opacity), Export, Text (size, colours), Effects (animations, picture change style, lower third, captions, transitions, shine), Voice (API key, file, Gemini voice, scripts).
Not done: card start sounds (sfx: whoosh, swish, pop, impact, ding, sting, riser; the old app made them with WebAudio), per-card font choice (fu, fe; fonts are fixed), live preview inside the editor tabs (use Timing), Phase 7 cleanup.
Build history: phase5 zip failed once with a JVM clash (status setter); fixed. This phase has not been compiled by Claude.

## Phase 7 status (Nov 2026): persistent preview, multi-track timeline, sounds, new icon
- ui/PreviewPanel.kt sits above the tab row in AppShell, so the preview never disappears when the tab changes. PlayerState (time, playing) is shared. Play, Pause, Stop, time readout, Hide/Show. The picture and timeline hide while the keyboard is open. Choosing another card in any tab shows that card (settledTime). Playback follows the voiceover clock when audio is sounding.
- ui/MultiTrackTimeline.kt: tracks Cards, Pictures, Voice, Sound, Overlay, Captions, Ticker, Logo along a ruler. Zoom Fit/2x/4x/8x, horizontal scroll (follows the playhead while playing), tap to jump (and select a card on the Cards track), drag the ruler to scrub, long-press a card bar and drag: edges change start or end, middle moves the card (0.1 s snap, saved when released).
- ui/TimingScreen.kt (Timing tab): start and end steppers, Play from this card, Back to back (close gaps), same length for all cards. Old ui/TimelineScreen.kt and the preview inside the card editor were removed.
- Card start sounds: audio/SfxSynth.kt (port of mkSfx: whoosh, swish, pop, impact, ding, sting, riser with LEAD and DUR), audio/SfxPlayer.kt (AudioTrack, plays in the preview), export/AudioMix.kt (decodes the voiceover, adds the sounds at card start minus lead, writes a WAV; ExportController then encodes it to AAC and joins it with the video). Project.sfx (default) and sfv (volume); card.sfx "def", "none" or a name. Effects tab has the controls. A video with sounds but no voiceover now gets an audio track too.
- App icon: new ZCH News Studio logo (circle cropped from the PNG with transparent corners) in all mipmap sizes, adaptive foreground at 66 percent of the canvas on background #001A3E. versionName 2.1.0.
- Not done: per-card font choice, word-level alignment from the audio, an undo history, timeline drag for the Pictures/Voice tracks, tests. Not compiled or run by Claude.

## Phase 8 status (Nov 2026): web app parity, bug fixes
Source: the newest WebView app (index__16 html and zip). Its flow: one voiceover for all cards, words aligned in the audio, auto-split of long scripts, news to cards with or without AI, undo/redo, bottom navigation.
Bugs fixed:
- Play and Pause were invisible: FrameRenderer filled the whole window with black because the canvas had no clip. It now clips to its own frame, and the preview canvas is clipped too.
- Card bars in the timeline could not be dragged: a long press was needed and scrolling stole the gesture. Now press a bar and drag at once (edges change start or end, middle moves the card); the other tracks still scroll.
Features ported:
- gemini/VoiceAlign.kt: cln() (removes the end click), aln() (finds word times in the audio), applyTimes(). gemini/VoiceBuilder.kt: generateAll() = one Gemini voiceover for all cards in groups of up to 500 words, 0.25 s between groups, word times from the audio; syncCards() = match cards to an imported voice. AudioMix.decodeMono() decodes a file for this.
- gemini/CardText.kt: splitNews, headline (hd), splitCard, withDrafts (mkCards). Project.autoSplit (JSON name "as"): when making the voiceover, a script over 45 words is split into several cards first. Cards tab: "Paste news and create cards" (collapsible) with Use Gemini, Generate one voiceover, Replace existing; without Gemini the text is split locally. Duplicate card.
- gemini/GeminiModels.kt: text models (3.8 Flash, Latest Flash, 3.5 Flash-Lite, 2.5 Pro/Flash/Flash-Lite), speech models (3.8 Flash TTS, 3.8 Flash-Lite TTS, 3.1 Flash TTS, 2.5 Pro TTS, 2.5 Flash TTS) and all 30 voices with their style words. Any other model name can be typed. The id gemini-3.1-flash-tts is a guess from the naming pattern: if Gemini rejects it, type the right id in "Other model name".
- Voice tab as in the WebView app: key, model, voice, delivery style, script of the selected card, show script on the card, Use headline + description, Split into cards, Auto-split switch, Generate ONE voiceover, import a voice, Match cards to the voice, Play this card, Delete the voiceover, status line.
- Effects: Newsroom preset, Apply to all cards. Edit: Reset picture.
- Undo and redo (model/History.kt): 60 steps, edits within 0.7 s count as one, selecting a card is not a step. Buttons next to Play.
Design as in the WebView app: black background, dark grey panel with rounded top and the section title, cyan accent, header (title, Preview toggle, resolution chip, cyan Export button), big white round play button with time at the left and undo/redo at the right, bottom bar with the same line icons (Cards, Edit, Voice, Text, Effects, Timing, Video, Brand). Export opens from the header.
Not done: per-card fonts, "Share last video", project import/export as JSON, undo of audio file changes. Not compiled or run by Claude. versionName 2.2.0.

## Phase 8b status (Nov 2026): timeline and card count fixes (v2.2.1)
- Timeline: default scale is 40 dp per second (zoom 1x), so it is wider than the screen and scrolls; Fit, 1x, 2x, 4x, 8x. Track rows are 32 dp, ruler 26 dp, text 11 sp. Arrow buttons scroll the timeline. "Tall" shows more tracks and hides the picture; "Short" brings it back. Dragging a card bar now works on the selected card only (tap to select, then drag); dragging anywhere else scrolls the timeline.
- The play row (time, round play button, undo and redo) is now below the picture, like the WebView app, not above it.
- The number of cards is no longer fixed. News to cards: "Words per card" (default 32) and the text decides the count (up to 200). Gemini is asked for about one card per that many words. Making the voiceover with Auto-split on splits every card whose script is over 45 words, not only the selected one. Split into cards has no cap of 12 any more.
- Not compiled or run by Claude.

## Phase 8c status (Nov 2026): layout fix (v2.2.2)
- Bug: the timeline header ("Timeline" label plus seven chips) overflowed with a large system font, the label wrapped letter by letter and the header grew very tall, so the tab content below was squeezed to a sliver. Fix: header is now one compact row of small buttons (Tall/Short, left and right arrows, Fit, 1x, 2x, 4x, 8x) that scrolls sideways; no label.
- The picture and timeline are limited by screen height: picture at most 24 percent (max 200 dp), tracks at most 12 percent (96 dp, 3 tracks) or 30 percent (256 dp) in Tall mode. The tab content always keeps the rest. Header title is "ZCH News Studio" (matches the new logo) and the preview toggle is "View".
- Not compiled or run by Claude.

## Phase 9 status (Nov 2026): organised layout (v2.3.0)
Request: features were tangled; arrange them in boxes like CapCut or KineMaster.
- ui/Controls.kt now holds the layout parts: Panel (titled box, tap the title to open or close, shows a hint when closed, state remembered), Choice (chips that wrap for up to 6 options, otherwise a PickerRow), PickerRow (shows the current value, opens a list dialog), CardStrip (cards as small tiles like clips, tap to select), CardSettings (strip plus settings of the selected card), Hint, LabeledSlider and Stepper with the value on the right.
- Tabs rebuilt in boxes. Cards: Cards (strip, Add, Duplicate, Delete), Card N (template picker, headline, description), Names and scores, Create cards from news. Edit: Pictures, Second picture, Picture in the frame. Voice: Gemini API key (open only if no key), Voice (model, voice picker, style), Script, Voiceover. Text: Size, Colors. Effects: Presets, Animation, Lower third, Captions, Sound at card start, Transitions, Shine. Timing: This card, All cards, Editing in the timeline. Video: Format, News ticker, Ticker colors. Brand: Channel name, Logo, Logo position and size. Export: Format, Export video.
- The Cards tab no longer uses a LazyColumn; the old card list rows and the Start/End fields there were replaced by the strip and the Timing tab.
- Not compiled or run by Claude. versionName 2.3.0.

## Phase 10 status (Nov 2026): tool bars inside the tabs, video clips, progress pop-ups (v2.4.0)
- Layout: every tab now has the same structure as the bottom bar. Header (card strip where it applies), a row of icon tools (ToolBar, ToolDef, ToolScreen, CardToolScreen in ui/Controls.kt; icons by name in NavIcons.named), and one box with the settings of the chosen tool. The old accordion Panels are no longer used by the tabs (Panel stays in Controls.kt).
  Cards: Cards, Template, Text, Scores, News. Edit: Media, Second, Frame. Voice: Voice, Script, Make, Key (starts on Key when no API key is saved). Text: Size, Colors. Effects: Presets, Animate, Lower third, Captions, Sound, Transition, Shine. Timing: Card, All cards, Help. Video: Format, Ticker, Colors. Brand: Name, Logo, Position. Export: Format, Export.
- Progress pop-up: ui/Busy.kt BusyDialog, a dialog with a turning circle (or a filling circle with percent) that cannot be dismissed by touching outside. Used for making a voiceover, creating cards from news, matching cards to a voice, importing audio, adding pictures and video clips, and the logo. Clip import also has Cancel.
- Video clips with pictures: Edit > Media > Add video clips. media/ClipStore.kt turns a clip into numbered JPEG frames (12 per second, max side 720, up to 60 seconds) in filesDir/clips/<id>, with meta.txt (frames,fps). A card refers to it as "clip:<id>" in imgs. ImageCache.frame(src, t) gives the frame for a time; Ctx.drawPicture uses it, so preview and export show clips; the clip plays from its start inside its slot and holds its last frame. A card that held nothing else is made as long as its clips (Project.setCardLength). Clip sound is not used. Frames of removed clips stay on disk (undo may need them).
- Not compiled or run by Claude. versionName 2.4.0.

## Phase 10b status (Nov 2026): settings in boxes (v2.4.1)
Request: the settings inside the tools were plain stacked fields; put them in boxes, in order.
- ui/Controls.kt: Group(title, modifier) is a rounded box with a small title; every tool's settings are built from Groups, and two small Groups sit side by side in a Row where they fit (Start and End, Zoom and Frame size, Position X and Y, Speed and Pop, Strength and Every, Size and Opacity, Team A and Team B).
- ToolScreen: the card strip and the tool bar now stay in place; only the settings below them scroll. The section title above the tabs was removed to give the settings more room.
- Stepper(value, onChange) is a compact box content: the value in large type, then -1 +1 and -0.1 +0.1 buttons.
- Card tiles are one tile of number plus one line of headline. The picture above is limited to 20 percent of the screen height (max 180 dp), the play button is 40 dp.
- Not compiled or run by Claude. versionName 2.4.1.

## Phase 10c status (Nov 2026): closable boxes (v2.4.2)
- Group boxes have a Close button. Closed, a box shrinks to its title with "Open"; tapping it opens its settings in a pop-up with Done. The state is remembered per box (key). The card strip is now a Group too ("Card N of M", key "strip") in Cards, Voice and every card tool. Not compiled or run by Claude.
