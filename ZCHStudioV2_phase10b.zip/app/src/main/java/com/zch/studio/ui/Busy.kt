package com.zch.studio.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

/**
 * A pop-up with a turning circle while something is made, like the progress pop-ups of CapCut.
 * With a progress value (0 to 1) the circle fills and shows the percent. It cannot be dismissed by touching outside.
 */
@Composable
fun BusyDialog(show: Boolean, text: String, progress: Float? = null, onCancel: (() -> Unit)? = null) {
    if (!show) return
    Dialog(
        onDismissRequest = {},
        properties = DialogProperties(dismissOnBackPress = false, dismissOnClickOutside = false),
    ) {
        Surface(shape = RoundedCornerShape(22.dp), color = Color(0xFF1C1C21)) {
            Column(
                modifier = Modifier.padding(horizontal = 32.dp, vertical = 28.dp).widthIn(min = 220.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(18.dp),
            ) {
                Box(contentAlignment = Alignment.Center) {
                    if (progress != null) {
                        CircularProgressIndicator(progress = { progress }, modifier = Modifier.size(68.dp), strokeWidth = 5.dp, color = AccentColor)
                        Text("${(progress * 100).toInt()}%", fontSize = 14.sp)
                    } else {
                        CircularProgressIndicator(modifier = Modifier.size(68.dp), strokeWidth = 5.dp, color = AccentColor)
                    }
                }
                Text(text, textAlign = TextAlign.Center, fontSize = 14.sp)
                if (onCancel != null) TextButton(onClick = onCancel) { Text("Cancel") }
            }
        }
    }
}
