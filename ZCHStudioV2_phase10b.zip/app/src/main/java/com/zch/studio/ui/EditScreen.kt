package com.zch.studio.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.zch.studio.media.ClipStore
import com.zch.studio.media.ImageImport
import com.zch.studio.model.NewsCard
import com.zch.studio.model.Project
import com.zch.studio.model.replaceCard
import com.zch.studio.model.setCardLength
import com.zch.studio.render.ImageCache
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean

/** The pictures and video clips of a card. Old projects may hold a single picture in src only. */
private fun media(c: NewsCard): List<String> = c.imgs.ifEmpty { if (c.src.isNotEmpty()) listOf(c.src) else emptyList() }

private val TOOLS = listOf(ToolDef("Media", "photo"), ToolDef("Second", "copy"), ToolDef("Frame", "frame"))

/** Edit tab: pictures and video clips of the card, a second picture, and how the picture sits in the frame. */
@Composable
fun EditScreen(project: Project, onProject: (Project) -> Unit) {
    val context = LocalContext.current
    val latest by rememberUpdatedState(project)
    val save by rememberUpdatedState(onProject)
    val cache = remember { ImageCache() }
    val cancel = remember { AtomicBoolean(false) }
    var busy by remember { mutableStateOf(false) }
    var progress by remember { mutableStateOf<Float?>(null) }
    var message by remember { mutableStateOf("") }

    fun changeSelected(change: (NewsCard) -> NewsCard) {
        val p = latest
        if (p.cards.isEmpty()) return
        val i = p.sel.coerceIn(0, p.cards.lastIndex)
        save(p.replaceCard(i, change(p.cards[i])))
    }

    val addPictures = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        if (uris.isEmpty()) return@rememberLauncherForActivityResult
        busy = true
        progress = null
        message = "Adding pictures..."
        val app = context.applicationContext
        background({ uris.map { ImageImport.toDataUri(app, it, 1280) } }) { result ->
            busy = false
            result.onSuccess { added ->
                message = ""
                changeSelected { c ->
                    val all = media(c) + added
                    c.copy(imgs = all, src = all.first())
                }
            }.onFailure { message = it.message ?: "Could not add the pictures" }
        }
    }

    val addClips = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        if (uris.isEmpty()) return@rememberLauncherForActivityResult
        busy = true
        cancel.set(false)
        progress = 0f
        message = "Preparing video clip 1 of ${uris.size}"
        val app = context.applicationContext
        background({
            val added = ArrayList<String>()
            uris.forEachIndexed { n, uri ->
                onMain { message = "Preparing video clip ${n + 1} of ${uris.size}" }
                added.add(ClipStore.importClip(app, uri, { p -> onMain { progress = (n + p) / uris.size } }, { cancel.get() }))
            }
            added.toList()
        }) { result ->
            busy = false
            progress = null
            result.onSuccess { added ->
                message = ""
                val p = latest
                if (p.cards.isNotEmpty()) {
                    val i = p.sel.coerceIn(0, p.cards.lastIndex)
                    val c = p.cards[i]
                    val before = media(c)
                    val all = before + added
                    var next = p.replaceCard(i, c.copy(imgs = all, src = all.first()))
                    // A card that held nothing else is made as long as its clips.
                    val seconds = added.sumOf { ClipStore.duration(it) }
                    if (before.isEmpty() && seconds > c.e - c.s) next = next.setCardLength(i, seconds)
                    save(next)
                }
            }.onFailure { message = if (it.message == "Cancelled") "Cancelled." else (it.message ?: "Could not add the video") }
        }
    }

    val pickSecond = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        busy = true
        progress = null
        message = "Adding picture..."
        val app = context.applicationContext
        background({ ImageImport.toDataUri(app, uri, 1280) }) { result ->
            busy = false
            result.onSuccess { data -> message = ""; changeSelected { it.copy(src2 = data) } }
                .onFailure { message = it.message ?: "Could not add the picture" }
        }
    }

    BusyDialog(busy, message, progress, onCancel = if (progress != null) ({ cancel.set(true) }) else null)

    CardToolScreen(project, onProject, "edit", TOOLS) { card, update, tool ->
        when (tool) {
            0 -> {
                Group("Pictures and video clips") {
                    val list = media(card)
                    if (list.isEmpty()) Hint("Nothing on this card yet.")
                    list.forEachIndexed { i, src ->
                        val clip = ClipStore.isClip(src)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                        ) {
                            Thumb(cache, src)
                            Column(modifier = Modifier.weight(1f)) {
                                Text(if (clip) "Video clip ${i + 1}" else "Picture ${i + 1}")
                                if (clip) Hint(String.format(Locale.US, "%.1f", ClipStore.duration(src)) + " s")
                            }
                            OutlinedButton(onClick = {
                                changeSelected { c ->
                                    val left = media(c).filterIndexed { n, _ -> n != i }
                                    c.copy(imgs = left, src = left.firstOrNull() ?: "")
                                }
                            }) { Text("Remove") }
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { addPictures.launch("image/*") }, enabled = !busy, modifier = Modifier.weight(1f)) { Text("Add pictures") }
                        Button(onClick = { addClips.launch("video/*") }, enabled = !busy, modifier = Modifier.weight(1f)) { Text("Add videos") }
                    }
                    if (message.isNotEmpty() && !busy) Hint(message)
                }
                Group("About clips") {
                    Hint(
                        "With several items the card shows them one after another. A video clip plays from its start " +
                            "(its sound is not used, and up to 60 seconds are taken). Choose how items change in the Effects tab.",
                    )
                }
            }
            1 -> Group("Second picture") {
                Hint("A second picture is used by the versus and player templates.")
                if (card.src2.isNotEmpty()) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Thumb(cache, card.src2)
                        OutlinedButton(onClick = { update(card.copy(src2 = "")) }) { Text("Remove") }
                    }
                }
                Button(onClick = { pickSecond.launch("image/*") }, enabled = !busy) {
                    Text(if (card.src2.isEmpty()) "Choose picture" else "Replace picture")
                }
            }
            else -> {
                Group("Fit") {
                    Choice("How the picture fits", listOf("fill" to "Fill the frame", "fit" to "Fit whole picture"), card.fit) {
                        update(card.copy(fit = it))
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Group("Zoom", Modifier.weight(1f)) {
                        LabeledSlider("Zoom", card.iz.toFloat(), 0.5f..3f) { update(card.copy(iz = it.toDouble())) }
                    }
                    Group("Frame size", Modifier.weight(1f)) {
                        LabeledSlider("Size", card.fs.toFloat(), 0.6f..1.3f) { update(card.copy(fs = it.toDouble())) }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Group("Position X", Modifier.weight(1f)) {
                        LabeledSlider("X (%)", card.fx.toFloat(), 0f..100f, 0) { update(card.copy(fx = it.toDouble())) }
                    }
                    Group("Position Y", Modifier.weight(1f)) {
                        LabeledSlider("Y (%)", card.fy.toFloat(), 0f..100f, 0) { update(card.copy(fy = it.toDouble())) }
                    }
                }
                OutlinedButton(
                    onClick = { update(card.copy(fit = "fill", iz = 1.0, fx = 50.0, fy = 35.0, fs = 1.0)) },
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("Reset picture") }
            }
        }
    }
}
