package com.zch.studio.media

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.util.LruCache
import java.io.File
import java.io.FileOutputStream
import java.util.UUID
import kotlin.math.max
import kotlin.math.min

/**
 * Video clips for cards. A clip is turned into a numbered row of small pictures (12 per second) on disk,
 * so the preview and the export can show any moment of it quickly. A card refers to it as "clip:<id>".
 * The sound of a clip is not used.
 */
object ClipStore {

    const val FPS = 12
    private const val MAX_SECONDS = 60
    private const val MAX_SIDE = 720

    private var dir: File = File("clips")
    private val metaCache = HashMap<String, Meta>()
    private val bitmaps = object : LruCache<String, Bitmap>(24 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount / 1024
    }

    class Meta(val frames: Int, val fps: Int) {
        val duration: Double get() = frames.toDouble() / fps
    }

    fun init(folder: File) {
        dir = folder
        folder.mkdirs()
    }

    fun isClip(src: String) = src.startsWith("clip:")
    fun idOf(src: String) = src.removePrefix("clip:")

    @Synchronized
    private fun meta(id: String): Meta? {
        metaCache[id]?.let { return it }
        val file = File(File(dir, id), "meta.txt")
        if (!file.exists()) return null
        val parts = file.readText().trim().split(",")
        val m = Meta(parts[0].toInt(), parts[1].toInt())
        metaCache[id] = m
        return m
    }

    /** Length of the clip in seconds, 0 if it is not found. */
    fun duration(src: String): Double = meta(idOf(src))?.duration ?: 0.0

    /** The picture t seconds into the clip. After the end the last picture stays. */
    fun frame(id: String, t: Float): Bitmap? {
        val m = meta(id) ?: return null
        val index = (t * m.fps).toInt().coerceIn(0, m.frames - 1)
        val key = "$id#$index"
        bitmaps.get(key)?.let { return it }
        val bmp = BitmapFactory.decodeFile(File(File(dir, id), "%05d.jpg".format(index)).absolutePath) ?: return null
        bitmaps.put(key, bmp)
        return bmp
    }

    /** Blocks. Call from a background thread. Returns the new "clip:<id>". Clips are cut at 60 seconds. */
    fun importClip(context: Context, uri: Uri, onProgress: (Float) -> Unit, isCancelled: () -> Boolean): String {
        val id = UUID.randomUUID().toString().replace("-", "").take(10)
        val folder = File(dir, id)
        folder.mkdirs()
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(context, uri)
            val durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            if (durationMs <= 0L) throw IllegalArgumentException("Could not read this video")
            var w = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
            var h = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
            val rotation = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            if (rotation == 90 || rotation == 270) { val x = w; w = h; h = x }
            if (w <= 0 || h <= 0) { w = 1280; h = 720 }
            val scale = min(1f, MAX_SIDE / max(w, h).toFloat())
            val tw = max(2, (w * scale).toInt())
            val th = max(2, (h * scale).toInt())
            val seconds = min(durationMs / 1000.0, MAX_SECONDS.toDouble())
            val total = max(1, (seconds * FPS).toInt())

            var last: Bitmap? = null
            for (i in 0 until total) {
                if (isCancelled()) throw IllegalStateException("Cancelled")
                val timeUs = i * 1_000_000L / FPS
                var bmp: Bitmap? = if (Build.VERSION.SDK_INT >= 27) {
                    retriever.getScaledFrameAtTime(timeUs, MediaMetadataRetriever.OPTION_CLOSEST, tw, th)
                } else {
                    retriever.getFrameAtTime(timeUs, MediaMetadataRetriever.OPTION_CLOSEST)?.let { Bitmap.createScaledBitmap(it, tw, th, true) }
                }
                if (bmp == null) bmp = last
                if (bmp == null) throw IllegalArgumentException("Could not read pictures from this video")
                FileOutputStream(File(folder, "%05d.jpg".format(i))).use { bmp.compress(Bitmap.CompressFormat.JPEG, 82, it) }
                last = bmp
                onProgress((i + 1f) / total)
            }
            File(folder, "meta.txt").writeText("$total,$FPS")
            return "clip:$id"
        } catch (e: Throwable) {
            folder.deleteRecursively()
            throw e
        } finally {
            runCatching { retriever.release() }
        }
    }
}
