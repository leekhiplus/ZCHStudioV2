package com.zch.studio

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zch.studio.data.ProjectStore
import com.zch.studio.export.ExportController
import com.zch.studio.media.ClipStore
import com.zch.studio.model.History
import com.zch.studio.model.Project
import com.zch.studio.ui.AccentColor
import com.zch.studio.ui.BrandScreen
import com.zch.studio.ui.CardsScreen
import com.zch.studio.ui.EditScreen
import com.zch.studio.ui.EffectsScreen
import com.zch.studio.ui.ExportScreen
import com.zch.studio.ui.FieldColor
import com.zch.studio.ui.MutedColor
import com.zch.studio.ui.NavIcons
import com.zch.studio.ui.PanelColor
import com.zch.studio.ui.PlayerState
import com.zch.studio.ui.PreviewPanel
import com.zch.studio.ui.TextStyleScreen
import com.zch.studio.ui.TimingScreen
import com.zch.studio.ui.VideoScreen
import com.zch.studio.ui.VoiceScreen
import com.zch.studio.ui.ZchTheme
import java.io.File

/** Section titles by number, the same nine sections and numbers as the WebView app. */
private val SECTIONS = listOf("Cards", "Edit", "Timing", "Video", "Brand", "Export", "Text", "Effects", "Voice")

/** Bottom bar: label and section number, in the order of the WebView app. */
private val NAV = listOf("Cards" to 0, "Edit" to 1, "Voice" to 8, "Text" to 6, "Effects" to 7, "Timing" to 2, "Video" to 3, "Brand" to 4)

class MainActivity : ComponentActivity() {

    private val store by lazy { ProjectStore(File(filesDir, "project.json")) }
    private var project by mutableStateOf(Project())
    private val exporter by lazy { ExportController.get(applicationContext) }
    private val history = History()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ClipStore.init(File(filesDir, "clips"))
        project = store.load()
        setContent {
            ZchTheme {
                AppShell(
                    project = project,
                    onProject = { update(it) },
                    exporter = exporter,
                    history = history,
                    onUndo = { undo() },
                    onRedo = { redo() },
                )
            }
        }
    }

    /** Every change is saved at once. Changing only the selected card is not an undo step. */
    private fun update(p: Project) {
        if (p.copy(sel = project.sel) != project) history.record(project)
        project = p
        store.save(p)
    }

    private fun undo() {
        history.undo(project)?.let { project = it; store.save(it) }
    }

    private fun redo() {
        history.redo(project)?.let { project = it; store.save(it) }
    }
}

@Composable
fun AppShell(
    project: Project,
    onProject: (Project) -> Unit,
    exporter: ExportController,
    history: History,
    onUndo: () -> Unit,
    onRedo: () -> Unit,
) {
    var selected by remember { mutableIntStateOf(0) }
    var previewOpen by remember { mutableStateOf(true) }
    val player = remember { PlayerState() }

    Scaffold(containerColor = Color.Black) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            StudioHeader(
                resolution = project.res,
                previewOpen = previewOpen,
                onTogglePreview = { previewOpen = !previewOpen },
                onResolution = { selected = 3 },
                onExport = { selected = 5 },
            )
            PreviewPanel(project, onProject, player, previewOpen, history.canUndo, history.canRedo, onUndo, onRedo)
            Surface(
                color = PanelColor,
                shape = RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp),
                modifier = Modifier.weight(1f).fillMaxWidth(),
            ) {
                Column {
                    Box(modifier = Modifier.height(10.dp))
                    Box(modifier = Modifier.weight(1f)) {
                        when (selected) {
                            0 -> CardsScreen(project, onProject)
                            1 -> EditScreen(project, onProject)
                            2 -> TimingScreen(project, onProject, player)
                            3 -> VideoScreen(project, onProject)
                            4 -> BrandScreen(project, onProject)
                            5 -> ExportScreen(project, onProject, exporter)
                            6 -> TextStyleScreen(project, onProject)
                            7 -> EffectsScreen(project, onProject)
                            else -> VoiceScreen(project, onProject, player)
                        }
                    }
                }
            }
            BottomNav(selected) { selected = it }
        }
    }
}

@Composable
private fun StudioHeader(
    resolution: Int,
    previewOpen: Boolean,
    onTogglePreview: () -> Unit,
    onResolution: () -> Unit,
    onExport: () -> Unit,
) {
    Row(
        modifier = Modifier.fillMaxWidth().height(50.dp).padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text("ZCH News Studio", fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, modifier = Modifier.weight(1f))
        HeaderChip(if (previewOpen) "View \u25BE" else "View \u25B4", onTogglePreview)
        HeaderChip("${resolution}p", onResolution)
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(18.dp))
                .background(Brush.horizontalGradient(listOf(AccentColor, Color(0xFF5EF0FF))))
                .clickable(onClick = onExport)
                .padding(horizontal = 18.dp, vertical = 8.dp),
        ) {
            Text("Export", color = Color.Black, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun HeaderChip(text: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(14.dp))
            .background(FieldColor)
            .clickable(onClick = onClick)
            .padding(horizontal = 11.dp, vertical = 5.dp),
    ) {
        Text(text, fontSize = 12.sp)
    }
}

@Composable
private fun BottomNav(selected: Int, onSelect: (Int) -> Unit) {
    Column(modifier = Modifier.fillMaxWidth().background(Color.Black)) {
        HorizontalDivider(color = Color(0xFF222222))
        Row(modifier = Modifier.fillMaxWidth().height(58.dp)) {
            NAV.forEach { (label, index) ->
                val on = selected == index
                Column(
                    modifier = Modifier.weight(1f).fillMaxHeight().clickable { onSelect(index) },
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    val tint = if (on) AccentColor else MutedColor
                    if (index == 6) {
                        Text("Aa", color = tint, fontWeight = FontWeight.Bold, fontSize = 16.sp, modifier = Modifier.height(22.dp))
                    } else {
                        Icon(NavIcons.forTab(index), contentDescription = label, tint = tint, modifier = Modifier.size(22.dp))
                    }
                    Text(label, fontSize = 10.sp, color = if (on) Color.White else MutedColor, maxLines = 1)
                }
            }
        }
    }
}
