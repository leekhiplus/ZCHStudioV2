package com.zch.studio.ui

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.unit.dp

/** The line icons of the WebView app's bottom bar, drawn from the same SVG paths. */
object NavIcons {

    private val cache = HashMap<String, ImageVector>()

    private fun build(name: String, vararg paths: String): ImageVector = cache.getOrPut(name) {
        ImageVector.Builder(name = name, defaultWidth = 24.dp, defaultHeight = 24.dp, viewportWidth = 24f, viewportHeight = 24f)
            .apply {
                paths.forEach { d ->
                    addPath(
                        pathData = PathParser().parsePathString(d).toNodes(),
                        stroke = SolidColor(Color.White),
                        strokeLineWidth = 2f,
                        strokeLineCap = StrokeCap.Round,
                        strokeLineJoin = StrokeJoin.Round,
                    )
                }
            }
            .build()
    }

    /** Icon for a section number (the numbers of the WebView app). Text (6) uses the letters "Aa" instead. */
    fun forTab(i: Int): ImageVector = when (i) {
        0 -> build("cards", "M6 7H18A2 2 0 0 1 20 9V16A2 2 0 0 1 18 18H6A2 2 0 0 1 4 16V9A2 2 0 0 1 6 7Z", "M8 4h8")
        1 -> build("edit", "M4 20h4L19 9l-4-4L4 16z")
        8 -> build("voice", "M12 3A3 3 0 0 1 15 6V11A3 3 0 0 1 9 11V6A3 3 0 0 1 12 3Z", "M5 11a7 7 0 0 0 14 0M12 18v3")
        7 -> build("effects", "M12 3v4M12 17v4M3 12h4M17 12h4M6 6l2.5 2.5M15.5 15.5L18 18M18 6l-2.5 2.5M8.5 15.5L6 18")
        2 -> build("timing", "M12 4A8 8 0 1 1 12 20A8 8 0 1 1 12 4Z", "M12 8v4l3 2")
        3 -> build("video", "M5 6H14A2 2 0 0 1 16 8V16A2 2 0 0 1 14 18H5A2 2 0 0 1 3 16V8A2 2 0 0 1 5 6Z", "M16 10l5-2v8l-5-2")
        else -> build("brand", "M12 3l2.6 5.4 5.9.9-4.3 4.1 1 5.8-5.2-2.8-5.2 2.8 1-5.8L3.5 9.3l5.9-.9z")
    }


    private val NAMED: Map<String, List<String>> = mapOf(
        "film" to listOf("M4 5H20V19H4Z", "M8 5V19", "M16 5V19", "M4 9H8", "M4 15H8", "M16 9H20", "M16 15H20"),
        "template" to listOf("M4 5H20V19H4Z", "M4 10H20", "M10 10V19"),
        "text" to listOf("M5 6H19", "M12 6V19", "M9 19H15"),
        "lines" to listOf("M4 7H20", "M4 12H20", "M4 17H13"),
        "trophy" to listOf("M8 4H16V9A4 4 0 0 1 8 9Z", "M5 5H8", "M16 5H19", "M12 13V17", "M9 20H15"),
        "photo" to listOf("M4 5H20V19H4Z", "M4 16L9 11L13 15L16 12L20 16"),
        "copy" to listOf("M9 9H20V20H9Z", "M5 15V4H16"),
        "frame" to listOf("M4 9V4H9", "M20 9V4H15", "M4 15V20H9", "M20 15V20H15"),
        "palette" to listOf("M12 3A9 9 0 1 0 12 21C13.5 21 14 20 13.5 19C13 18 13.5 17 15 17H17A3 3 0 0 0 20 14A9 9 0 0 0 12 3Z"),
        "key" to listOf("M4 11A4 4 0 1 1 12 11A4 4 0 1 1 4 11Z", "M11 13.5L20 21"),
        "wave" to listOf("M3 12H5", "M7 8V16", "M11 5V19", "M15 8V16", "M19 10V14"),
        "speaker" to listOf("M4 10V14H8L13 18V6L8 10Z", "M16 9A4 4 0 0 1 16 15"),
        "export" to listOf("M12 4V16", "M7 11L12 16L17 11", "M5 20H19"),
        "bars" to listOf("M3 15H21V19H3Z", "M3 5H21V9H3Z"),
        "lower" to listOf("M4 6H14V9H4Z", "M4 14H20V19H4Z"),
        "cc" to listOf("M4 6H20V18H4Z", "M10 10A2 2 0 1 0 10 14", "M17 10A2 2 0 1 0 17 14"),
        "transition" to listOf("M4 6H11V18H4Z", "M13 6H20V18H13Z"),
        "tag" to listOf("M4 12V4H12L20 12L12 20Z", "M8 8H8.5"),
        "shine" to listOf("M12 3L14 9L20 11L14 13L12 19L10 13L4 11L10 9Z"),
        "motion" to listOf("M5 12H15", "M11 7L16 12L11 17", "M19 5V19"),
        "size" to listOf("M5 19L12 5L19 19", "M8 14H16"),
        "settings" to listOf("M4 8H14", "M18 8H20", "M4 16H6", "M10 16H20", "M14 6V10", "M6 14V18"),
    )

    /** Icon by name for the tool bars inside the tabs. */
    fun named(name: String): ImageVector = when (name) {
        "clock" -> forTab(2)
        "video" -> forTab(3)
        "brand" -> forTab(4)
        "voice" -> forTab(8)
        "effects" -> forTab(7)
        "edit" -> forTab(1)
        "star" -> forTab(4)
        else -> build("named-$name", *(NAMED[name] ?: NAMED.getValue("lines")).toTypedArray())
    }

    val Undo: ImageVector get() = build("undo", "M9 14L4 9l5-5", "M4 9h10a6 6 0 0 1 0 12h-3")
    val Redo: ImageVector get() = build("redo", "M15 14l5-5-5-5", "M20 9H10a6 6 0 0 0 0 12h3")
}
