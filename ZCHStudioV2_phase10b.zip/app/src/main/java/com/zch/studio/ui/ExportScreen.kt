package com.zch.studio.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import com.zch.studio.export.ExportController
import com.zch.studio.model.Project
import com.zch.studio.model.outputSize
import com.zch.studio.model.totalDuration

private val TOOLS = listOf(ToolDef("Format", "video"), ToolDef("Export", "export"))

/** Export tab: format, and the export itself with progress. */
@Composable
fun ExportScreen(project: Project, onProject: (Project) -> Unit, exporter: ExportController) {
    val (w, h) = project.outputSize()
    val seconds = project.totalDuration()
    val busy = exporter.running
    val context = LocalContext.current
    val latest by rememberUpdatedState(project)
    // The export shows a progress notification. The export starts whether or not the permission is granted.
    val askNotifications = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        exporter.start(latest)
    }

    ToolScreen("export", TOOLS, initial = 1) { tool ->
        if (tool == 0) {
            Group("Shape") {
                Chips(listOf("16:9", "9:16", "1:1").map { it to it }, project.asp, enabled = !busy) { onProject(project.copy(asp = it)) }
            }
            Group("Size (short side)") {
                Chips(listOf("480", "720", "1080").map { it to "${it}p" }, project.res.toString(), enabled = !busy) {
                    onProject(project.copy(res = it.toInt()))
                }
            }
            Group("Frame rate") {
                Chips(listOf("24", "25", "30").map { it to "$it fps" }, project.fps.toString(), enabled = !busy) {
                    onProject(project.copy(fps = it.toInt()))
                }
            }
        } else {
            Group("Summary") {
                Text("$w x $h, ${project.fps} fps")
                Hint("${seconds.toInt()} seconds, MP4 (H.264)")
                Hint(if (project.audioName.isEmpty()) "No voiceover. Add one in the Voice tab." else "Voiceover: ${project.audioName}")
            }
            Group("Export") {
                if (busy) {
                    LinearProgressIndicator(progress = { exporter.progress }, modifier = Modifier.fillMaxWidth())
                    Text("${(exporter.progress * 100).toInt()}%")
                    OutlinedButton(onClick = { exporter.cancel() }, modifier = Modifier.fillMaxWidth()) { Text("Cancel") }
                } else {
                    Button(
                        onClick = {
                            val needsAsk = Build.VERSION.SDK_INT >= 33 &&
                                ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                            if (needsAsk) askNotifications.launch(Manifest.permission.POST_NOTIFICATIONS) else exporter.start(project)
                        },
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Export MP4") }
                }
                if (exporter.status.isNotEmpty()) Text(exporter.status)
                Hint("Export keeps running in the background. Watch the notification for progress.")
            }
        }
    }
}
