package com.zch.studio.ui

import androidx.compose.runtime.Composable
import com.zch.studio.model.Project

private val TOOLS = listOf(ToolDef("Size", "size"), ToolDef("Colors", "palette"))

/** Text tab: size and colours of the selected card. */
@Composable
fun TextStyleScreen(project: Project, onProject: (Project) -> Unit) {
    CardToolScreen(project, onProject, "text", TOOLS) { card, update, tool ->
        if (tool == 0) {
            Group("Text size") {
                LabeledSlider("Size of this card's text", card.ts.toFloat(), 0.5f..1.6f) { update(card.copy(ts = it.toDouble())) }
            }
            Group("Fonts") {
                Hint("Urdu text uses Noto Nastaliq Urdu and English text uses Montserrat. Both are built into the app.")
            }
        } else {
            Group("Text color") { ColorField("Text color", card.tc) { update(card.copy(tc = it)) } }
            Group("Background color") { ColorField("Background color", card.bg) { update(card.copy(bg = it)) } }
        }
    }
}
