package com.zch.studio.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.zch.studio.audio.SfxPlayer
import com.zch.studio.audio.SfxSynth
import com.zch.studio.model.Project

private val TEXT_ANIMATIONS = listOf(
    "Fade In", "Slide From Right", "Slide From Left", "Slide From Bottom", "Pop In", "Zoom In", "Slide From Top",
    "Zoom Out", "Bounce Drop", "Spin In", "Flip In", "Wipe (right to left)", "Wipe (left to right)", "No animation",
)
private val PICTURE_ANIMATIONS = listOf(
    "Slow Zoom In", "Slow Zoom Out", "Pan Left", "Pan Right", "Static Image", "Pan Up", "Pan Down",
    "Zoom In + Pan Right", "Zoom Out + Pan Left", "Pulse", "Fast Zoom In",
)
private val TRANSITIONS = listOf(
    "cut" to "Cut", "cross" to "Crossfade", "fade" to "Fade through black", "flash" to "Flash", "push" to "Push",
    "slide" to "Slide from right", "slidel" to "Slide from left", "slideu" to "Slide up", "zoom" to "Zoom in", "wipe" to "Wipe",
)
private val PICTURE_CHANGES = listOf("cross" to "Crossfade", "slide" to "Slide", "zoom" to "Zoom", "flash" to "Flash", "wipe" to "Wipe")

private val TOOLS = listOf(
    ToolDef("Presets", "star"), ToolDef("Animate", "motion"), ToolDef("Lower third", "lower"), ToolDef("Captions", "cc"),
    ToolDef("Sound", "speaker"), ToolDef("Transition", "transition"), ToolDef("Shine", "shine"),
)

/** Effects tab: presets, animation, lower third, captions, sound, transitions and shine. */
@Composable
fun EffectsScreen(project: Project, onProject: (Project) -> Unit) {
    val sfx = remember { SfxPlayer() }
    DisposableEffect(Unit) { onDispose { sfx.release() } }

    CardToolScreen(project, onProject, "effects", TOOLS) { card, update, tool ->
        when (tool) {
            0 -> {
                Group("Newsroom look") {
                    Hint("Sets the template, tag, text bar, shine, picture change and pop of this card in one tap.")
                    OutlinedButton(
                        onClick = {
                            update(card.copy(tpl = 16, ot = 1, ot1 = "BREAKING NEWS", ot2 = "LIVE", ol = 1, olx = "fade", sh = 1, it = "cross", pz = 1))
                        },
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Newsroom preset") }
                }
                Group("All cards") {
                    Hint("Copies the lower third, shine, picture change and pop of this card to every card.")
                    OutlinedButton(
                        onClick = {
                            onProject(
                                project.copy(
                                    cards = project.cards.map { c ->
                                        c.copy(
                                            ot = card.ot, ot1 = card.ot1, ot2 = card.ot2, ol = card.ol, olx = card.olx,
                                            olc = card.olc, sh = card.sh, it = card.it, pz = card.pz,
                                        )
                                    },
                                ),
                            )
                        },
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Apply to all cards") }
                }
            }
            1 -> {
                Group("Text") { IndexChoice("Text animation", TEXT_ANIMATIONS, card.ta) { update(card.copy(ta = it)) } }
                Group("Picture") {
                    IndexChoice("Picture animation", PICTURE_ANIMATIONS, card.ia) { update(card.copy(ia = it)) }
                    Choice("When the picture changes", PICTURE_CHANGES, card.it) { update(card.copy(it = it)) }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Group("Speed", Modifier.weight(1f)) {
                        LabeledSlider("Speed", card.sp.toFloat(), 0.5f..3f) { update(card.copy(sp = it.toDouble())) }
                    }
                    Group("Pop", Modifier.weight(1f)) {
                        SwitchRow("At start", card.pz != 0) { update(card.copy(pz = if (it) 1 else 0)) }
                    }
                }
            }
            2 -> {
                Group("Tag at the top left") {
                    SwitchRow("Show the tag", card.ot != 0) { update(card.copy(ot = if (it) 1 else 0)) }
                    if (card.ot != 0) {
                        OutlinedTextField(
                            value = card.ot1, onValueChange = { update(card.copy(ot1 = it)) },
                            label = { Text("Red part") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                        )
                        OutlinedTextField(
                            value = card.ot2, onValueChange = { update(card.copy(ot2 = it)) },
                            label = { Text("White part (can be empty)") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                        )
                    }
                }
                Group("Text bar at the bottom") {
                    SwitchRow("Show the bar", card.ol != 0) { update(card.copy(ol = if (it) 1 else 0)) }
                    if (card.ol != 0) {
                        OutlinedTextField(
                            value = card.lt, onValueChange = { update(card.copy(lt = it)) },
                            label = { Text("Bar text (empty uses the headline)") }, modifier = Modifier.fillMaxWidth(),
                        )
                        Choice("Bar text at the end", listOf("fade" to "Fade out", "slide" to "Slide out", "stay" to "Stay"), card.olx.ifBlank { "fade" }) {
                            update(card.copy(olx = it))
                        }
                    }
                }
                if (card.ol != 0) Group("Bar color") { ColorField("Bar color", card.olc) { update(card.copy(olc = it)) } }
                Group("Shine") { SwitchRow("Shine on the tag and bar", card.sh != 0) { update(card.copy(sh = if (it) 1 else 0)) } }
            }
            3 -> Group("Captions") {
                SwitchRow("Show the spoken words on the card", card.cap != 0) { update(card.copy(cap = if (it) 1 else 0)) }
                Hint("Captions need a voiceover whose cards are matched to it. Make one in the Voice tab.")
            }
            4 -> {
                Group("This card") {
                    Choice("Sound", listOf("def" to "Use the default", "none" to "No sound") + SfxSynth.NAMES, card.sfx.ifEmpty { "def" }) {
                        update(card.copy(sfx = it))
                    }
                    val chosen = SfxSynth.nameFor(card, project)
                    OutlinedButton(onClick = { chosen?.let { sfx.play(it, project.sfv.toFloat()) } }, enabled = chosen != null) {
                        Text("Play this card's sound")
                    }
                }
                Group("Default for all cards") {
                    Choice("Sound", listOf("none" to "No sound") + SfxSynth.NAMES, project.sfx) { onProject(project.copy(sfx = it)) }
                }
                Group("Volume") {
                    LabeledSlider("Sound volume", project.sfv.toFloat(), 0f..1f) { onProject(project.copy(sfv = it.toDouble())) }
                    Hint("Sounds play in the preview and are mixed into the exported video with the voiceover.")
                }
            }
            5 -> {
                Group("Between cards") { Choice("Transition", TRANSITIONS, project.trans) { onProject(project.copy(trans = it)) } }
                Group("Length") {
                    LabeledSlider("Transition length (s)", project.td.toFloat(), 0.2f..1.5f) { onProject(project.copy(td = it.toDouble())) }
                }
            }
            else -> {
                Group("Where") {
                    Chips(listOf("bars" to "Panels only", "all" to "Whole card", "off" to "Off"), project.ls) { onProject(project.copy(ls = it)) }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Group("Strength", Modifier.weight(1f)) {
                        LabeledSlider("Strength", project.lsi.toFloat(), 0.1f..1f) { onProject(project.copy(lsi = it.toDouble())) }
                    }
                    Group("Every", Modifier.weight(1f)) {
                        LabeledSlider("Seconds", project.lsp.toFloat(), 1f..6f, 1) { onProject(project.copy(lsp = it.toDouble())) }
                    }
                }
            }
        }
    }
}
