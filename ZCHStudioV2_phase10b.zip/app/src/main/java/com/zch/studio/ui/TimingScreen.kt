package com.zch.studio.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.ui.Modifier
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.unit.dp
import com.zch.studio.model.Project
import com.zch.studio.model.closeGaps
import com.zch.studio.model.withEqualLengths
import java.util.Locale
import kotlin.math.max

private val TOOLS = listOf(ToolDef("Card", "clock"), ToolDef("All cards", "lines"), ToolDef("Help", "settings"))

/** Timing tab: start and end of the selected card, tools for all cards, and how to edit in the timeline. */
@Composable
fun TimingScreen(project: Project, onProject: (Project) -> Unit, player: PlayerState) {
    var every by remember { mutableFloatStateOf(5f) }
    CardToolScreen(project, onProject, "timing", TOOLS) { card, update, tool ->
        when (tool) {
            0 -> {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Group("Start", Modifier.weight(1f)) {
                        Stepper(card.s) { update(card.copy(s = it.coerceIn(0.0, card.e - 0.3))) }
                    }
                    Group("End", Modifier.weight(1f)) {
                        Stepper(card.e) { update(card.copy(e = max(it, card.s + 0.3))) }
                    }
                }
                Group("Length") {
                    Hint("This card lasts " + String.format(Locale.US, "%.1f", card.e - card.s) + " seconds.")
                    Button(onClick = { player.time = card.s.toFloat(); player.playing = true }, modifier = Modifier.fillMaxWidth()) {
                        Text("Play from this card")
                    }
                }
            }
            1 -> {
                Group("Close the gaps") {
                    Hint("Moves every card so they follow each other with no gaps.")
                    OutlinedButton(onClick = { onProject(project.closeGaps()) }, modifier = Modifier.fillMaxWidth()) { Text("Back to back") }
                }
                Group("Same length for every card") {
                    LabeledSlider("Seconds", every, 2f..12f, 1) { every = it }
                    OutlinedButton(onClick = { onProject(project.withEqualLengths(every.toDouble())) }, modifier = Modifier.fillMaxWidth()) {
                        Text("Apply same length")
                    }
                }
            }
            else -> Group("Editing in the timeline") {
                Hint(
                    "Tap a card in the timeline to select it, then drag it. The edges change its start or end and the middle moves it. " +
                        "Drag anywhere else to scroll. Use Fit, 1x, 2x, 4x, 8x to zoom and Tall for more tracks. " +
                        "Cards made with a Gemini voice are timed to the speech, so changing them can move picture and voice apart.",
                )
            }
        }
    }
}
